<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Controllers\Base;
use App\Models\rhModel;
use App\Models\posisiModel;
use App\Models\bhsModel;
use App\Models\sertModel;
use App\Models\ModelPengalaman;
use App\Models\expNonQModel;
use App\Models\eduModel;


class CV extends BaseController
{
    protected $rhModel;
    protected $posisiModel;
    protected $bhsModel;
    protected $sertModel;
    protected $base;
    protected $ModelPengalaman;
    protected $expNonQModel;
    protected $eduModel;

    public function __construct()
    {
        $rh = $this->rhModel = new rhModel();
        $posisi = $this->posisiModel = new posisiModel();
        $bhs = $this->bhsModel = new bhsModel();
        $sertifikat = $this->sertModel = new sertModel();
        $pengalaman = $this->ModelPengalaman = new ModelPengalaman();
        $expNonQModel = $this->expNonQModel = new expNonQModel();
        $eduModel = $this->eduModel = new eduModel();
    }
    public function index()
    {
        if (session()->get('id')) {
            $posisi = $this->posisiModel->getPosisi();
            $result = $this->rhModel->getCVwithKode();
            $data = ['rh' => $result, 'posisi' => $posisi, 'judul' => 'Riwayat Hidup Tenaga Ahli'];
            return view('cv/index', $data);
            //return view('cv/index');
        }
        else
            return redirect()->to('/');
    }
    public function RiwayatHidup($kode = null)
    {
        $NamafileTandaTangan = '';
        $tt = $this->rhModel->getViewTandaTangan($kode);
        if (count($tt) > 0) {   //  Dari https://www.w3schools.com/php/func_array_count.asp
            $NamafileTandaTangan = $tt[0]['lokasi'];
            $NamafileTandaTangan = substr($NamafileTandaTangan, 12);
        } 
        
        $sertifikat = $this->sertModel = new sertModel();
        $srt = $sertifikat->getSrtWithKode($kode);
        $bhs = $this->bhsModel->getBhsWithKode($kode);
        $pengalaman = $this->ModelPengalaman->getPengalaman($kode);
        $pengalaman_nq = $this->expNonQModel = new expNonQModel();
        $experiences = $pengalaman_nq->CariSemuaKodeTA($kode); 
        $pendidikan = $this->eduModel->getEduWithKode($kode);
        
        $ta = $this->rhModel->getCVwithKode($kode);
    
        //  Mencari tanggal lahir, untuk dikonversi dari angka menjadi nama bulan 
        $tanggal = '';
        $tgl = isset($ta['tgl']) ? $ta['tgl'] : '';
        if ($tgl != '0000-00-00' && $tgl != null && $tgl != '') {
            $tgl = substr($ta['tgl'], 8, 2);
            $bln = substr($ta['tgl'], 5, 2);
            //  Memanggil helper 
            helper('custom_helper'); // Loading single helper
            //  Memanggil fungsi NamaBulan() untuk mencetak nama-nama bulan
            $bulan = NamaBulan($bln);
            $thn = substr($ta['tgl'], 0, 4);
            $tanggal = $tgl . " " . $bulan . " " . $thn;
        }
        //  Mencari status pegawai
        $status = isset($ta['status_pgw']) ? $ta['status_pgw'] : '';

        $data = [
            'ta' => $ta,
            'status' => $status,
            'tt' => $NamafileTandaTangan,
            'tgl_lahir' => $tanggal,
            'srt' => $srt,
            'bhs' => $bhs,
            'pendidikan' => $pendidikan,
            'pengalaman' => $pengalaman,
            'pengalamanNonQ' => $experiences
        ];
        return view('cv/rh', $data);
    }
}
