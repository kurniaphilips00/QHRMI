<?php
namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\rhModel;
use App\Models\lampiranModel;
use App\Models\proyekModel;

class Upload extends BaseController {
    protected $rhModel;
    protected $lampiranModel; 
    protected $proyekModel;
    public function __construct()
    {
        $ta = $this->rhModel = new rhModel();    
        $proyek = $this->proyekModel = new proyekModel();
        $img = $this->lampiranModel = new lampiranModel();   
    }
    public function index() {
            //  User tidak boleh masuk ke http://localhost:8080/index.php/home/dashboard tanpa login (mengetik url di Google)
            //  https://stackoverflow.com/questions/4473042/how-to-prevent-entering-to-the-site-using-url-typing-in-codeigniter
            if (session()->get('id')) {
                $ta = $this->rhModel->getCV();  
                $img = $this->lampiranModel->getLampiran(); 
                $data = [ 'judul' => 'Data Lampiran Tenaga Ahli', 'ta' => $ta, 'img' => $img]; 
                return view('upload/index', $data);
            }
            else
                return redirect()->to('/');
    }
    
    
   public function tambah() {
    $taKode = $this->rhModel->getTAOrderByKode();// Untuk memilih Tenaga Ahli urut berdasarkan kode
      $taName = $this->rhModel->getTAOrderByName();// Untuk memilih Tenaga Ahli urut berdasarkan nama 
      $n = 0;
      foreach ($taName as $val) {
          $nama[$n] = $val['nama'];
          $kode[$n] = $val['kode_ta'];
          $n++;
      }

      $ta = $this->rhModel->getTAOrderByKode();  
      $proyek = $this->proyekModel->getProyekOrderByKode();
      $img = $this->lampiranModel->getLampiran();
      $data = [            
          'ta' => $ta, 
          'proyek' => $proyek,
          'img' => $img,
          'judul' => 'Tambah Data Lampiran',
          'nama' => $nama,
          'kode' => $kode,            
      'validation' => \Config\Services::validation() 
      ];
      return view('upload/tambah1', $data);
  }
  

    //https://makitweb.com/how-to-upload-a-file-using-jquery-ajax-in-codeigniter-4/
    //https://www.webslesson.info/2019/09/how-to-create-progress-bar-for-data-insert-in-php-using-ajax.html
    //Menyimpan file upload, atribut, dan field2 memakai progress bar dengan ajax
    public function upl() { //  Menyimpan  data baru (memakai ajax)

        helper(['form', 'url']);
       // dd($this->request->getFile('file'));
        $database = \Config\Database::connect();
        $builder = $database->table('tb_lampiran');
        $validateImage = $this->validate([
            'file' => [
                'uploaded[file]',
                'mime_in[file, image/png, image/jpg,image/jpeg, image/gif]',
                'max_size[file, 4096]',
            ],
        ]);
        
        $response = [
            'success' => false,
            'data' => '',
            'msg' => "File image tidak ter-upload"
        ];

        $imageFile = $this->request->getFile('file');
        if (! $imageFile->hasMoved()) {
        //if ($validateImage) {
            
            $newName = $imageFile->getName();
            /*
            $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
            $pdf_File->move($PATH . '/uploads');
            $lokasi = "public_html/uploads/" . $newName;
            */
            // Simpan file difolder public/uploads/
            $imageFile->move(WRITEPATH . '../public/uploads', $newName);
            $kode_ta = $this->request->getVar('kode_ta');
            $nama_ta = $this->request->getVar('nama_ta');
            $lampiran = $this->request->getVar('lampiran');
            $data = [
                'namafile' => $newName,
                'kode_ta' => $kode_ta,
                'nama_ta'  => $nama_ta,
                'lampiran' => $lampiran
            ];
            $save = $builder->insert($data);
            $response = [
                'success' => true,
                'data' => $save,
                'msg' => "File image berhasil di-upload"
            ];
        }
        return $this->response->setJSON($response);
    }  


    public function delete($id)
    {
        $v = $this->lampiranModel->getLampiran($id);
        //  Hapus file fisik di dalam path
        $lokasi = isset($v['lokasi']) ? $v['lokasi'] : '';
        if ($lokasi != '') {

          //  $PATH = getcwd();                   // get current working directory
            $lokasi = substr($lokasi, 29);      // lokasi = tt/namafile.ext (	atau uploads/namafile.ext )
          //  $namafile = $PATH . '/' . $lokasi;  // Contoh : "/home/u454747069/domains/prapro.cloud/public_html/tt/Yani Antariksa.jpg"
            //  Jika file fisiknya masih ada > hapus !!!
            if (file_exists($lokasi))
                unlink($lokasi);
        }
        $this->lampiranModel->delete($id);
        return redirect()->to(base_url('upload/'))->with('sukses-hapus', 'Data berhasil dihapus');
    }
}
?>