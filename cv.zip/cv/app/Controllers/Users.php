<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\usrModel;

class Users extends BaseController
{
    public function index()
    {
        if (session()->get('id')) {
            $model = new usrModel();
            $data['users'] = $model->orderBy('id', 'ASC')->findAll();
            return view('usr/index1', $data);
        } else
            return redirect()->to('/');
    }

    public function ajax_read($id)
    {
        $users = new usrModel();
        $data = $users->get_by_id($id);
        echo json_encode($data);
    }

    public function add()
    {
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password' => $this->request->getPost('password'),
            'created_at' => $this->request->getPost('created_at')
        ];
        $model = new usrModel();
        $model->save($data);
        return $this->response->setJSON([
            'status' => 'Sukses tambah data !'
        ]);
    }

    public function ajax_edit($id) {
        $model = new usrModel();
        $data = $model->get_by_id($id);
        echo json_encode($data);
    }
 
    public function ajax_update() {
        helper(['form', 'url']);
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password' => $this->request->getPost('password'),
            'created_at' => $this->request->getPost('created_at')
        ];
        $model = new usrModel();
        $model->user_update(array('id' => $this->request->getPost('id')), $data);
        return $this->response->setJSON([
            'status' => 'Sukses update data !'
        ]);
    }

 

    public function delete($id)
    {
        $model = new usrModel();
        $model->delete($id);
        //  return redirect()->to(base_url('/user'))->with('sukses-hapus', 'Data berhasil dihapus');
        return $this->response->setJSON([
            'status' => 'Sukses hapus data !'
        ]);
    }

    
}
