<?php
/*
Ini perbaikan tampilan tabel, nama(disesuaikan dengan ExpNonQ) dan refreshing(untuk mengingat lagi) 
Jangan hapus file app/Views/errors/ ("missing error view file") :
https://stackoverflow.com/questions/74006380/the-error-view-files-were-not-found-cannot-render-exception-trace-code-igniter

//  Datatables Serverside dengan editor tidak bisa dipakai,
//  karena library harus berbayar (ada trial expired) > What about Yew ....?
//  https://datatables.net/examples/data_sources/server_side

*/
namespace App\Controllers;
/**********************************************************************************
 * Perbedaan online dan offline (localhost) pada  
 * $PATH = getcwd(); untuk online
 * sedangkan localhost memakai
 * $imageFile->move(WRITEPATH . '../public/uploads', $newName); 
 * 
 ***********************************************************************************/
use App\Models\rhModel;
use App\Controllers\BaseController;
use App\Models\ModelPengalaman;
use App\Models\posisiModel;
use App\Models\proyekModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

class ExpOnQ extends BaseController
{
    protected $rhModel;
    protected $ModelPengalaman;
    protected $posisiModel;
    protected $proyekModel;
    public function __construct()
    {
        $posisi = $this->posisiModel = new posisiModel();
        $rh = $this->rhModel = new rhModel();
        $expert = $this->ModelPengalaman = new ModelPengalaman();
        $proyek = $this->proyekModel = new proyekModel();
    }

    public function index()
    {
        if (session()->get('id')) {
            $expert = $this->ModelPengalaman->getExperts();
            $rh = $this->rhModel->getCV();
            $data = [
                'judul' => 'Data Pengalaman Tenaga Ahli',
                'rh' => $rh,
                'expert' => $expert
            ];
           
            return view('/ExpOnQ/index', $data);
        } else
            return redirect()->to('/');
    }

    public function edit_ajax()
    {
        // Get the users data from the database
        $expert = $this->ModelPengalaman->findAll();

        // If the request is a POST request, then update or delete the user data
        if ($this->request->getPost()) {
            $data = $this->request->getPost();

            if (isset($data['id'])) {
                // Update the user data
                $this->ModelPengalaman->update($data['id'], $data);
            } else {
                // Create a new user
                $this->ModelPengalaman->insert($data);
            }
        }

        // Return the users data in JSON format
        return json_encode($expert);
    }

//  Ini dipakai jika memakai Datatable Serverside
//  Dipanggil oleh /oldExp/index1
    public function tampilkan_ajax() {
        $model = $this->ModelPengalaman = new ModelPengalaman();
        $data = $model->findAll();
        $output = array(
            'data' => $data
        );
        echo json_encode($output);
    }
    public function tambah()
    {
        if (session()->get('id')) {
            helper('custom_helper');
            $expert = $this->ModelPengalaman->getExperts();
            $kode = CheckPengalaman($expert);   //  Menghitung nomor kode
            if ($kode == null) {
                $kode = hitungKode('tb_pengalaman');
            }
            $taName = $this->rhModel->getTAOrderByName(); // Untuk memilih Tenaga Ahli urut berdasarkan nama

            $n = 0;
            $namata = [];
            $kodeta = [];
            foreach ($taName as $val) {
                $namata[$n] = $val['nama'];
                $kodeta[$n] = $val['kode_ta'];
                $n++;
            }

            $n = 0;
            $nama_pekerjaan = [];
            $kode_proyek = [];
            $nama_instansi = [];
            $proyek = $this->proyekModel->getProyek();
            foreach ($proyek as $val) {
                $kode_proyek[$n] = $val['kode_proyek'];
                $nama_pekerjaan[$n] = $val['pekerjaan'];
                $nama_instansi[$n] = $val['instansi'];
                $n++;
            }
            //  Untuk mengisi kode_posisi dan posisitugas
            $n = 0;
            $posisitugas = [];
            $kode_posisi = [];
            $posisi = $this->posisiModel->getPosisi();
            foreach ($posisi as $val) {
                $kode_posisi[$n] = $val['kode_posisi'];
                $posisitugas[$n] = $val['posisitugas'];
                $n++;
            }

            $ta = $this->rhModel->getCV();
            $expert = $this->ModelPengalaman->getExperts();
            $data = [
                'judul' => 'Tambah Tenaga Ahli',
                'ta' => $ta,
                'expert' => $expert,
                'proyek' => $proyek,
                'posisi' => $posisi,
                'kode' => $kode,
                'nama_ta' => $namata,
                'kode_ta' => $kodeta,
                'kode_proyek' => $kode_proyek,
                'nama_pekerjaan' => $nama_pekerjaan,
                'nama_instansi' => $nama_instansi,
                'kode_posisi' => $kode_posisi,
                'posisitugas' => $posisitugas,
                'taName' => $taName,
                'validation' => \Config\Services::validation()
            ];
            return view('/oldExp/add', $data);
        } else
            return redirect()->to('/');
    }

    ///////////  Menyimpan hasil tambah pengalaman/////////////////////////
    public function simpan()
    {
        /*dd($this->request->getVar('kode_posisi'));
        $rules = $this->validate([
           
            'nama_TA'    => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Nama tenaga ahli harus diisi.',
                ],
            ],
            'nama_pekerjaan'      => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Nama Pekerjaan (kegiatan) harus diisi.',
                ],
            ]
        ]);
        if (!$rules) 
           {    //--pasangannya di tambah_exp.php 
            session()->setFlashdata('gagal-menambah-pengalaman','Tambah data pengalaman gagal !!!');
            return redirect()->back()->withInput();
          } */

        $this->ModelPengalaman->save([
            'kode_pengalaman' => $this->request->getVar('kode'),
            'kode_proyek' => $this->request->getVar('kode_proyek'),
            'nama_pekerjaan' => $this->request->getVar('pekerjaan'),
            'nama_instansi' => $this->request->getVar('nama_instansi'),
            'kode_ta' => $this->request->getVar('kode_ta'),
            'nama_ta' => $this->request->getVar('nama_ta'),
            'kode_posisi' => $this->request->getVar('kode_posisi'),
            'posisitugas' => $this->request->getVar('posisitugas')
        ]);
        //--pasangannya di admin/exp/index.php, karena kalau berhasil langsung kembali ke route /pengalaman (admin/exp/index.php)   
        session()->setFlashdata('sukses-tambah-TA', 'Data pengalaman berhasil ditambah');
        return redirect()->to(base_url('/old-exp'));
    }
    public function ajak()
    {
        $param['draw'] = isset($_REQUEST['draw']) ? $_REQUEST['draw'] : '';
        $key = isset($_REQUEST['search']['value']) ? $_REQUEST['search']['value'] : '';
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : '';
        $length = isset($_REQUEST['length']) ? $_REQUEST['length'] : '';
        $expert = $this->ModelPengalaman = new ModelPengalaman();
    }
    public function baca($kode)
    {
        if (session()->get('id')) {
            $posisi = $this->posisiModel->getPosisi();
            $data = [
                'judul' => 'Baca Data Tenaga Ahli',
                'expert' => $this->ModelPengalaman->getExperts($kode),
                'posisi' => $posisi,

                'validation' => \Config\Services::validation()
            ];
            return view('/oldExp/read', $data);
        } else
            return redirect()->to('/');
    }

    public function edit($id)
    {
        if (session()->get('id')) {
            $taName = $this->rhModel->getTAOrderByName(); // Untuk memilih Tenaga Ahli urut berdasarkan nama
            $n = 0;
            foreach ($taName as $val) {
                $namata[$n] = $val['nama'];
                $kodeta[$n] = $val['kode_ta'];
                $n++;
            }
            $n = 0;

            $proyek = $this->proyekModel->getProyek();

            foreach ($proyek as $val) {
                $kode_proyek[$n] = $val['kode_proyek'];
                $nama_pekerjaan[$n] = $val['pekerjaan'];
                $nama_instansi[$n] = $val['instansi'];
                $n++;
            }

            $posisi = $this->posisiModel->getPosisi();

            //   $ta = $this->rhModel->getCV();// Untuk memilih nama dan mengambil id Tenaga Ahli
            $expert = $this->ModelPengalaman->getExpertsWithID($id);
            $proyek = $this->proyekModel->getProyek();

            $data = [
                'judul' => 'Edit Tenaga Ahli',
                'nama_ta' => $namata,
                'kode_ta' => $kodeta,
                'kode_proyek' => $kode_proyek,
                'nama_pekerjaan' => $nama_pekerjaan,
                'nama_instansi' => $nama_instansi,
                'proyek' => $proyek,
                'expert' => $expert,
                'posisi' => $posisi,
                'validation' => \Config\Services::validation()
            ];
            //  dd($proyek);
            return view('/oldExp/edit', $data);
        } else
            return redirect()->to('/');
    }

    public function update($id)
    {
        //dd($this->request->getVar('posisi'));
        $this->ModelPengalaman->save([
            'id' => $id,
            'nama_ta' => $this->request->getVar('nama_ta'),
            'kode_ta' => $this->request->getVar('kode_ta'),
            'posisitugas' => $this->request->getVar('posisitugas'),
            'kode_proyek' => $this->request->getVar('kode_proyek'),
            'nama_pekerjaan' => $this->request->getVar('nama_pekerjaan'),
            'nama_instansi'  => $this->request->getVar('nama_instansi')
        ]);
        //--pasangannya di admin/exp/index.php, karena kalau berhasil langsung kembali ke route /pengalaman (admin/exp/index.php)   
        session()->setFlashdata('sukses-update-pengalaman', 'Data pengalaman berhasil di-update');
        return redirect()->to('old-exp');
    }
    public function delete($id)
    {
        $this->ModelPengalaman->delete($id);
        session()->setFlashdata('delete-success', 'Data berhasil dihapus');
        return redirect()->to('/old-exp');
    }

    public function delete_all_pengalaman()
    {
        if (isset($_GET['HapusPengalaman'])) 
        //  dd($this->request->getVar('ckdel'));
        {  //  Jika tombol dengan name="HapusPengalaman" diklik
            //  https://stackoverflow.com/questions/64996555/insert-multiple-dimension-array-codeigniter
            if (!empty($this->request->getVar('ckdel'))) {  //  Jika ada checkbox dengan name="ckdel[]" dipilih
                $hapus = $this->request->getVar('ckdel');
               // dd($hapus);
                foreach ($hapus as $br) {
                    $this->ModelPengalaman->delete($br);
                }
            }
        }
        session()->setFlashdata('delete-all-success', 'Semua data pengalaman yang dicentang berhasil dihapus');
        return redirect()->to('/old-exp');
    }
    public function importExcel()
    { //importExcel
        $spreadsheet = new Spreadsheet();
        $file = $this->request->getFile('excel');

        $ext = $file->getExtension();

        if ($ext === "xls" || $ext === "xlsx") {

            if ($ext === "xls") $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();    //  Jika ekstensinya xls
            else $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx(); //  Jika ekstensinya xlsx
            $spread = $reader->load($file); //   Muat ke reader, tampung ke variabel $spread
            $sheet = $spread->getActiveSheet()->toArray(); //    Membaca sheet aktif dan menampung ke array
            /*  Ini untuk keperluan pelacakan
                $n = 0;
                $TA175 = 0;
            */
            foreach ($sheet as $index => $item) {
                if ($index == 0) continue; // Baris ke 0 berisi header(judul), bukan data, jadi diabaikan
                //  Jika baris x semua kolom kosong berhenti
                if ($item[0] == "" && $item[1] == "" && $item[2] == "" && $item[3] == "") {
                    break;
                }
                if ($item[0] != "" && $item[1] != "" && $item[2] != "" && $item[3] != "") {

                    //  Mencari nama pekerjaan dan instansi ke tabel proyek 
                    $pekerjaan = $this->ModelPengalaman->getPekerjaanDanInstansi($item[1]);
                    $job = isset($pekerjaan[0]['pekerjaan']) ? $pekerjaan[0]['pekerjaan'] : '';
                    $posisi = $this->posisiModel->getPosisiByKode($item[3]);
                    $pos = isset($posisi['posisitugas']) ? $posisi['posisitugas'] : '';
                    $rh = $this->rhModel->getCVwithKode($item[2]);
                    $nama = isset($rh['nama']) ? $rh['nama'] : '';

                    //  if ($job != '' and $job != 'NULL') { > .....  ini bisa berakibat fatal jika nama pekerjaan atau instansi
                    //  yang ada di dalam tb_proyek kosong  > jumlah record TA-0175 di dalam  Excel 170 baris, 
                    //  tetapi yang di-import hanya 44 baris, karena itu tidak bisa dipakai sebagai syarat/pedoman 

                    $instansi = isset($pekerjaan[0]['instansi']) ? $pekerjaan[0]['instansi'] : '';
                    /*  Ini untuk keperluan pelacakan
if ($item[2] == 'TA-0175') {
	$TA175++;
}*/
                    $data =
                        [
                            'kode_pengalaman' => $item[0],              //      kolom A
                            'kode_proyek' => $item[1],                  //      kolom B
                            'kode_ta' => $item[2],                      //      kolom C                            	
                            'kode_posisi' => $item[3],                  //      kolom D				
                            'nama_pekerjaan' => $job,
                            'nama_instansi' => $instansi,
                            'nama_ta' => $nama,
                            'posisitugas' => $pos        //	$pos diperoleh dari $item[4]
                        ];
                    $this->ModelPengalaman->insert($data);  // mulai baris 1 dan seterusnya 

                    //            }
                }
            }
            //  ini untuk keperluan pelacakan
            //  session()->setFlashdata('imported', 'Data berhasil di-impor, jumlah TA-0175 = '.$TA175);
            session()->setFlashdata('imported', 'Data berhasil di-impor ');
        } else {
            session()->setFlashdata('error', 'Bukan format file excel');
        }
        return redirect()->to(base_url('/old-exp'));
    }

    public function exportToExcel()
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'Kode Pengalaman');
        $sheet->setCellValue('B1', 'Kode Proyek');
        $sheet->setCellValue('C1', 'Pekerjaan');
        $sheet->setCellValue('D1', 'Instansi');
        $sheet->setCellValue('E1', 'Kode Tenaga Ahli');
        $sheet->setCellValue('F1', 'Nama Tenaga Ahli');
        $sheet->setCellValue('G1', 'Kode Posisi');
        $sheet->setCellValue('H1', 'Posisi');

        $row = 2;   // row 1 dipakai untuk header (judul-judul kolom di atas)
        $exp = $this->ModelPengalaman->getExperts();
        foreach ($exp as $v => $item) {
            $sheet
                ->setCellValue('A' . $row, $item['kode_pengalaman'])
                ->setCellValue('B' . $row, $item['kode_proyek'])
                ->setCellValue('C' . $row, $item['nama_pekerjaan'])
                ->setCellValue('D' . $row, $item['nama_instansi'])
                ->setCellValue('E' . $row, $item['kode_ta'])
                ->setCellValue('F' . $row, $item['nama_ta'])
                ->setCellValue('G' . $row, $item['kode_posisi'])
                ->setCellValue('H' . $row, $item['posisitugas']);
            $row++;
        }

        $filename = "Pengalaman";
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename=' . $filename . '.xlsx');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
    }

    public function kosong()
    {
        $this->ModelPengalaman->kosongkan();
        return redirect()->to('/old-exp');
    }
}
