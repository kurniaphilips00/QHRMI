<?php

/**********************************************************************************
 * Perbedaan online dan offline (localhost) pada  
 * $PATH = getcwd(); untuk online
 * sedangkan localhost memakai
 * $imageFile->move(WRITEPATH . '../public/uploads', $newName); 
 * 
 ***********************************************************************************/

namespace App\Controllers;

use App\Models\rhModel;
use App\Models\sertModel;
use App\Controllers\BaseController;


class CloudCertificate extends BaseController
{
    protected $taModel;
    protected $sertModel;

    public function __construct()
    {
        //  ta diperlukan untuk menampilkan nama pada drop down pilihan nama tenaga ahli (index & modal tambah)
        $ta = $this->taModel = new rhModel();
        $sertifikat = $this->sertModel = new sertModel();
    }
    public function index()
    {
        //  User tidak boleh masuk ke http://localhost:8080/index.php/home/dashboard tanpa login (mengetik url di Google)
        //  https://stackoverflow.com/questions/4473042/how-to-prevent-entering-to-the-site-using-url-typing-in-codeigniter
        if (session()->get('id')) {
            $ta = $this->taModel->getCV();
            $sertifikat = $this->sertModel->getSertifikat();
            $data = [
                'judul' => 'Data Sertifikat Tenaga Ahli',
                'ta' => $ta,
                'sertifikat' =>  $sertifikat
            ];
            return view('sertifikat/index', $data);
        } else
            return redirect()->to('/');
    }

    public function ajax_read($id)
    {
        $sertifikat = new sertModel();
        $data = $sertifikat->get_by_id($id);
        echo json_encode($data);
    }

    public function tambah()
    {
        if (session()->get('id')) {
            $n = 0;
            $taID = $this->taModel->getTAOrderByID(); // Untuk memilih Tenaga Ahli urut berdasarkan ID
            $taName = $this->taModel->getTAOrderByName(); // Untuk memilih Tenaga Ahli urut berdasarkan nama
            $sertifikat = $this->sertModel->getSertifikat();
            foreach ($taName as $val) {
                $nama[$n] = $val['nama'];
                $kode[$n] = $val['kode_ta'];
                $n++;
            }
            $data = [
                'judul' => 'Tambah Data Sertifikat',
                'taID' => $taID,
                'taName' => $taName,
                'sertifikat' =>  $sertifikat,
                'nama' => $nama,
                'kode' => $kode,
                'validation' => \Config\Services::validation()
            ];
            return view('sertifikat/tambah', $data);
        } else
            return redirect()->to('/');
    }


    //https://makitweb.com/how-to-upload-a-file-using-jquery-ajax-in-codeigniter-4/
    //https://www.webslesson.info/2019/09/how-to-create-progress-bar-for-data-insert-in-php-using-ajax.html
    //Menyimpan file upload, atribut, dan field2 memakai progress bar dengan ajax
    public function certupl()
    { //  Menyimpan  data baru (memakai ajax)

        helper(['form', 'url']);

        $database = \Config\Database::connect();
        $builder = $database->table('tb_sertifikat');
        $validateImage = $this->validate([
            'file' => [
                'uploaded[file]',
                'mime_in[file, image/png, image/jpg,image/jpeg, image/gif]',
                'max_size[file, 4096]',
            ],
        ]);

        $response = [
            'success' => false,
            'data' => '',
            'msg' => "File image tidak ter-upload"
        ];

        $imageFile = $this->request->getFile('file');
        if ($imageFile != '' && !$imageFile->hasMoved()) {


            $newName = $imageFile->getName();
            //  Ini untuk cloud
            //  $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
            //  $imageFile->move($PATH . '/certificate');
            //  $lokasi = "public_html/certificate/" . $newName;

            $imageFile->move(WRITEPATH . '../public/certificate/', $newName); //   Pindah file ke direktori penyimpanan
            $lokasi = "public/certificate/" . $newName;

            $nomor_sertifikat = $this->request->getVar('nomor_sertifikat');
            $nama_sertifikat = $this->request->getVar('nama_sertifikat');
            $tgl_kadaluarsa = $this->request->getVar('tgl_kadaluarsa');
            $tgl_terbit = $this->request->getVar('tgl_terbit');

            $kode_ta = $this->request->getVar('kode_ta');
            $nama_ta = $this->request->getVar('nama_ta');
            $data = [
                'nomor_sertifikat' => $nomor_sertifikat,
                'nama_sertifikat' => $nama_sertifikat,
                'namafile' => $newName,
                'kode_ta' => $kode_ta,
                'nama_ta' => $nama_ta,
                'lokasi' => $lokasi,
                'tgl_kadaluarsa' => $tgl_kadaluarsa,
                'tgl_terbit' => $tgl_terbit
            ];

            $save = $builder->insert($data);
            $response = [
                'success' => true,
                'data' => $save,
                'msg' => "File image berhasil di-upload"
            ];
        }
        return $this->response->setJSON($response);
    }

    public function delete($id)
    {
        // dd($id);
        $this->sertModel->delete($id);
        session()->setFlashdata('del', 'Sertifikat berhasil dihapus');
        return redirect()->to(base_url('/sertifikat'));
    }
    public function baca($id)
    {
        if (session()->get('id')) {
            $sertifikat = $this->sertModel->getSertifikat(($id));
            $data = [
                'judul' => 'Baca Data Sertifikat',
                'sertifikat' =>  $sertifikat
            ];
            return view('sertifikat/baca', $data);
        } else
            return redirect()->to('/');
    }


    public function edit($id)
    {
        if (session()->get('id')) {
            $n = 0;
            $taID = $this->taModel->getTAOrderByID(); // Untuk memilih Tenaga Ahli urut berdasarkan ID
            $taName = $this->taModel->getTAOrderByName(); // Untuk memilih Tenaga Ahli urut berdasarkan nama
            $sertifikat = $this->sertModel->getSertifikat();
            foreach ($taName as $val) {
                $nama[$n] = $val['nama'];
                $kode[$n] = $val['kode_ta'];
                $n++;
            }

            $data = [
                'judul' => 'Edit Sertifikat Tenaga Ahli',
                'sertifikat' => $this->sertModel->getSertifikat($id),
                'nama' => $nama,
                'kode' => $kode,
                'validation' => \Config\Services::validation()
            ];
            return view('sertifikat/edit', $data);
        } else
            return redirect()->to('/');
    }

    public function update($id)
    {
        $file = $this->request->getFile('file');

        if ($file != '' && !$file->hasMoved()) {
            $newName = $file->getName();
            $lokasi = "public_html/certificate/" . $newName;
            if (is_file($lokasi)) {
                $this->sertModel->save([  /////////UPDATE//////////////////////////////////
                    'id_sert' => $id,
                    'nomor_sertifikat' => $this->request->getVar('nomor_sertifikat'),
                    'nama_sertifikat' => $this->request->getVar('nama_sertifikat'),
                    'kode_ta' => $this->request->getVar('kode_ta'),
                    'nama_ta' => $this->request->getVar('nama_ta'),
                    'tgl_kadaluarsa' => $this->request->getVar('tgl_kadaluarsa'),
                    'tgl_terbit' => $this->request->getVar('tgl_terbit')
                ]);
            } else {
                $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
                $file->move($PATH . '/certificate');

                $this->sertModel->save([  /////////UPDATE//////////////////////////////////
                    'id_sert' => $id,
                    'nomor_sertifikat' => $this->request->getVar('nomor_sertifikat'),
                    'nama_sertifikat' => $this->request->getVar('nama_sertifikat'),
                    'kode_ta' => $this->request->getVar('kode_ta'),
                    'nama_ta' => $this->request->getVar('nama_ta'),
                    'tgl_kadaluarsa' => $this->request->getVar('tgl_kadaluarsa'),
                    'tgl_terbit' => $this->request->getVar('tgl_terbit'),
                    'namafile' => $newName,
                    'lokasi' => $lokasi
                ]);
            }

            return redirect()->to(base_url('/sertifikat'))->with('sukses-update-srt', 'Data berhasil diupdate');
        }
    }


    public function uploadsrt($id)
    {
        dd($id);
        $file = $this->request->getFile('file');
        if ($file != '' && !$file->hasMoved()) {
            if ($file->getError() === 4) {      //      Jika tidak ada file yang di-upload
                return redirect()->to(base_url('sertifikat/edit'))->with('gagal-upload', 'Tidak ada file yang diupload');     //      
            } else {
                if ($file != '' && !$file->hasMoved()) {
                    $newName = $file->getName();
                    $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
                    $file->move($PATH . '/certificate');
                    //$lokasi = "public_html/certificate/" . $newName;
                }
            }
            return redirect()->to(base_url('/sertifikat'))->with('sukses-upload', 'File berhasil diupload');
        }
    }

    public function certupdl()
    { //  Menyimpan  data baru (memakai ajax)

        helper(['form', 'url']);

        $database = \Config\Database::connect();
        $builder = $database->table('tb_sertifikat');

        $validateImage = $this->validate([
            'file' => [
                'uploaded[file]',
                'mime_in[file, image/png, image/jpg,image/jpeg, image/gif]',
                'max_size[file, 4096]',
            ],
        ]);

        $response = [
            'success' => false,
            'data' => '',
            'msg' => "File image tidak ter-upload"
        ];

        $imageFile = $this->request->getFile('file');
        if ($imageFile != '' && !$imageFile->hasMoved()) {


            $newName = $imageFile->getName();
            //  Ini untuk cloud
            //  $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
            //  $imageFile->move($PATH . '/certificate');
            //  $lokasi = "public_html/certificate/" . $newName;

            $imageFile->move(WRITEPATH . '../public/certificate/', $newName); //   Pindah file ke direktori penyimpanan
            $lokasi = "public/certificate/" . $newName;

            $nomor_sertifikat = $this->request->getVar('nomor_sertifikat');
            $nama_sertifikat = $this->request->getVar('nama_sertifikat');
            $tgl_kadaluarsa = $this->request->getVar('tgl_kadaluarsa');
            $tgl_terbit = $this->request->getVar('tgl_terbit');

            $kode_ta = $this->request->getVar('kode_ta');
            $nama_ta = $this->request->getVar('nama_ta');
            $data = [
                'nomor_sertifikat' => $nomor_sertifikat,
                'nama_sertifikat' => $nama_sertifikat,
                'namafile' => $newName,
                'kode_ta' => $kode_ta,
                'nama_ta' => $nama_ta,
                'lokasi' => $lokasi,
                'tgl_kadaluarsa' => $tgl_kadaluarsa,
                'tgl_terbit' => $tgl_terbit
            ];

            $save = $builder->insert($data);
            $response = [
                'success' => true,
                'data' => $save,
                'msg' => "File image berhasil di-upload"
            ];
        }
        return $this->response->setJSON($response);
    }
}
