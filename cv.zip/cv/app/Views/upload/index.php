<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <center>
                <h1 style="font-weight: bold; font-family: Georgia" ;>Lampiran</h1>
          </center>
          <div class="card-header">
            <div class="btn-group" role="group" aria-label="Basic mixed styles example">
              <a href="/upload/tambah" class=btn btn-primary style="width:120px; background-color:#90e1f5; margin-right: 1em;">
                <i class="fa-solid fa-circle-plus"></i> Tambah</a>
            </div>
          </div>
          <!-- /.card-header -->
          <br>
          <div class="card-body">
            <?php if (session('DelSuccess')) :  ?>
              <div class="alert alert-info" role="alert">
                <?= session('DelSuccess');  //  Delete success 
                ?>
              </div>
            <?php endif; ?>
            <!--Notifikasi berhasil tambah data CV -->
            <?php if (session('AddSuccess')) :  ?>
              <div class="alert alert-success" role="alert">
                <?= session('AddSuccess'); ?>
              </div>
            <?php endif; ?>

            <?php if (session('edit-success')) :  ?>
              <div class="alert alert-info" role="alert">
                <?= session('edit-success');
                ?>
              </div>
            <?php endif; ?>
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th style="text-align:center; width:5%">No.</th>
                  <th style="text-align:center; width:10%">Image</th>
                  <th style="text-align:center; width:25%">Nama File</th>
                  <th style="text-align:center; width:15%">Lokasi</th>
                  <th style="text-align:center; width:10%">Lampiran</th>
                  <th style="text-align:center; width:20%">Nama Tenaga Ahli</th>
                  <th style="text-align:center; width:15%">Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($img) {
                  $no = 1;
                  foreach ($img as $v) {
                    $id = isset($v['id']) ? $v['id'] : '';
                    $lampiran = isset($v['lampiran']) ? $v['lampiran'] : '';
                    $lokasi = isset($v['lokasi']) ? $v['lokasi'] : '';
                    $namafile = isset($v['namafile']) ? $v['namafile'] : '';

                    if ($lokasi != '') {
                      //  Gambar diambilkan dari lokasi dimulai karakter ke 12 (dari 0)
                      //  Karena public/ otomatis merujuk ke public_html > tidak perlu ditulis
                      $gambar = substr($lokasi, 12);
                    }
                    else
                        $gambar = '';
                    $nama_ta = isset($v['nama_ta']) ? $v['nama_ta'] : '';
                    $kode_ta = isset($v['kode_ta']) ? $v['kode_ta'] : '';
                ?>
                    <tr>
                      <td style="width:5%"><?= $no ?></td>
                      <td style="width:10%"><img src="<?= $gambar ?>" width="100px"></td>
                      <td style="width:25%"><?= $namafile; ?></td>
                      <td style="width:15%"><?= $lokasi; ?></td>
                      <td style="width:10%"><?= $lampiran; ?></td>
                      <td style="width:20%;"><?= $nama_ta; ?></td>


                      <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->
                      <td style="width:15%; text-align:center">
                        <a href="/upload/baca/<?= $id; ?>"><i class="fa-solid fa-glasses" title="baca"></i>|
                          <a href="<?= $gambar; ?>" download title="download"><i class="fa-solid fa-download"></i>|
                            <a href="/upload/hapus/<?= $id; ?>" onclick="return confirm('Yakin ingin menghapus lampiran ?')">
                              <i class="fa-solid fa-trash-can" title="hapus"></i>
                      </td>
                      <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->

                    </tr>
                  <?php
                    $no++;
                  } //foreach ($img as $v)
                } else { ?>

                  <tr>
                    <td colspan="5">Tidak ada data(kosong)..........................!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!</td>
                  </tr>
                <?php
                } ?>


              </tbody>

            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<!-- /.content -->

<script>
  function cari_pengalaman() {
    // alert('Hail');
    const v = document.getElementById('names').value;
    if (v != '') {
      let names = document.getElementById('names');
      names.onclick = function(event) {
        var target = event.target;
        var nama = event.target.value;
        window.location.href = "/fNama/" + nama;
      };
    }

  }

  function ShowExperts($id) {
    //      let nama = document.getElementById('#intermitten').innerText;
    window.location.href = "/ExpertsList/" + $id
  }
</script>
<?= $this->endsection(); ?>