<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <!--    
        Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
        Perlu penyesuaian versi bootstrap dari 3.4.1 ke 5.1.3
    -->
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="sweetalert2.min.css">
</head>
<style>
    .currSign:before {
        content: 'Rp. ';
    }

    p {
        font-size: 20px;
        line-height: 1.5;
        margin: 40px auto 0;
        max-width: 640px;
    }

    pre {
        background: #eee;
        border: 1px solid #ccc;
        font-size: 16px;
        padding: 20px;
    }

    .ui-datepicker-calendar {
        display: none;
    }

    .ui-datepicker-month {
        display: none;
    }

    .ui-datepicker-next,
    .ui-datepicker-prev {
        display: none;
    }
</style>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">


                <div class="card">

                    <!-- /.card-header -->
                    <div class="card-body">

                        <?php if (session('gagal-menambah-proyek')) :  ?>
                            <div class="alert alert-danger" role="alert" style="background-color: red;">
                                <?= session('gagal-menambah-proyek');
                                ?>
                            </div>
                        <?php endif; ?>
                        <?php if (session('sukses-tambah-proyek')) :  ?>
                            <div class="alert alert-info" role="alert">
                                <?= session('sukses-tambah-proyek');
                                ?>
                            </div>
                        <?php endif; ?>
                        <?php if (session('sukses-tambah-TA')) :  ?>
                            <div class="alert alert-info" role="alert">
                                <?= session('sukses-tambah-TA');
                                ?>
                            </div>
                        <?php endif; ?>
                        <?php if (session('gagal-tambah-TA')) :  ?>
                            <div class="alert alert-danger" role="alert" style="background-color: red;">
                                <?= session('gagal-tambah-TA');
                                ?>
                            </div>
                        <?php endif; ?>
                        <?php if (session('Tidak_ada_TA_terpilih')) :  ?>
                            <div class="alert alert-danger" role="alert" style="background-color: red;">
                                <?= session('Tidak_ada_TA_terpilih');
                                ?>
                            </div>
                        <?php endif; ?>


                        <div class="panel-body">

                            <center>
                                <h1 style="font-weight: bold; font-family: Georgia" ;>Tambah Proyek Baru</h1>
                            </center>

                            <form action="<?= route_to('/proyek/simpan') ?>" method="post" enctype="multipart/form-data" id="upload_image_form">

                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">Kode Proyek</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="kode_proyek" value="<?= $kode; ?>" readonly>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label for="job" class="col-sm-2 col-form-label">Kegiatan(pekerjaan)</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="pekerjaan" id="job" value="<?= old('kegiatan') ?>" placeholder="Pekerjaan">
                                        <span id="nama_error" class="text-danger"></span>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label for="pengguna" class="col-sm-2 col-form-label">Pengguna(instansi)</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="instansi" id="pengguna" value="<?= old('instansi') ?>" placeholder="Instansi">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">Kode instansi</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="kode_instansi" onclick="isikodeinstansi()" id="kode_instansi" value="<?= old('kode_instansi') ?>">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">Lokasi Kegiatan</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="lokasi" value="<?= old('lokasi') ?>">

                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">Alamat</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="alamat" id="alamat" value="<?= old('alamat') ?>">
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label class="col-sm-2 col-form-label">Mulai</label>
                                    <div class="col-sm-2">
                                        <input type="date" class="form-control" id="tgl_awal" onchange="start()">
                                    </div>
                                    <div class="col-sm-2">
                                        <input type="hidden" class="form-control" name="mulai" id="aw">
                                    </div>
                                    <label class="col-sm-2 col-form-label">Tahun</label>
                                    <div class="col-sm-2 thn">
                                        <input type="text" class="form-control" name="tahun" id="tahun">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">Selesai</label>
                                    <div class="col-sm-2">
                                        <input type="date" class="form-control" id="tgl_akhir" onchange="hitung_intermitten()" />
                                    </div>
                                    <div class="col-sm-2">
                                        <input type="hidden" class="form-control" name="selesai" id="ak">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">Intermitten</label>
                                    <div class="col-sm-6 mx-0">
                                        <input type="text" class="form-control mx-0" name="inter" id="intermitten" style="width:500">
                                    </div>

                                    <label class="col-sm-2 col-form-label">Jumlah Bulan</label>
                                    <div class="col-sm-2">
                                        <input type="text" class="form-control" readonly name="jml_bln" id="jmlbln" value="<?= old('jml_bln') ?>">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">Nomor kontrak</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="nokontrak" value="<?= old('nokontrak') ?>">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">Nilai kontrak</label>
                                    <div class="col-sm-4">
                                        <!-- diambil dari https://codepen.io/akalkhair/pen/dyPaozZ -->
                                        <!-- Memakai JQuery > fungsi formatCurrency dan formatNumber() > pada script di bawah v --->
                                        <input type="text" name="nilaisementara" id="currency-field" pattern="^\Rp\d{1.3}(.\d{3})*(\,\d+)?Rp" data-type="currency" placeholder="Rp 1.000.000,00" onfocusout="formatnilai()" />
                                        <input type="hidden" name="nilai" id="real_nilai">
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Nomor Referensi</label>
                                    <div class="col-sm-6">
                                        <input type="text" class="input-group-text" name="referensi">
                                    </div>
                                </div>

                                <!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/
                                    https://techarise.com/file-upload-with-progress-bar-using-codeigniter-ajax/        -->

                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">Pilih file referensi (pdf)</label>
                                    <input type="file" name="file" multiple="true" style="width: 500px;" class="col-sm-10" accept="application/pdf">
                                    <!-- <button type="submit" class="btn btn-outline-secondary"  style="color:blue">Upload</button>-->
                                </div>

                                <hr>
                                <div class="row align-items-center">
                                    <div class="col">
                                        <div class="progress" style="width:700px; margin-left: 200px;" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                            <div id="file-progress-bar" class="progress-bar"></div>
                                        </div>
                                    </div>
                                </div>
                                <!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/
                                    https://techarise.com/file-upload-with-progress-bar-using-codeigniter-ajax/        -->
                                <div class="modal-footer">
                                    <a href="/proyek" class="btn btn-primary m-2" style="height: 35px; width: 90px">
                                        <i class="fa-solid fa-circle-left"></i></i>Kembali</a>
                                    <button type="submit" class="btn btn-success" id="uploadBtn" onclick="periksa()">Simpan</button>
                                </div>


                                <!-- DAFTAR TENAGA AHLI YANG AKAN DIPILIH--------------------------------------------------------->

                                <table id="tabel" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th style="text-align:center; width:15%">Kode</th>
                                            <th style="text-align:center; width:50%">Tenaga Ahli</th>
                                            <!--https://stackoverflow.com/questions/64996555/insert-multiple-dimension-array-codeigniter-->
                                            <!--    <th><button type="submit" name="PilihTA" value="1" 
                                            style="width: 20px; height: 20px; text-align: center; font-weight: bold; padding: 0 0 0 0" 
                                            class="tombol" title="Simpan kode tenaga ahli"><i class="fa-solid fa-floppy-disk"></i></button> -->
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="bodi">
                                        <?php if ($ta) {
                                            $no = 1;
                                            foreach ($ta as $v => $item) {
                                                $id = isset($item['id']) ? $item['id'] : '';
                                                $kode = isset($item['kode_ta']) ? $item['kode_ta'] : '';
                                                $nama = isset($item['nama']) ? $item['nama'] : '';
                                        ?>
                                                <tr>
                                                    <td style="width:15%"><?= $kode ?></td>
                                                    <td style="width:50%"><?= $nama ?></td>
                                                    <td>
                                                        <!--    Tenaga ahli dipilih melalui ckTA[]    -->
                                                        <input type="checkbox" name="ckTA[]" value="<?= $kode ?>">

                                                        <!--    Posisi dipilih melalui ckPosisi[] -->
                                                        <select class="form-select" style="margin-right: 20px; width: 350px;" name="ckPosisi[]">
                                                            <option selected></option>
                                                            <option value="PO-0001">Team Leader/Ketua Tim/Project Manager/Project Leader</option>
                                                            <option value="PO-0002">Asesor Psikologi/Psikolog</option>
                                                            <option value="PO-0003">Asesor SDM</option>
                                                            <option value="PO-0004">Koordinator Kegiatan Asesmen</option>
                                                            <option value="PO-0005">Psikiater</option>
                                                            <option value="PO-0006">Sistem IT/Administrasi IT/Tenaga Pendukung IT/Operator Komputer</option>
                                                            <option value="PO-0007">Tim Olah Data</option>
                                                            <option value="PO-0008">Host</option>
                                                            <option value="PO-0009">Helpdesk</option>
                                                            <option value="PO-0010">Administrasi</option>
                                                            <option value="PO-0011">Tester</option>
                                                            <option value="PO-0012">Co Tester</option>
                                                            <option value="PO-0013">Tim Support</option>
                                                            <option value="PO-0014">Feedback Giver</option>
                                                            <option value="PO-0015">Psikiater</option>
                                                            <option value="PO-0016">Sistem IT/Administrasi IT/Tenaga Pendukung IT/Operator Komputer</option>
                                                            <option value="PO-0017">Tim Olah Data</option>
                                                            <option value="PO-0018">Host</option>
                                                            <option value="PO-0019">Helpdesk</option>
                                                            <option value="PO-0020">Administrasi</option>
                                                        </select>
                                                    </td>

                                                    <td>

                                                    </td>

                                                </tr>
                                            <?php
                                                $no++;
                                            }
                                        } else { ?>
                                            <tr>
                                                <td colspan="5">Tidak ada data(kosong)..........................!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!</td>
                                            </tr>
                                        <?php
                                        } ?>
                                    </tbody>
                                </table>
                            </form>
                            <!-- </form> -->
                            <!-- END OF DAFTAR TENAGA AHLI YANG AKAN DIPILIH--------------------------------------------------------->

                        </div>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="sweetalert2.all.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(document).ready(function() {
        /*

        <!--    https://techarise.com/demos/ci/file-upload-with-progress-bar-jquery-ajax   -->
        <!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example -->

        */
        $('#upload_image_form').on('submit', function(e) {

            $('#uploadBtn').prop('Disabled');
            e.preventDefault();
            if ($('#tgl_awal').val() == '' || $('#aw').val() == '') {
                //alert("Tanggal awal, akhir dan tahun harus diisi ...!");
                
                let timerInterval
                Swal.fire({
                    title: 'Tanggal awal, akhir dan tahun harus diisi ...!',
                    html: 'Saya akan tertutup dalam <b></b> milli detik.',
                    timer: 10000,
                    timerProgressBar: true,
                    didOpen: () => {
                        Swal.showLoading()
                        const b = Swal.getHtmlContainer().querySelector('b')
                        timerInterval = setInterval(() => {
                            b.textContent = Swal.getTimerLeft()
                        }, 100)
                    },
                    willClose: () => {
                        clearInterval(timerInterval)
                    }
                }).then((result) => {
                    /* Read more about handling dismissals below */
                    if (result.dismiss === Swal.DismissReason.timer) {
                        console.log('I was closed by the timer')
                    }
                })
                $('#uploadBtn').prop('enabled');
                document.getElementById("upload_image_form").reset();
                $('#tahun').focus();
            } else {
                $.ajax({
                    xhr: function() {
                        var xhr = new window.XMLHttpRequest();
                        //  Kemajuan progres bar dihitung di sini
                        xhr.upload.addEventListener("progress", function(element) {
                            if (element.lengthComputable) {
                                var percentComplete = ((element.loaded / element.total) * 100);
                                $("#file-progress-bar").width(percentComplete + '%');
                                $("#file-progress-bar").html(percentComplete + '%');
                            }
                        }, false);
                        return xhr;
                    },
                    url: "simpanproyek",
                    method: "POST",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    cache: false,
                    dataType: "json",

                    beforeSend: function() {
                        $("#file-progress-bar").width('0%');
                        $('#uploadBtn').html('Uploading ...');
                    },
                    success: function(res) {

                        if (res.success == true) {

                            $('#uploadBtn').html('Sukses upload...');
                            $("button#uploadBtn").css("background-color", "green");

                            Swal.fire(
                                'Sweet,....!',
                                res.msg,
                                'success'
                            );

                        } else if (res.success == false) {

                            Swal.fire(
                                'Bad,.....!',
                                res.msg,
                                'error'
                            );
                        }
                        //$('.uploadBtn').html('Upload');
                        $('#uploadBtn').prop('Enabled');
                        document.getElementById("upload_image_form").reset();
                    },

                    complete: function() {
                        $('#uploadBtn').html('Simpan');
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });
            }
        });


    });
</script>

<script>
    function periksa() {

        if (document.getElementById("tgl_awal").value == '') {
            alert("Tanggal awal harus diisi, agar bisa ditampilkan di riwayat hidup");
            document.getElementById("tgl_awal").focus();
        };
        if (document.getElementById("tgl_akhir").value == '') {
            alert("Tanggal akhir harus diisi, agar bisa ditampilkan di riwayat hidup");
            document.getElementById("tgl_akhir").focus();
        };
        if (document.getElementById("tahun").value == '') {
            alert("Tahun harus diisi, agar bisa ditampilkan di riwayat hidup");
            document.getElementById("tahun").focus();
        };
    }
    // autocomplete dari  https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_autocomplete
    function autocomplete(inp, arr) {
        /*the autocomplete function takes two arguments,
        the text field element and an array of possible autocompleted values:*/
        var currentFocus;
        /*execute a function when someone writes in the text field:*/
        inp.addEventListener("input", function(e) {
            var a, b, i, val = this.value;
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!val) {
                return false;
            }
            currentFocus = -1;
            /*create a DIV element that will contain the items (values):*/
            a = document.createElement("DIV");
            a.setAttribute("id", this.id + "autocomplete-list");
            a.setAttribute("class", "autocomplete-items");
            /*append the DIV element as a child of the autocomplete container:*/
            this.parentNode.appendChild(a);
            /*for each item in the array...*/
            for (i = 0; i < arr.length; i++) {
                /*check if the item starts with the same letters as the text field value:*/
                if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                    /*create a DIV element for each matching element:*/
                    b = document.createElement("DIV");
                    /*make the matching letters bold:*/
                    b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                    b.innerHTML += arr[i].substr(val.length);
                    /*insert a input field that will hold the current array item's value:*/
                    b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                    /*execute a function when someone clicks on the item value (DIV element):*/
                    b.addEventListener("click", function(e) {
                        /*insert the value for the autocomplete text field:*/
                        inp.value = this.getElementsByTagName("input")[0].value;
                        /*close the list of autocompleted values,
                        (or any other open lists of autocompleted values:*/
                        closeAllLists();
                    });
                    a.appendChild(b);
                }
            }
        });
        /*execute a function presses a key on the keyboard:*/
        inp.addEventListener("keydown", function(e) {
            var x = document.getElementById(this.id + "autocomplete-list");
            if (x) x = x.getElementsByTagName("div");
            if (e.keyCode == 40) {
                /*If the arrow DOWN key is pressed,
                increase the currentFocus variable:*/
                currentFocus++;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 38) { //up
                /*If the arrow UP key is pressed,
                decrease the currentFocus variable:*/
                currentFocus--;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 13) {
                /*If the ENTER key is pressed, prevent the form from being submitted,*/
                e.preventDefault();
                if (currentFocus > -1) {
                    /*and simulate a click on the "active" item:*/
                    if (x) x[currentFocus].click();
                }
            }
        });

        function addActive(x) {
            /*a function to classify an item as "active":*/
            if (!x) return false;
            /*start by removing the "active" class on all items:*/
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = (x.length - 1);
            /*add class "autocomplete-active":*/
            x[currentFocus].classList.add("autocomplete-active");
        }

        function removeActive(x) {
            /*a function to remove the "active" class from all autocomplete items:*/
            for (var i = 0; i < x.length; i++) {
                x[i].classList.remove("autocomplete-active");
            }
        }

        function closeAllLists(elmnt) {
            /*close all autocomplete lists in the document,
            except the one passed as an argument:*/
            var x = document.getElementsByClassName("autocomplete-items");
            for (var i = 0; i < x.length; i++) {
                if (elmnt != x[i] && elmnt != inp) {
                    x[i].parentNode.removeChild(x[i]);
                }
            }
        }
        /*execute a function when someone clicks in the document:*/
        document.addEventListener("click", function(e) {
            closeAllLists(e.target);
        });
    }

    var nama_instansi = <?php echo json_encode($nama_instansi); ?>;
    var kode_instansi = <?php echo json_encode($kode_instansi); ?>;
    autocomplete(document.getElementById("pengguna"), nama_instansi);

    function isikodeinstansi() {
        //  alert('Hai');
        const pengguna = document.getElementById("pengguna").value; //Ini id dari drop down/ fungsi onclick
        let index = nama_instansi.indexOf(pengguna);
        document.getElementById("kode_instansi").value = kode_instansi[index];
    }
</script>

<script>
    function isiposisi() {
        var posisi = document.getElementById("posdrop").value;
        if (posisi != 'Pilih posisi') {
            document.getElementById("pos").value = posisi;
        }
    }

    function formatnilai() {
        nilai = document.getElementById('currency-field').value;
        nilai = nilai.replace(",00", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace("Rp", "");
        document.getElementById('real_nilai').value = nilai;
    }
</script>

<script>
    /*  ########## JQuery memakai Google CDN (ada di dashboard-layout.php) ######## */
    $("input[data-type='currency']").on({
        keyup: function() {
            // alert('Hai');
            formatCurrency($(this));
        },
        blur: function() {
            formatCurrency($(this), "blur");
        }
    });

    function formatNumber(n) {
        // format number 1000000 to 1.234.567
        return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ".")
    }


    function formatCurrency(input, blur) {
        //  alert('Hai');
        // appends $ to value, validates decimal side
        // and puts cursor back in right position.

        // get input value
        var input_val = input.val();

        // don't validate empty input
        if (input_val === "") {
            return;
        }

        // original length
        var original_len = input_val.length;

        // initial caret position 
        var caret_pos = input.prop("selectionStart");

        // check for decimal
        if (input_val.indexOf(",") >= 0) {

            // get position of first decimal
            // this prevents multiple decimals from
            // being entered
            var decimal_pos = input_val.indexOf(",");

            // split number by decimal point
            var left_side = input_val.substring(0, decimal_pos);
            var right_side = input_val.substring(decimal_pos);

            // add commas to left side of number
            left_side = formatNumber(left_side);

            // validate right side
            right_side = formatNumber(right_side);

            // On blur make sure 2 numbers after decimal
            if (blur === "blur") {
                right_side += "00";
            }

            // Limit decimal to only 2 digits
            right_side = right_side.substring(0, 2);

            // join number by .
            input_val = "Rp" + left_side + "," + right_side;

        } else {
            // no decimal entered
            // add commas to number
            // remove all non-digits
            input_val = formatNumber(input_val);
            input_val = "Rp" + input_val;

            // final formatting
            if (blur === "blur") {
                input_val += ",00";
            }
        }

        // send updated string to input
        input.val(input_val);

        // put caret back in the right position
        var updated_len = input_val.length;
        caret_pos = updated_len - original_len + caret_pos;
        input[0].setSelectionRange(caret_pos, caret_pos);
    }
</script>


<script>
    function start() {
        const tglawal = new Date(document.getElementById('tgl_awal').value);
        let tahuntglawal = tglawal.getFullYear();
        let bulantglaw = tglawal.getMonth() + 1; // Months start at 0
        let haritglaw = tglawal.getDate();
        let tgl = tahuntglawal + '-' + bulantglaw + '-' + haritglaw;
        document.getElementById('aw').value = tgl;
        document.getElementById("tahun").value = tahuntglawal;
    }

    function hitung_intermitten() {
        let awal = document.getElementById('tgl_awal').value;
        if (awal != "") {
            const tglawal = new Date(document.getElementById('tgl_awal').value);
            const tglakhir = new Date(document.getElementById('tgl_akhir').value);
            let time_difference = tglakhir.getTime() - tglawal.getTime();
            let Years_difference = 0;
            let SisaBulan = 0;
            let SisaHari = 0;
            let JmlBln = 0;
            var inter = "( ";
            //calculate days difference by dividing total milliseconds in a day  
            let days_difference = time_difference / (1000 * 60 * 60 * 24);
            let Months_difference = Math.floor(days_difference / 30);
            console.log(Months_difference.toString());
            if (Months_difference > 12) {
                Years_difference = Math.floor(Months_difference / 12);
                SisaBulan = Months_difference % 12;
                SisaHari = days_difference - ((Years_difference * 360) + (SisaBulan * 30));
                inter += Years_difference + " tahun ";
                inter += SisaBulan + " bulan ";
                inter += SisaHari + " hari ";
                if (SisaHari > 0) {
                    JmlBln = SisaBulan + 1;
                } else {
                    JmlBln = SisaBulan;
                }
            } else if (Months_difference > 0) {
                SisaHari = days_difference % 30;
                inter += Months_difference + " bulan ";
                inter += SisaHari + " hari ";
                if (SisaHari > 0) {
                    JmlBln = Months_difference + 1;
                } else {
                    JmlBln = Months_difference;
                }
            } else {
                inter += days_difference + " hari ";
                JmlBln = 1;
            }
            inter += " )";
            let tahuntglakhir = tglakhir.getFullYear();
            let bulantglakhir = tglakhir.getMonth() + 1; // Months start at 0
            let haritglakhir = tglakhir.getDate();
            let tglSelesai = tahuntglakhir + '-' + bulantglakhir + '-' + haritglakhir;
            document.getElementById('ak').value = tglSelesai;
            document.getElementById('intermitten').value = inter;
            document.getElementById('jmlbln').value = JmlBln;
        }
    }

    function IsiNama() {
        const sel = document.getElementById("ta_ID");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("Nama_Personil").value = teks;
    }

    function IsiID() {
        let ta = document.getElementById('ta_ID').value;
        const sel = document.getElementById("ta_ID");
        sel.options[sel.selectedIndex].text = ta;
    }

    function tambah() {
        var sel = document.getElementById("proj");
        var teks = sel.options[sel.selectedIndex].text;
        document.getElementById("aktifitas").value = teks;
        let vproject = document.getElementById("proj").value;
    }
</script>
<?= $this->endsection(); ?>