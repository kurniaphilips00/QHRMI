<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <!--    
        Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
        Perlu penyesuaian versi bootstrap dari 3.4.1 ke 5.1.3
    -->
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="sweetalert2.min.css">
</head>
<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">


                <div class="card">


                    <center>
                        <h1 style="font-weight: bold; font-family: Georgia" ;>Edit Proyek</h1>
                    </center>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <form action="<?= route_to('/proyek/edit/', $proyek['id']) ?>" method="post" enctype="multipart/form-data" id="frmEdit">


                            <input type="hidden" name="id" id="TxtID" value="<?= $proyek['id'] ?>">

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode proyek</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $proyek['kode_proyek'] ?>" readonly>
                                </div>
                            </div>


                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kegiatan(pekerjaan)</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="pekerjaan" value="<?= $proyek['pekerjaan'] ?>" placeholder="Pekerjaan">

                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Pengguna(instansi)</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="instansi" id="pengguna" value="<?= $proyek['instansi'] ?>">
                                </div>
                            </div>



                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Lokasi Kegiatan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="lokasi" value="<?= $proyek['lokasi'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Alamat</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="alamat" id="alamat" value="<?= $proyek['alamat'] ?>">
                                </div>
                            </div>

                            <div class="mb-1 row">

                                <?php

                                $mulai = isset($proyek['mulai']) ? $proyek['mulai'] : '';

                                $selesai = isset($proyek['selesai']) ? $proyek['selesai'] : '';
                                if ($mulai != null && $mulai != '0000-00-00') {
                                    $tgl = new DateTime($mulai);
                                    $tgl_mulai = $tgl->format('d-m-Y'); //  Menampilkan format Indo

                                } else {
                                    $tgl_mulai = '00';
                                }
                                if ($selesai != null &&  $selesai != '0000-00-00') {
                                    $tgl = new DateTime($selesai);
                                    $tgl_selesai = $tgl->format('d-m-Y'); //  Menampilkan format Indo

                                } else {
                                    $tgl_selesai = '00';
                                }

                                ?>
                                <label class="col-sm-2 col-form-label">Waktu Pelaksanaan</label>
                                <div class="col-sm-2">
                                    <input style="width:156px" type="text" class="form-control-plaintext" value="<?= $tgl_mulai; ?>" readonly>
                                </div>
                                <label style="font-weight:500px" class="col-sm-1">s/d</label>
                                <div class="col-sm-2">
                                    <input type="text" style="width:145px;" class="col-sm-1" value="<?= $tgl_selesai; ?>" readonly>
                                </div>

                            </div>


                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Mulai</label>
                                <div class="col-sm-2">
                                    <input type="date" class="form-control" value="<?= $mulai ?>" id="tgl_awal" onchange="start()">
                                </div>
                                <div class="col-sm-2">
                                    <input type="hidden" class="form-control" name="mulai" id="aw" value="<?= $mulai ?>">
                                </div>

                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Selesai</label>
                                <div class="col-sm-2">
                                    <input type="date" class="form-control" id="tgl_akhir" value="<?= $selesai ?>" onchange="hitung_intermitten()" />
                                </div>
                                <div class="col-sm-2">
                                    <input type="hidden" class="form-control" name="selesai" id="ak" value="<?= $selesai ?>">
                                </div>

                                <label for="tahun" class="col-sm-2 col-form-label">Tahun</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" name="tahun" id="tahun" value="<?= $proyek['tahun'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Intermitten</label>
                                <div class="col-sm-5 mx-0">
                                    <input type="text" class="form-control mx-0" name="inter" id="intermitten" value="<?= $proyek['inter'] ?>" style="width:500">
                                </div>

                                <label class="col-sm-2 col-form-label">Jumlah Bulan</label>
                                <div class="col-sm-1">
                                    <input type="text" class="form-control" name="jml_bln" id="jmlbln" value="<?= $proyek['jml_bln'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nomor kontrak</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="nokontrak" value="<?= $proyek['nokontrak'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nilai kontrak</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="nilai" value="<?= $proyek['nilai'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nomor Referensi</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="referensi" value="<?= $proyek['referensi'] ?>">
                                </div>
                            </div>


                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Surat Referensi</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="surat_referensi" value="<?= $proyek['surat_referensi'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-3">Pilih file referensi (pdf)</label>
                                <input type="file" name="file" multiple="true" id="finput" style="width: 500px;" class="col-sm-9" accept="application/pdf">
                            </div>

                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="width:700px; margin-left: 210px;" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                        <div id="file-progress-bar" class="progress-bar"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="modal-footer">
                                <a href="/proyek" class="btn btn-primary m-2" style="height: 35px; width: 90px">
                                    <i class="fa-solid fa-circle-left"></i></i>Kembali</a>
                                <button type="submit" id="btnUpdate" class="btn btn-success">Simpan</button>
                            </div>

                        </form>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="sweetalert2.all.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(document).ready(function() {
        /*          <!--    https://techarise.com/demos/ci/file-upload-with-progress-bar-jquery-ajax   -->
                    <!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example -->        */
        $('#frmEdit').on('submit', function(e) {
            $('#btnUpdate').prop('Disabled');
            e.preventDefault();

            id = $('#TxtID').val();
            if ($('#finput').val() != '') {
                $.ajax({
                    xhr: function() {
                        var xhr = new window.XMLHttpRequest();
                        //  Kemajuan progres bar dihitung di sini
                        xhr.upload.addEventListener("progress", function(element) {
                            if (element.lengthComputable) {
                                var percentComplete = ((element.loaded / element.total) * 100);
                                $("#file-progress-bar").width(percentComplete + '%');
                                $("#file-progress-bar").html(percentComplete + '%');
                            }
                        }, false);
                        return xhr;
                    },
                    url: "updateproyek",
                    method: "POST",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    cache: false,
                    dataType: "json",
                    beforeSend: function() {
                        $("#file-progress-bar").width('0%');
                        $('#btnUpdate').html('Uploading ...');
                    },
                    success: function(res) {
                        if (res.success == true) {
                            $('#btnUpdate').html('Sukses upload...');
                            $("button#btnUpdate").css("background-color", "green");

                            Swal.fire(
                                'Sweet,....!',
                                res.msg,
                                'success'
                            );

                        } else if (res.success == false) {

                            Swal.fire(
                                'Bad,.....!',
                                res.msg,
                                'error'
                            );
                        }
                        //$('.btnUpdate').html('Upload');
                        $('#btnUpdate').prop('Enabled');
                        document.getElementById("frmEdit").reset();
                    },

                    complete: function() {
                        $('#btnUpdate').html('Simpan');
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });
            } else {
                //  Tidak ada file yang di-upload
                $.ajax({


                    url: "updateproyek",
                    method: "POST",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    cache: false,
                    dataType: "json",
                    success: function(res) {

                        if (res.success == true) {

                            $('#btnUpdate').html('Sukses menyimpan data...');
                            $("button#btnUpdate").css("background-color", "green");

                            Swal.fire(
                                'Sweet,....!',
                                res.msg,
                                'success'
                            );

                        } else if (res.success == false) {

                            Swal.fire(
                                'Bad,.....!',
                                res.msg,
                                'error'
                            );
                        }
                        //$('.btnUpdate').html('Upload');
                        $('#btnUpdate').prop('Enabled');
                        document.getElementById("frmEdit").reset();
                    },

                    complete: function() {
                        $('#btnUpdate').html('Simpan');
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });

            }

        });
    });
</script>
<script>
    function periksa() {

        if (document.getElementById("tgl_awal").value == '') {
            alert("Tanggal awal harus diisi, agar bisa ditampilkan di riwayat hidup");
            document.getElementById("tgl_awal").focus();
        };
        if (document.getElementById("tgl_akhir").value == '') {
            alert("Tanggal akhir harus diisi, agar bisa ditampilkan di riwayat hidup");
            document.getElementById("tgl_akhir").focus();
        };
        if (document.getElementById("tahun").value == '') {
            alert("Tahun harus diisi, agar bisa ditampilkan di riwayat hidup");
            document.getElementById("tahun").focus();
        };
    }
    // autocomplete dari  https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_autocomplete
    function autocomplete(inp, arr) {
        /*the autocomplete function takes two arguments,
        the text field element and an array of possible autocompleted values:*/
        var currentFocus;
        /*execute a function when someone writes in the text field:*/
        inp.addEventListener("input", function(e) {
            var a, b, i, val = this.value;
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!val) {
                return false;
            }
            currentFocus = -1;
            /*create a DIV element that will contain the items (values):*/
            a = document.createElement("DIV");
            a.setAttribute("id", this.id + "autocomplete-list");
            a.setAttribute("class", "autocomplete-items");
            /*append the DIV element as a child of the autocomplete container:*/
            this.parentNode.appendChild(a);
            /*for each item in the array...*/
            for (i = 0; i < arr.length; i++) {
                /*check if the item starts with the same letters as the text field value:*/
                if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                    /*create a DIV element for each matching element:*/
                    b = document.createElement("DIV");
                    /*make the matching letters bold:*/
                    b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                    b.innerHTML += arr[i].substr(val.length);
                    /*insert a input field that will hold the current array item's value:*/
                    b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                    /*execute a function when someone clicks on the item value (DIV element):*/
                    b.addEventListener("click", function(e) {
                        /*insert the value for the autocomplete text field:*/
                        inp.value = this.getElementsByTagName("input")[0].value;
                        /*close the list of autocompleted values,
                        (or any other open lists of autocompleted values:*/
                        closeAllLists();
                    });
                    a.appendChild(b);
                }
            }
        });
        /*execute a function presses a key on the keyboard:*/
        inp.addEventListener("keydown", function(e) {
            var x = document.getElementById(this.id + "autocomplete-list");
            if (x) x = x.getElementsByTagName("div");
            if (e.keyCode == 40) {
                /*If the arrow DOWN key is pressed,
                increase the currentFocus variable:*/
                currentFocus++;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 38) { //up
                /*If the arrow UP key is pressed,
                decrease the currentFocus variable:*/
                currentFocus--;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 13) {
                /*If the ENTER key is pressed, prevent the form from being submitted,*/
                e.preventDefault();
                if (currentFocus > -1) {
                    /*and simulate a click on the "active" item:*/
                    if (x) x[currentFocus].click();
                }
            }
        });

        function addActive(x) {
            /*a function to classify an item as "active":*/
            if (!x) return false;
            /*start by removing the "active" class on all items:*/
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = (x.length - 1);
            /*add class "autocomplete-active":*/
            x[currentFocus].classList.add("autocomplete-active");
        }

        function removeActive(x) {
            /*a function to remove the "active" class from all autocomplete items:*/
            for (var i = 0; i < x.length; i++) {
                x[i].classList.remove("autocomplete-active");
            }
        }

        function closeAllLists(elmnt) {
            /*close all autocomplete lists in the document,
            except the one passed as an argument:*/
            var x = document.getElementsByClassName("autocomplete-items");
            for (var i = 0; i < x.length; i++) {
                if (elmnt != x[i] && elmnt != inp) {
                    x[i].parentNode.removeChild(x[i]);
                }
            }
        }
        /*execute a function when someone clicks in the document:*/
        document.addEventListener("click", function(e) {
            closeAllLists(e.target);
        });
    }

    var nama_instansi = <?php echo json_encode($nama_instansi); ?>;
    var kode_pengguna = <?php echo json_encode($kode_pengguna); ?>;
    autocomplete(document.getElementById("pengguna"), nama_instansi);

    function isikodeinstansi() {
        //  alert('Hai');
        const pengguna = document.getElementById("pengguna").value; //Ini id dari drop down/ fungsi onclick
        let index = nama_instansi.indexOf(pengguna);
        document.getElementById("kode_inst").value = kode_pengguna[index];
    }
</script>

<script>
    // Filter diambil dari  https://dev.to/faddalibrahim/filtering-and-validating-file-uploads-with-javascript-327p
    document.getElementById("file").addEventListener("change", validateFile)

    function validateFile() {
        const allowedExtensions = ['pdf'], //  png diganti pdf
            sizeLimit = 1_000_000; // 1 megabyte

        // destructuring file name and size from file object
        const {
            name: fileName,
            size: fileSize
        } = this.files[0];

        /*
         * if filename is apple.png, we split the string to get ["apple","png"]
         * then apply the pop() method to return the file extension
         *
         */
        const fileExtension = fileName.split(".").pop();

        /* 
            check if the extension of the uploaded file is included 
            in our array of allowed file extensions
        */
        if (!allowedExtensions.includes(fileExtension)) {
            alert("Tipe file bukan pdf");
            this.value = null;
        } else if (fileSize > sizeLimit) {
            alert("Ukuran file terlalu besar")
            this.value = null;
        }
    }
</script>


<script>
    function ShowExperts($id) {
        //      let nama = document.getElementById('#intermitten').innerText;
        window.location.href = "/ExpertsList/" + $id
    }

    function start() {
        const tglawal = new Date(document.getElementById('tgl_awal').value);
        let tahuntglawal = tglawal.getFullYear();
        let bulantglaw = tglawal.getMonth() + 1; // Months start at 0
        let haritglaw = tglawal.getDate();
        let tgl = tahuntglawal + '-' + bulantglaw + '-' + haritglaw;
        document.getElementById('aw').value = tgl;
        document.getElementById('tahun').value = tahuntglawal;
    }

    function hitung_intermitten() {
        let awal = document.getElementById('tgl_awal').value;
        if (awal != "") {
            const tglawal = new Date(document.getElementById('tgl_awal').value);
            const tglakhir = new Date(document.getElementById('tgl_akhir').value);
            let time_difference = tglakhir.getTime() - tglawal.getTime();
            let Years_difference = 0;
            let SisaBulan = 0;
            let SisaHari = 0;
            var inter = "( ";
            //calculate days difference by dividing total milliseconds in a day  
            let days_difference = time_difference / (1000 * 60 * 60 * 24);
            let Months_difference = Math.floor(days_difference / 30);
            console.log(Months_difference.toString());
            if (Months_difference > 12) {
                Years_difference = Math.floor(Months_difference / 12);
                SisaBulan = Months_difference % 12;
                SisaHari = days_difference - ((Years_difference * 360) + (SisaBulan * 30));
                inter += Years_difference + " tahun ";
                inter += SisaBulan + " bulan ";
                inter += SisaHari + " hari ";
            } else if (Months_difference > 0) {
                SisaHari = days_difference % 30;
                inter += Months_difference + " bulan ";
                inter += SisaHari + " hari ";
            } else {
                inter += days_difference + " hari ";
            }
            inter += " )";
            let tahuntglakhir = tglakhir.getFullYear();
            let bulantglakhir = tglakhir.getMonth() + 1; // Months start at 0
            let haritglakhir = tglakhir.getDate();
            let tglSelesai = tahuntglakhir + '-' + bulantglakhir + '-' + haritglakhir;
            document.getElementById('ak').value = tglSelesai;
            document.getElementById('intermitten').value = inter;
            document.getElementById('jmlbln').value = Months_difference;
        }
    }

    function IsiNama() {
        const sel = document.getElementById("ta_ID");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("Nama_Personil").value = teks;
    }

    function IsiID() {

        let ta = document.getElementById('ta_ID').value;
        const sel = document.getElementById("ta_ID");
        sel.options[sel.selectedIndex].text = ta;
    }

    function tambah() {
        var sel = document.getElementById("proj");
        var teks = sel.options[sel.selectedIndex].text;
        document.getElementById("aktifitas").value = teks;
        let vproject = document.getElementById("proj").value;
    }
</script>
<?= $this->endsection(); ?>