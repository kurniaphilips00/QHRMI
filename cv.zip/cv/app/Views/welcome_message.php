<!DOCTYPE html>
<html lang="en">
<!-- 
    Ini layar yang pertama kali muncul, sebelum login
    Setelah berhasil login, user akan dibawa ke layar dashboard 
-->
<!--**********************************************************************************
 * Perbedaan online dan offline (localhost) pada  
 * $PATH = getcwd(); untuk online
 * sedangkan localhost memakai
 * $imageFile->move(WRITEPATH . '../public/uploads', $newName); 
 * 
 ***********************************************************************************
-->
<head>
    <meta charset="UTF-8">
    <title>Welcome to PT. Quantum HRMI</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/jpg" href="../img/logo.jpg" />
    <!-- CodeIgniter v4.3.6.....next project :
    anomali (Anil's Not Ordinary Management Application Libraries Implementation) 
    -->

    <style>
        .bkg {
            background-image: url('../q.jpg');
        }
    </style>
</head>

<body class="bkg">
    <!-- Masuk ke layar login -->
    <p><a href="login" style="color: white;">Login</a></p>
</body>

</html>