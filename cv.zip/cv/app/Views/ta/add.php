<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <link rel="stylesheet" href="sweetalert2.min.css">
</head>
<style>
    .no_edit {
        border-radius: 5px;
        background-color: #1dbcdb;
        color: white;
        width: 700px;
        height: 40px;
        font-family: "Times New Roman", Times, serif;
        font-weight: bold;
        color: black;
    }
    .biasa {
        border-radius: 5px;
        background-color: #1659c4;
        color: white;
        width: 700px;
        height: 40px;
    }
    .daftar {
        border-radius: 5px;
        background-color: purple;
        color: white;
        width: 700px;
        height: 40px;
    }
    .daftar_pendek {
        border-radius: 5px;
        background-color: purple;
        color: white;
        width: 400px;
        height: 40px;
    }
    input:invalid {
        border: double;
        border: red solid 3px;
    }
    .tanggal {
        border-radius: 5px;
        background-color: #1659c4;
        color: white;
        width: 150px;
        height: 40px;
    }
    .pendek {
        border-radius: 5px;
        background-color: #1659c4;
        color: white;
        width: 415px;
        height: 40px;
        margin-right: 10px;
    }
</style>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <center>
                            <h1 style="font-weight: bold; font-family: Georgia" ;>Tambah Tenaga Ahli</h1>
                        </center>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <?php if (session('bukan-pdf')) :  ?>
                            <div class="alert alert-danger" role="alert">
                                <?= session('bukan-pdf');
                                ?>
                            </div>
                        <?php endif; ?>

                        <?php if (session('add-failed')) :  ?>
                            <div class="alert alert-danger" role="alert">
                                <?= session('add-failed');
                                ?>
                            </div>
                        <?php endif; ?>
                        <?php if (session('add-success')) :  ?>
                            <div class="alert alert-info" role="alert">
                                <?= session('add-success');
                                ?>
                            </div>
                        <?php endif; ?>
                        <form action="<?= route_to('/ta/tambah') ?>" method="post" enctype="multipart/form-data" id="upload_image_form">
                            <?= csrf_field(); ?>
                            <div class="mb-1 row">
                                <label class="col-sm-3 col-form-label">Kode </label>
                                <div class="col-sm-8">
                                    <input type="text" class="no_edit" name="kode_ta" value="<?= $kode; ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="perusahaan" class="col-sm-3 col-form-label">Nama Perusahaan</label>
                                <div class="col-sm-8">
                                    <input type="text" class="no_edit" name="perusahaan" value="PT. Quantum HRM Internasional" readonly>
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label for="nama" class="col-sm-3 col-form-label">Nama Personil</label>
                                <div class="col-sm-8">
                                    <input type="text" class="biasa" name="nama" id="nama" placeholder="Nama Personil">
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-3 col-form-label">Posisi</label>
                                <div class="col-sm-8">
                                    <select class="form-control daftar" id="pos" name="position">
                                        <option value="">Pilih posisi</option>
                                        <?php foreach ($posisi as $val) : ?>
                                            <option value="<?= $val['posisitugas'] ?>"> <?= $val['posisitugas'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-3">Kategori</label>
                                <div class="col-sm-8">
                                    <select class="form-control daftar" name="kategori">
                                        <option value="">Pilih kategori</option>
                                        <?php foreach ($kategori as $val) : ?>
                                            <option value="<?= $val['kategori'] ?>"> <?= $val['kategori'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="tgl" class="col-sm-3 col-form-label">Tgl. lahir</label>
                                <div class="col-sm-2">
                                    <input type="date" class="tanggal" name="new_ttl" id="new_tgl_lahir" onchange="tampil()" />
                                </div>
                                <div class="col-sm-2">
                                    <input type="hidden" class="form-control" name="tgl_lahir" id="MySQL_tgl" />
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="alamat" class="col-sm-3">Alamat</label>
                                <div class="col-sm-5">
                                    <input type="text" class="biasa" name="alamat" id="alamat" value="<?= old('alamat') ?>" placeholder="Alamat">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                   <!--Memakai autocomplete dari  https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_autocomplete-->
                                   <label for="kota" class="col-sm-3">Kota</label>
                                <div class="col-sm-5">
                                    <input type="text" name="kota" id="City" style="width:200px" value="<?= old('kota') ?>" placeholder="Kota">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-3">No. KTP</label>
                                <div class="col-sm-5">
                                    <input class="pendek" type="number" pattern="[0-9]" minlength="15"
                                            name="no_ktp" id="KTP" placeholder="KTP" onchange="MinKTPLength()">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-3">No. telp</label>
                                <div class="col-sm-5">
                                    <input class="pendek" type="number" pattern="[0-9]" minlength="10" class="form-control" name="no_telp" id="No_Telp" value="<?= old('no_telp') ?>" onchange="MinTelpLength()" placeholder="Telp">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-3">No. HP</label>
                                <div class="col-sm-5">
                                    <input class="pendek" type="number" pattern="[0-9]" minlength="10" class="form-control" name="no_hp" id="No_HP" placeholder="HP" onchange="MinHPLength()">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-3">No. NPWP</label>
                                <label class="col-sm-9">
                                    <input name="no_npwp1" type="tel" pattern="[0-9]{2}" placeholder="__" aria-label="2-digit nomor" size="1" />
                                    .<input name="no_npwp2" pattern="[0-9]{3}" placeholder="___" aria-label="3-digit nomor" size="2" />.<input name="no_npwp3" pattern="[0-9]{3}" placeholder="___" aria-label="3-digit nomor" size="3" />-<input name="no_npwp4" pattern="[0-9]{1}" placeholder="_" aria-label="1-digit nomor" size="1" />.<input name="no_npwp5" pattern="[0-9]{3}" placeholder="___" aria-label="3-digit nomor" size="3" />.<input name="no_npwp6" pattern="[0-9]{3}" placeholder="___" aria-label="3-digit nomor" size="3" />( contoh format : 12.456.789-1.234.123 )
                                </label>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-3">e-mail</label>
                                <div class="col-sm-5">
                                    <input class="pendek" type="email" id="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">
                                </div>
                                
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-3" id="sipp">Nomor SIPP</label>
                                <div class="col-sm-9">
                                    <input type="text" class="pendek" name="sipp">
                                    <label style="margin-right: 20px" class="input-group-text" id="sipp_ed">Tgl. kadaluarsa</label>
                                    <input type="date" class="tanggal" id="Tgl_SIPP" onchange="Ubah_SIPP_ED()" />
                                    <input type="hidden" class="input-group-text" name="sipp_ed" id="sipp_ed_ID">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-3" id="str">Nomor STR</label>
                                <div class="col-sm-9">
                                    <input type="text" class="pendek" name="str">
                                    <label style="margin-right: 20px" class="input-group-text" id="str_ed">Tgl. kadaluarsa</label>
                                    <input type="date" class="tanggal" id="Tgl_STR" onchange="Ubah_STR_ED()" />
                                    <input type="hidden" class="input-group-text" name="str_ed" id="str_ed_ID">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-3" id="kta">Nomor KTA</label>
                                <div class="col-sm-9">
                                    <input type="text" class="pendek" name="kta">
                                    <label style="margin-right: 20px" class="input-group-text" id="kta_ed">Tgl. kadaluarsa</label>
                                    <input type="date" class="tanggal" id="Tgl_KTA" onchange="Ubah_KTA_ED()"/>
                                    <input type="hidden" class="input-group-text" name="kta_ed" id="kta_ed_ID">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-3">Asosiasi</label>
                                <div class="col-sm-9">
                                    <select class="daftar_pendek" name="asosiasi">
                                        <option selected>Pilih Asosiasi</option>
                                        <option value="Asosiasi Psikologi Industri dan Organisasi (APIO)">Asosiasi Psikologi Industri dan Organisasi (APIO)</option>
                                        <option value="Himpunan Psikologi Indonesia (HIMPSI)">Himpunan Psikologi Indonesia (HIMPSI)</option>
                                        <option value="Asosiasi Psikologi Forensik(APSIFOR)">Asosiasi Psikologi Forensik(APSIFOR)</option>
                                        <option value="Ikatan Psikolog Klinis(IPK)">Ikatan Psikolog Klinis(IPK)</option>
                                        <option value="IIkatan Psikologi Pendidikan Indonesia(IPPI)">Ikatan Psikologi Pendidikan Indonesia(IPPI)</option>
                                    </select>
                                    <label  style="margin-left: 25px; margin-right: 20px" class="input-group-text">Tgl. kadaluarsa</label>
                                    <input type="date" class="tanggal" id="Tgl_Asosiasi" onchange="Fill_Asosiasi_ED()" />
                                    <input type="hidden" class="input-group-text" name="asosiasi_ed" id="id_asosiasi_ed">
                                </div>
                            </div>
                            <br>
                            <div class="mb-3 row">
                                <label class="col-sm-3">Status Kepegawaian</label>
                                <div class="col-sm-9">
                                    <select class="daftar_pendek" name="status_kepegawaian">
                                        <option selected>Pilih status</option>
                                        <option value="Tetap">Tetap</option>
                                        <option value="Tidak Tetap">Tidak Tetap</option>
                                    </select>
                                </div>
                            </div>
                            <br>

                            <!--        
                                https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/
                                https://techarise.com/file-upload-with-progress-bar-using-codeigniter-ajax/        
                            -->

                            <div class="mb-3 row">
                                <label class="col-sm-3">Pilih file referensi (pdf)</label>
                                <input type="file" name="file" multiple="true" style="width: 500px;" class="col-sm-9" accept="application/pdf">
                                <!-- <button type="submit" class="btn btn-outline-secondary"  style="color:blue">Upload</button>-->
                            </div>

                            <hr>
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="width:500px; margin-left: 300px;">
                                        <div id="file-progress-bar" class="progress-bar"></div>
                                    </div>
                                </div>
                            </div>
                            <!--        
                                https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/
                                https://techarise.com/file-upload-with-progress-bar-using-codeigniter-ajax/        
                            -->

                            <div class="modal-footer">
                                <a href="/ta" class="btn btn-primary m-2" style="height: 35px; width: 90px">
                                    <i class="fa-solid fa-circle-left"></i></i>Kembali</a>
                                <button id="uploadBtn" type="submit" class="btn btn-success">Simpan</button>
                            </div>
                        </form>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="sweetalert2.all.min.js"></script>


<!--    https://techarise.com/demos/ci/file-upload-with-progress-bar-jquery-ajax   -->
<!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $('#upload_image_form').on('submit', function(e) {
            $('#uploadBtn').html('Sedang menyimpan ...');
            $('#uploadBtn').prop('Disabled');
            e.preventDefault();

            if ($('#nama').val() == '') {
                //  START OF Peringatan (validasi) oleh SWAL

                Swal.fire({
                    title: 'OOoooops !',
                    text: 'Nama harus diisi ..... !',
                    imageUrl: '/img/angryb.png',
                    imageWidth: 400,
                    imageHeight: 350,
                    imageAlt: 'Custom image',
                })

                //  END OF Peringatan (validasi) oleh SWAL

                $('#uploadBtn').html('Simpan');
                $('#uploadBtn').prop('enabled');
                $('#nama').focus();
                document.getElementById("upload_image_form").reset();
            } else {

                $.ajax({

                    xhr: function() {
                        var xhr = new window.XMLHttpRequest();
                        //  Kemajuan progres bar dihitung di sini
                        xhr.upload.addEventListener("progress", function(element) {
                            if (element.lengthComputable) {
                                var percentComplete = ((element.loaded / element.total) * 100);
                                $("#file-progress-bar").width(percentComplete + '%');
                                $("#file-progress-bar").html(percentComplete + '%');
                            }
                        }, false);
                        return xhr;
                    },
                    url: "uploadrefta",
                    method: "POST",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    cache: false,
                    dataType: "json",

                    beforeSend: function() {
                        $("#file-progress-bar").width('0%');
                    },
                    success: function(res) {
                        //   console.log(res.success);
                        // alert(res);
                        if (res.success == true) {

                            Swal.fire(
                                'Sweet,....!',
                                res.msg,
                                'success'
                            );
                            $('#uploadBtn').html('Sedang menyimpan...');
                            $("button#uploadBtn").css("background-color", "yellow");
                        } else if (res.success == false) {
                            Swal.fire(
                                'OOoooops,....!',
                                res.msg,
                                'error'
                            );
                        }
                        $('.uploadBtn').html('Simpan');
                        $('#uploadBtn').prop('Enabled');
                        document.getElementById("upload_image_form").reset();
                    },
                    complete: function() {
                        $('#uploadBtn').html('Simpan');
                        $("button#uploadBtn").css("background-color", "green");
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });
            } //  if ($('#nama').val() == '')
        });
    });
</script>

<script>
    // Filter diambil dari  https://dev.to/faddalibrahim/filtering-and-validating-file-uploads-with-javascript-327p
    document.getElementById("file").addEventListener("change", validateFile)

    function validateFile() {
        const allowedExtensions = ['pdf'], //  png diganti pdf
            sizeLimit = 1_000_000; // 1 megabyte

        // destructuring file name and size from file object
        const {
            name: fileName,
            size: fileSize
        } = this.files[0];

        /*
         * if filename is apple.png, we split the string to get ["apple","png"]
         * then apply the pop() method to return the file extension
         *
         */
        const fileExtension = fileName.split(".").pop();

        /* 
            check if the extension of the uploaded file is included 
            in our array of allowed file extensions
        */
        if (!allowedExtensions.includes(fileExtension)) {
            alert("Tipe file bukan pdf");
            this.value = null;
        } else if (fileSize > sizeLimit) {
            alert("Ukuran file terlalu besar")
            this.value = null;
        }
    }


    function MinTelpLength() {
        const notelp = document.getElementById("No_Telp").value;
        if (notelp.length < 10) {
            confirm('Jumlah digit angka lebih kecil dari 10')
            document.getElementById("No_Telp").focus();
        }
        return false;
    }

    function MinHPLength() {
        const nohp = document.getElementById("No_HP").value;
        if (nohp.length < 10) {
            confirm('Jumlah digit angka lebih kecil dari 10')
            document.getElementById("No_HP").focus();
        }
        return false;
    }

    function MinKTPLength() {
        const noktp = document.getElementById("KTP").value;
        if (noktp.length < 15) {
            confirm('Jumlah digit angka lebih kecil dari 15')
            document.getElementById("KTP").focus();
        }
        return false;
    }

    function assoc() {
        const sel = document.getElementById("association");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("asosi").value = teks;
    }


    function Ubah_SIPP_ED() {
        const tgl = new Date(document.getElementById('Tgl_SIPP').value);

        let tahun = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        let tanggal = tgl.getDate();

        let formattedMySQL = tahun + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('sipp_ed_ID').value = formattedMySQL;

    }

    function Ubah_STR_ED() {
        const tgl = new Date(document.getElementById('Tgl_STR').value);

        let tahun = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        let tanggal = tgl.getDate();

        let formattedMySQL = tahun + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('str_ed_ID').value = formattedMySQL;

    }

    function Fill_Asosiasi_ED() {
        const tgl = new Date(document.getElementById('Tgl_Asosiasi').value);

        let tahun = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        let tanggal = tgl.getDate();

        let formattedMySQL = tahun + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('id_asosiasi_ed').value = formattedMySQL;
    }

    function Ubah_KTA_ED() {
        const tgl = new Date(document.getElementById('Tgl_KTA').value);

        let tahun = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        let tanggal = tgl.getDate();

        let formattedMySQL = tahun + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('kta_ed_ID').value = formattedMySQL;
    }

    function tampil() {

        const tgl = new Date(document.getElementById('new_tgl_lahir').value);

        //Mengubah ke format MySQL
        month = '' + (tgl.getMonth() + 1),
            day = '' + tgl.getDate(),
            year = tgl.getFullYear();
        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        tanggal = year + '-' + month + '-' + day;

        document.getElementById('MySQL_tgl').value = tanggal;
    }

    function jurusanStrata1() {
        var sel = document.getElementById("jurS1");
        var teks = sel.options[sel.selectedIndex].text;
        document.getElementById("ijasahS1").value = teks;
    }

    function jurusanStrata2() {
        // alert('Halo');
        var sel = document.getElementById("jurS2");
        var teks = sel.options[sel.selectedIndex].text;
        document.getElementById("ijasahS2").value = teks;
    }

    function jurusanStrata3() {
        var sel = document.getElementById("jurS3");
        var teks = sel.options[sel.selectedIndex].text;
        document.getElementById("ijasahS3").value = teks;
    }
</script>

<script>
    function autocomplete(inp, arr) {
        /*the autocomplete function takes two arguments,
        the text field element and an array of possible autocompleted values:*/
        var currentFocus;
        /*execute a function when someone writes in the text field:*/
        inp.addEventListener("input", function(e) {
            var a, b, i, val = this.value;
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!val) {
                return false;
            }
            currentFocus = -1;
            /*create a DIV element that will contain the items (values):*/
            a = document.createElement("DIV");
            a.setAttribute("id", this.id + "autocomplete-list");
            a.setAttribute("class", "autocomplete-items");
            /*append the DIV element as a child of the autocomplete container:*/
            this.parentNode.appendChild(a);
            /*for each item in the array...*/
            for (i = 0; i < arr.length; i++) {
                /*check if the item starts with the same letters as the text field value:*/
                if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                    /*create a DIV element for each matching element:*/
                    b = document.createElement("DIV");
                    /*make the matching letters bold:*/
                    b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                    b.innerHTML += arr[i].substr(val.length);
                    /*insert a input field that will hold the current array item's value:*/
                    b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                    /*execute a function when someone clicks on the item value (DIV element):*/
                    b.addEventListener("click", function(e) {
                        /*insert the value for the autocomplete text field:*/
                        inp.value = this.getElementsByTagName("input")[0].value;
                        /*close the list of autocompleted values,
                        (or any other open lists of autocompleted values:*/
                        closeAllLists();
                    });
                    a.appendChild(b);
                }
            }
        });
        /*execute a function presses a key on the keyboard:*/
        inp.addEventListener("keydown", function(e) {
            var x = document.getElementById(this.id + "autocomplete-list");
            if (x) x = x.getElementsByTagName("div");
            if (e.keyCode == 40) {
                /*If the arrow DOWN key is pressed,
                increase the currentFocus variable:*/
                currentFocus++;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 38) { //up
                /*If the arrow UP key is pressed,
                decrease the currentFocus variable:*/
                currentFocus--;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 13) {
                /*If the ENTER key is pressed, prevent the form from being submitted,*/
                e.preventDefault();
                if (currentFocus > -1) {
                    /*and simulate a click on the "active" item:*/
                    if (x) x[currentFocus].click();
                }
            }
        });

        function addActive(x) {
            /*a function to classify an item as "active":*/
            if (!x) return false;
            /*start by removing the "active" class on all items:*/
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = (x.length - 1);
            /*add class "autocomplete-active":*/
            x[currentFocus].classList.add("autocomplete-active");
        }

        function removeActive(x) {
            /*a function to remove the "active" class from all autocomplete items:*/
            for (var i = 0; i < x.length; i++) {
                x[i].classList.remove("autocomplete-active");
            }
        }

        function closeAllLists(elmnt) {
            /*close all autocomplete lists in the document,
            except the one passed as an argument:*/
            var x = document.getElementsByClassName("autocomplete-items");
            for (var i = 0; i < x.length; i++) {
                if (elmnt != x[i] && elmnt != inp) {
                    x[i].parentNode.removeChild(x[i]);
                }
            }
        }
       /*execute a function when someone clicks in the document:*/
       document.addEventListener("click", function(e) {
            closeAllLists(e.target);
        });
    }

    var kota2 = <?php echo json_encode($namakota); ?>;
    autocomplete(document.getElementById("City"), kota2);
</script>

<?= $this->endsection(); ?>