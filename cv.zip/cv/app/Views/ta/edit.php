<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <link rel="stylesheet" href="sweetalert2.min.css">
</head>
<style>
    /* Jika input tidak sesuai dengan format, warna border berubah menjadi merah */
    input:invalid { 
        border: double;
        border: red solid 3px;
    }

    .daftar {
        border-radius: 5px;
        background-color: purple;
        color: white;
        width: 700px;
        height: 40px;
    }

    .no_edit {
        border-radius: 5px;
        background-color: #1dbcdb;
        color: white;
        width: 700px;
        height: 40px;
        font-family: "Times New Roman", Times, serif;
        font-weight: bold;
        color: black;
    }

    .biasa {
        border-radius: 5px;
        background-color: #1659c4;
        color: white;
        width: 700px;
        height: 40px;
    }
    .pendek {
        border-radius: 5px;
        background-color: #1659c4;
        color: white;
        width: 415px;
        height: 40px;
        margin-right: 10px;
    }
    .tanggal {
        border-radius: 5px;
        background-color: #1659c4;
        color: white;
        width: 150px;
        height: 40px;
    }
</style>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">

                    <center>
                        <h1 style="font-weight: bold; font-family: Georgia" ;>Edit Tenaga Ahli</h1>
                    </center>

                    <!-- /.card-header -->
                    <div class="card-body">
                        <form action="<?= route_to('edit_ta/', $ta['id']) ?>" method="post" id="frmEdit" enctype="multipart/form-data">

                            <input type="hidden" name="id" id="TxtID" value="<?= $ta['id'] ?>">

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Tenaga Ahli</label>
                                <div class="col-sm-10">
                                    <input type="text" 
                                    class="no_edit" name="kode_ta" value="<?= $ta['kode_ta'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nama Personil</label>
                                <div class="col-sm-10">
                                    <input type="text" 
                                    class="no_edit" name="nama" value="<?= $ta['nama'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nama Perusahaan</label>
                                <div class="col-sm-10">
                                    <input type="text" 
                                    class="no_edit" name="perusahaan" value="<?= $ta['perusahaan'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Posisi yang diusulkan</label>
                                <div class="col-sm-5">
                                    <select class="form-control daftar" name="posisi">
                                        <option value="<?= $ta['posisi'] ?>"><?= $ta['posisi'] ?></option>
                                        <!--Ini field dari tabel posisi (tb_posisi) untuk mengisi tb_ta -->
                                        <?php foreach ($posisi as $val) : ?>
                                            <option value="<?= $val['posisitugas'] ?>"><?= $val['posisitugas'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3 row"><label class="col-sm-2 col-form-label">Kategori</label>
                                <div class="col-sm-5">
                                    <select class="form-control daftar" id="category" name="kategori">
                                        <option value="<?= $ta['kategori'] ?>"><?= $ta['kategori'] ?></option>
                                        <?php foreach ($kategori as $val) : ?>
                                            <option value="<?= $val['kategori'] ?>"> <?= $val['kategori'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Status Kepegawaian</label>
                                <div class="col-sm-5">
                                    <select class="form-select col-sm-3 daftar" name="status_kepegawaian">
                                        <option value="<?= $ta['status_kepegawaian'] ?>"><?= $ta['status_kepegawaian'] ?></option>
                                        <option value="Tetap">Tetap</option>
                                        <option value="Tidak Tetap">Tidak Tetap</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Alamat</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control biasa" name="alamat" value="<?= $ta['alamat'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row"><label class="col-sm-2 col-form-label">Kota</label>
                                <div class="col-sm-5">
                                    <select class="form-control daftar" id="kota" name="kota">
                                        <option value="<?= $ta['kota'] ?>"><?= $ta['kota'] ?></option>
                                        <?php foreach ($kota as $val) : ?>
                                            <option value="<?= $val['kota'] ?>"> <?= $val['kota'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <?php
                            $tgl = isset($ta['tgl']) ? $ta['tgl'] : '';
                            if ($tgl != '0000-00-00' && $tgl != null  && $tgl != '') {
                                $tgl = new DateTime($ta['tgl']);
                                $tgl_lahir = $tgl->format('Y-m-d'); //  Menampilkan format Indo
                                $sekarang = new DateTime();
                                $diff = $sekarang->diff($tgl);
                            } else {
                                $tgl_lahir = "";
                            }
                            ?>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Status Kepegawaian</label>
                                <div class="col-sm-5">
                                    <select class="form-select col-sm-3 daftar" name="status_kepegawaian">
                                        <option value="<?= $ta['status_kepegawaian'] ?>"><?= $ta['status_kepegawaian'] ?></option>
                                        <option value="Tetap">Tetap</option>
                                        <option value="Tidak Tetap">Tidak Tetap</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-1 row">

                                <label class="col-sm-2 col-form-label">Tgl.lahir</label>

                                <div class="col-sm-2">
                                    <input type="date" class="form-control tanggal" name="new_ttl" id="new_tgl_lahir" 
                                    value="<?= $tgl_lahir ?>" onchange="tampil()" />
                                </div>

                                <div class="col-sm-2">
                                    <input type="hidden" class="form-control" name="tgl" value="<?= $tgl_lahir ?>" id="old_tgl_lahir" />
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">KTP</label>
                                <div class="col-sm-5">
                                    <input type="number" pattern="[0-9]" minlength="15" value="<?= $ta['no_ktp'] ?>" name="no_ktp" class="form-control biasa" id="KTP" onchange="MinKTPLength()">
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">NPWP lama</label>
                                <div class="col-sm-3">
                                    <input type="text" class="form-control no_edit" name="no_npwp" style="color:blue" id="nomor_npwp" 
                                    value="<?= $ta['no_npwp'] ?>" readonly>
                                </div>
                            </div>

                            <div class="row">
                                <label class="col-sm-2 col-form-label">NPWP baru</label>
                                <label class="col-sm-5">
                                    <input name="no_npwp1" id="npwp1" type="tel" pattern="[0-9]{2}" placeholder="__" aria-label="2-digit nomor" size="1" />
                                    .<input name="no_npwp2" id="npwp2" pattern="[0-9]{3}" placeholder="___" aria-label="3-digit nomor" size="2" />.
                                    <input name="no_npwp3" id="npwp3" pattern="[0-9]{3}" placeholder="___" aria-label="3-digit nomor" size="3" />-<input name="no_npwp4" id="npwp4" pattern="[0-9]{1}" placeholder="_" aria-label="1-digit nomor" size="1" />.
                                    <input name="no_npwp5" id="npwp5" pattern="[0-9]{3}" placeholder="___" aria-label="3-digit nomor" size="3" />.<input name="no_npwp6" id="npwp6" pattern="[0-9]{3}" placeholder="___" aria-label="3-digit nomor" size="3" />
                                </label>
                                <label class="col-sm-3 col-form-label">contoh : 12.456.789-1.234.123</label>
                            </div>
                         
                            <div class="mb-1 row">
                                <label for="no_telp" class="col-sm-2 col-form-label">Telp.</label>
                                <div class="col-sm-5">
                                    <input type="number" value="<?= $ta['no_telp'] ?>" name="no_telp" 
                                    pattern="[0-9]" minlength="10" class="form-control biasa" id="Telp" onchange="MinTelpLength()">
                                </div>
                            </div>
                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">HP</label>
                                <div class="col-sm-5">
                                    <input type="number" name="no_hp" value="<?= $ta['no_hp'] ?>" 
                                    pattern="[0-9]" minlength="10" class="form-control biasa" id="No_HP" 
                                    onchange="MinHPLength()">
                                </div>
                            </div>
                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Email</label>
                                <div class="col-sm-5">
                                    <input type="email" class="biasa" 
                                    name="email" value="<?= $ta['email'] ?>" id="email" 
                                    pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">
                                </div>
                            </div>
                            <br>
                            <br>
                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Nomor SIPP</label>
                                <div class="col-sm-10">
                                    <input type="text" class="input-group-text pendek" name="sipp" 
                                    value="<?= old('sipp', $ta['sipp']) ?>" />
                                    <label style="width: 120px" class="input-group-text" id="sipp_ed">Tgl. kadaluarsa</label>
                                    <input type="date" class="input-group-text tanggal" id="Tgl_SIPP" 
                                            onchange="Ubah_SIPP_ED()" value="<?= $ta['sipp_ed'] ?>"/>
                                    <input type="hidden" class="input-group-text" name="sipp_ed" id="sipp_ed_ID"/>
                                </div>
                               
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Nomor STR </label>
                                <div class="col-sm-10">
                                        <input type="text" class="input-group-text pendek" name="str" value="<?= old('str', $ta['str']) ?>" />
                                        <label style="width: 120px" class="input-group-text" id="str_ed">Tgl. kadaluarsa</label>
                                        <input type="date" class="input-group-text tanggal" id="Tgl_STR" onchange="Ubah_STR_ED()" value="<?= $ta['str_ed'] ?>"/>
                                        <input type="hidden" class="input-group-text" name="str_ed" id="str_ed_ID"/>
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Nomor KTA </label>
                                <div class="col-sm-10">
                                        <input type="text" class="input-group-text pendek" name="kta" value="<?= old('kta', $ta['kta']) ?>" />
                                        <label style="width: 120px" class="input-group-text" id="kta_ed">Tgl. kadaluarsa</label>
                                        <input type="date" class="input-group-text tanggal" id="Tgl_KTA" onchange="Ubah_KTA_ED()" value="<?= $ta['kta_ed'] ?>"/>
                                        <input type="hidden" class="input-group-text" name="kta_ed" id="kta_ed_ID"/>
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Asosiasi</label>
                                <!--   <input type="text" name="asosiasi" id="TheRealAssoc" class="input-group-text" style="width: 500px;" readonly/>-->
                                    <div class="col-sm-10">
                                        <select class="input-group-text pendek" id="association" name="asosiasi">
                                            <option selected><?= $ta['asosiasi'] ?></option>
                                            <option value="Asosiasi Psikologi Industri dan Organisasi (APIO)">Asosiasi Psikologi Industri dan Organisasi (APIO)</option>
                                            <option value="Himpunan Psikologi Indonesia (HIMPSI)">Himpunan Psikologi Indonesia (HIMPSI)</option>
                                            <option value="Asosiasi Psikologi Forensik(APSIFOR)">Asosiasi Psikologi Forensik(APSIFOR)</option>
                                            <option value="Ikatan Psikolog Klinis(IPK)">Ikatan Psikolog Klinis(IPK)</option>
                                            <option value="Ikatan Psikologi Pendidikan Indonesia(IPPI)">Ikatan Psikologi Pendidikan Indonesia(IPPI)</option>
                                            <option value=""></option>
                                        </select>
                                        <label style="width: 120px" class="input-group-text">Tgl. kadaluarsa</label>
                                        <input type="date" class="input-group-text tanggal" id="Tgl_Asosiasi" onchange="Ubah_Asosiasi_ED()" value="<?= $ta['asosiasi_ed'] ?>"/>
                                        <input type="hidden" class="input-group-text" name="asosiasi_ed" id="Real_Tgl_Asosiasi">
                                    </div>
                            </div>

                            <div class="mb-1 row">
                                
                                <label class="col-sm-2 col-form-label">Referensi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control daftar" value="<?= $ta['file_pdf_referensi'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <div class="col-sm-2">
                                    <label style="width:300px">Pilih file referensi</label>
                                </div>
                                <div class="col-sm-9">
                                    <input type="file" name="file" id="finput" style="width:800px" accept="application/pdf"><br>
                                </div>

                            </div>

                            <hr>
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="width:1000px; margin-left: 50px;">
                                        <div id="file-progress-bar" class="progress-bar"></div>
                                    </div>
                                </div>
                            </div>

                            <br>
                            <br>
                            <div class="modal-footer">
                                <a href="/ta" class="btn btn-primary m-2" style="height: 35px; width: 90px">
                                    <i class="fa-solid fa-circle-left"></i></i>Kembali</a>
                                <button type="submit" id="btnUpdate" class="btn btn-success">Update</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="sweetalert2.all.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(document).ready(function() {
        /*          <!--    https://techarise.com/demos/ci/file-upload-with-progress-bar-jquery-ajax   -->
                    <!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example -->        */
        $('#frmEdit').on('submit', function(e) {
            $('#btnUpdate').prop('Disabled');
            e.preventDefault();
            id = $('#TxtID').val();
            if ($('#finput').val() != '') {
                //  Jika ada file yang di-upload, aktifkan progress bar 
                $.ajax({
                    xhr: function() {
                        var xhr = new window.XMLHttpRequest();
                        //  Kemajuan progres bar dihitung di sini
                        xhr.upload.addEventListener("progress", function(element) {
                            if (element.lengthComputable) {
                                var percentComplete = ((element.loaded / element.total) * 100);
                                $("#file-progress-bar").width(percentComplete + '%');
                                $("#file-progress-bar").html(percentComplete + '%');
                            }
                        }, false);
                        return xhr;
                    },
                    url: "updateTA",
                    method: "POST",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    cache: false,
                    dataType: "json",
                    beforeSend: function() {
                        $("#file-progress-bar").width('0%');
                        $('#btnUpdate').html('Uploading ...');
                    },
                    success: function(res) {
                        if (res.success == true) {
                            $('#btnUpdate').html('Sukses upload...');
                            $("button#btnUpdate").css("background-color", "green");
                            Swal.fire(
                                'Sweet,....!',
                                res.msg,
                                'success'
                            );
                        } else if (res.success == false) {
                            Swal.fire(
                                'Bad,.....!',
                                res.msg,
                                'error'
                            );
                        }
                        //$('.btnUpdate').html('Upload');
                        $('#btnUpdate').prop('Enabled');
                        document.getElementById("frmEdit").reset();
                    },
                    complete: function() {
                        $('#btnUpdate').html('Simpan');
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });
            } else {
                //  //  Jika ada file yang di-upload, tidak usah memakai progress bar
                $.ajax({
                    url: "updateTA",
                    method: "POST",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    cache: false,
                    dataType: "json",
                    success: function(res) {
                        if (res.success == true) {
                            $('#btnUpdate').html('Sukses menyimpan data...');
                            $("button#btnUpdate").css("background-color", "green");
                            Swal.fire(
                                'Sweet,....!',
                                res.msg,
                                'success'
                            );
                        } else if (res.success == false) {
                            Swal.fire(
                                'Bad,.....!',
                                res.msg,
                                'error'
                            );
                        }
                        //$('.btnUpdate').html('Upload');
                        $('#btnUpdate').prop('Enabled');
                        document.getElementById("frmEdit").reset();
                    },
                    complete: function() {
                        $('#btnUpdate').html('Simpan');
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });

            }

        });
    });
</script>

<script>
    function isiEmail() {
        const email = document.getElementById("email").value;
        document.getElementById("TheRealEmail").value = email;
    }

    function isiHP() {
        const noktp = document.getElementById("No_HP").value;
        document.getElementById("TheRealHP").value = noktp;
    }

    function MinHPLength() {
        const nohp = document.getElementById("No_HP").value;
        if (nohp.length < 10) {
            confirm('Jumlah digit angka lebih kecil dari 10')
            document.getElementById("No_HP").focus();
        }
        return false;
    }

    function isiKTP() {
        const noktp = document.getElementById("KTP").value;
        document.getElementById("The_Real_KTP").value = noktp;
    }


    function isiTelp() {
        const noktp = document.getElementById("Telp").value;
        document.getElementById("TheRealTelp").value = noktp;
    }

    function MinTelpLength() {
        const notelp = document.getElementById("Telp").value;
        if (notelp.length < 10) {
            confirm('Jumlah digit angka lebih kecil dari 10')
            document.getElementById("No_Telp").focus();
        }
        return false;
    }

    function MinKTPLength() {
        const noktp = document.getElementById("KTP").value;
        if (noktp.length < 15) {
            confirm('Jumlah digit angka lebih kecil dari 15')
            document.getElementById("KTP").focus();
        }
        return false;
    }

    function Sambung_NPWP() {
        var npwp1 = document.getElementById("npwp1").value;
        var npwp2 = document.getElementById("npwp2").value;
        var npwp3 = document.getElementById("npwp3").value;
        var npwp4 = document.getElementById("npwp4").value;
        var npwp5 = document.getElementById("npwp5").value;
        var npwp6 = document.getElementById("npwp6").value;
        var npwp = npwp1 + "." + npwp2 + "." + npwp3 + "-" + npwp4 + "." + npwp5 + "." + npwp6;
        document.getElementById("nomor_npwp").value = npwp;
    }

    function MinLengthS3Year() {
        const thnS3 = document.getElementById("S3Year").value;
        if (thnS3.length != 4) {
            confirm('Jumlah digit tidak sama dengan 4')
            document.getElementById("S3Year").focus();
        }
        return false;
    }

    function MinLengthS2Year() {
        const thnS2 = document.getElementById("S2Year").value;
        if (thnS2.length != 4) {
            confirm('Jumlah digit tidak sama dengan 4')
            document.getElementById("S2Year").focus();
        }
        return false;
    }

    function MinLengthS1Year() {
        const thnS1 = document.getElementById("S1Year").value;
        if (thnS1.length != 4) {
            confirm('Jumlah digit tidak sama dengan 4')
            document.getElementById("S1Year").focus();
        }
        return false;
    }

    function tampil() { //Mengatur tampilan format tanggal lahir
        //Mengambil tanggal lahir baru dari input date 
        const tgl = new Date(document.getElementById('new_tgl_lahir').value);
        let tahun = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        let tanggal = tgl.getDate();
        if (tanggal < 10) tanggal = '0' + tanggal;
        if (bulan < 10) bulan = '0' + bulan;
        let formattedToday = tahun + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('old_tgl_lahir').value = formattedToday; //  Menampilkan tanggal lahir dengan format MySQL//
    }

    function Ubah_SIPP_ED() {
        const tgl = new Date(document.getElementById('Tgl_SIPP').value);
        let tahun = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        let tanggal = tgl.getDate();
        let formattedMySQL = tahun + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('sipp_ed_ID').value = formattedMySQL;
    }

    function Ubah_STR_ED() {
        const tgl = new Date(document.getElementById('Tgl_STR').value);
        let tahun = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        let tanggal = tgl.getDate();
        let formattedMySQL = tahun + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('str_ed_ID').value = formattedMySQL;
    }

    function Ubah_Asosiasi_ED() {
        const tgl = new Date(document.getElementById('Tgl_Asosiasi').value);
        let tahun = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        let tanggal = tgl.getDate();
        let formattedMySQL = tahun + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('Real_Tgl_Asosiasi').value = formattedMySQL;
    }

    function Ubah_KTA_ED() {
        const tgl = new Date(document.getElementById('Tgl_KTA').value);
        let tahun = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        let tanggal = tgl.getDate();
        let formattedMySQL = tahun + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('kta_ed_ID').value = formattedMySQL;
    }

    function Ubah_CIPA_ED() {
        const tgl = new Date(document.getElementById('Tgl_CIPA').value);
        let tahun = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        let tanggal = tgl.getDate();
        let formattedMySQL = tahun + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('cipa_Kadal').value = formattedMySQL;
    }

    function jurusanStrata1() {
        var sel = document.getElementById("jurS1");
        var teks = sel.options[sel.selectedIndex].text;
        document.getElementById("ijasahS1").value = teks;
    }

    function jurusanStrata2() {
        var sel = document.getElementById("jurS2");
        var teks = sel.options[sel.selectedIndex].text;
        document.getElementById("ijasahS2").value = teks;
    }

    function jurusanStrata3() {
        var sel = document.getElementById("jurS3");
        var teks = sel.options[sel.selectedIndex].text;
        document.getElementById("ijasahS3").value = teks;
    }

    function IsiNama() {
        const sel = document.getElementById("ta_ID");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("Nama_Personil").value = teks;
    }

    function IsiJabatan() {
        const sel = document.getElementById("positions");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("jabatan").value = teks;
    }

    function IsiID() {
        let ta = document.getElementById('ta_ID').value;
        const sel = document.getElementById("ta_ID");
        sel.options[sel.selectedIndex].text = ta;
    }

    function ShowExperts($id) {
        //      let nama = document.getElementById('#intermitten').innerText;
        window.location.href = "/ExpertsList/" + $id
    }

    function IsiIDPekerjaan() {
        let idKegiatan = document.getElementById('pekerjaan').value;
        const sel = document.getElementById("pekerjaan");
        sel.options[sel.selectedIndex].text = idKegiatan;
    }

    function IsiPekerjaan() {
        const sel = document.getElementById("pekerjaan");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("aktifitas").value = teks;
    }
</script>

<!--
<script>
    function autocomplete(inp, arr) {
        /*the autocomplete function takes two arguments,
        the text field element and an array of possible autocompleted values:*/
        var currentFocus;
        /*execute a function when someone writes in the text field:*/
        inp.addEventListener("input", function(e) {
            var a, b, i, val = this.value;
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!val) {
                return false;
            }
            currentFocus = -1;
            /*create a DIV element that will contain the items (values):*/
            a = document.createElement("DIV");
            a.setAttribute("id", this.id + "autocomplete-list");
            a.setAttribute("class", "autocomplete-items");
            /*append the DIV element as a child of the autocomplete container:*/
            this.parentNode.appendChild(a);
            /*for each item in the array...*/
            for (i = 0; i < arr.length; i++) {
                /*check if the item starts with the same letters as the text field value:*/
                if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                    /*create a DIV element for each matching element:*/
                    b = document.createElement("DIV");
                    /*make the matching letters bold:*/
                    b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                    b.innerHTML += arr[i].substr(val.length);
                    /*insert a input field that will hold the current array item's value:*/
                    b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                    /*execute a function when someone clicks on the item value (DIV element):*/
                    b.addEventListener("click", function(e) {
                        /*insert the value for the autocomplete text field:*/
                        inp.value = this.getElementsByTagName("input")[0].value;
                        /*close the list of autocompleted values,
                        (or any other open lists of autocompleted values:*/
                        closeAllLists();
                    });
                    a.appendChild(b);
                }
            }
        });
        /*execute a function presses a key on the keyboard:*/
        inp.addEventListener("keydown", function(e) {
            var x = document.getElementById(this.id + "autocomplete-list");
            if (x) x = x.getElementsByTagName("div");
            if (e.keyCode == 40) {
                /*If the arrow DOWN key is pressed,
                increase the currentFocus variable:*/
                currentFocus++;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 38) { //up
                /*If the arrow UP key is pressed,
                decrease the currentFocus variable:*/
                currentFocus--;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 13) {
                /*If the ENTER key is pressed, prevent the form from being submitted,*/
                e.preventDefault();
                if (currentFocus > -1) {
                    /*and simulate a click on the "active" item:*/
                    if (x) x[currentFocus].click();
                }
            }
        });

        function addActive(x) {
            /*a function to classify an item as "active":*/
            if (!x) return false;
            /*start by removing the "active" class on all items:*/
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = (x.length - 1);
            /*add class "autocomplete-active":*/
            x[currentFocus].classList.add("autocomplete-active");
        }

        function removeActive(x) {
            /*a function to remove the "active" class from all autocomplete items:*/
            for (var i = 0; i < x.length; i++) {
                x[i].classList.remove("autocomplete-active");
            }
        }

        function closeAllLists(elmnt) {
            /*close all autocomplete lists in the document,
            except the one passed as an argument:*/
            var x = document.getElementsByClassName("autocomplete-items");
            for (var i = 0; i < x.length; i++) {
                if (elmnt != x[i] && elmnt != inp) {
                    x[i].parentNode.removeChild(x[i]);
                }
            }
        }
        /*execute a function when someone clicks in the document:*/
        document.addEventListener("click", function(e) {
            closeAllLists(e.target);
        });
    }
  
    autocomplete(document.getElementById("kota"), kota2);
</script>
-->
<?= $this->endsection(); ?>