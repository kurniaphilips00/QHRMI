<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                            <a href="/omset/tambah" class=btn btn-primary style="width:90px; background-color:#037bfc; margin-right: 5px;color:white" title="Menambah data omset">
                                <i class="fa-solid fa-circle-plus"></i> Tambah</a>
                            
                                <a href="/omset/rekap" class="btn btn-primary" 
                                style="width:80px; height:30px; background-color:#90e1f5; margin-left: 20px; color:black" 
                                title="Summary"><i class="fa-solid fa-chart-simple"></i>Rekap</a>
<!--
                            <form action="" method="post" enctype="multipart/form-data" style="display: inline;">
                                <div class="btn-group" role="group">
                                    <label for="files" class="btn">Pilih file excel</label>
                                    <input id="files" type="file" accept=".xls, .xlsx, .ods" name='excel'>
                                </div>
                                <button title="" onclick="return confirm('Tabel pengalaman akan dikosongkan, yakin ingin impor ?')" type="submit" class="btn btn-primary" style="width:90px;height: 30px; background-color:#90e1f5; color:black">
                                    <i class="fa-sharp fa-solid fa-upload"></i>Import</button>
                                <a href="/omset/exportExcel" class="btn btn-primary" style="width:80px; height:30px; background-color:#90e1f5; margin-right: 20px; color:black" title="Export to Excel">Export<i class="fa-solid fa-file-arrow-down"></i></a>
                            </form>
-->

                        </div>
                        <br>
                    </div>
                    <br>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <?php if (session('sukses-tambah-omset')) :  ?>
                            <div class="alert alert-info" role="alert">
                                <?= session('sukses-tambah-omset');
                                ?>
                            </div>
                        <?php endif; ?>
                        <?php if (session('del-success')) :  ?>
                            <div class="alert alert-info" role="alert">
                                <?= session('del-success');  //  Delete success 
                                ?>
                            </div>
                        <?php endif; ?>
                        <?php if (session('sukses-update-omset')) :  ?>
                            <div class="alert alert-info" role="alert">
                                <?= session('sukses-update-omset');
                                ?>
                            </div>
                        <?php endif; ?>

                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="text-align:center; width:5%">No.</th>
                                    <th style="text-align:center; width:5%">Kode</th>
                                    <th style="text-align:center; width:20%">Instansi</th>
                                    <th style="text-align:center; width:25%">Pekerjaan</th>
                                    <th style="text-align:center; width:10%">Mulai</th>
                                    <th style="text-align:center; width:10%">Selesai</th>
                                    <th style="text-align:center; width:5%">Nilai</th>
                                    <th style="text-align:center; width:5%">Jenis</th>
                                    <th style="text-align:center; width:15%">Edit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($Omset) {
                                    $no = 1;
                                    foreach ($Omset as $v) {

                                        $id = isset($v['id']) ? $v['id'] : '';
                                        $kode = isset($v['kode']) ? $v['kode'] : '';
                                        $jenis = isset($v['jenis']) ? $v['jenis'] : '';
                                        $instansi = isset($v['instansi']) ? $v['instansi'] : '';
                                        $pekerjaan = isset($v['pekerjaan']) ? $v['pekerjaan'] : '';
                                        $nilai = isset($v['nilai']) ? $v['nilai'] : '';
                                        $mulai = isset($v['mulai']) ? $v['mulai'] : '';
                                        $selesai = isset($v['selesai']) ? $v['selesai'] : '';
                                        if ($mulai != null && $mulai != '0000-00-00') {
                                            $tgl = new DateTime($mulai);
                                            $tgl_mulai = $tgl->format('d-m-Y'); //  Menampilkan format Indo
                                        } else {
                                            $tgl_mulai = 'kosong';
                                        }
                                        if ($selesai != null &&  $selesai != '0000-00-00') {
                                            $tgl = new DateTime($selesai);
                                            $tgl_selesai = $tgl->format('d-m-Y'); //  Menampilkan format Indo
                                        } else {
                                            $tgl_selesai = 'kosong';
                                        }
                                        $nilai = isset($v['nilai']) ? $v['nilai'] : '';
                                        $jenis = isset($v['jenis']) ? $v['jenis'] : '';
                                ?>
                                        <tr>
                                            <td style="width:5%"><?= $no; ?></td>
                                            <td style="width:5%"><?= $kode; ?></td>
                                            <td style="width:20%"><?= $instansi ?></td>
                                            <td style="width:25%"><?= $pekerjaan ?></td>
                                            <td style="width:10%"><?= $tgl_mulai ?></td>
                                            <td style="width:10%"><?= $tgl_selesai ?></td>
                                            <td style="width:5%"><?= $nilai ?></td>
                                            <td style="width:5%"><?= $jenis ?></td>
                                            <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->
                                            <td style="width:15%; text-align:center">
                                                <a href="/omset/baca/<?= $kode; ?>">
                                                    <i class="fa-solid fa-glasses" title="baca"></i>
                                                    |
                                                    <a href="/omset/edit/<?= $id; ?>">
                                                        <i class="fa-solid fa-pencil" title="edit"></i>
                                                        |
                                                        <a href="/omset/hapus/<?= $id; ?>" onclick="return confirm('Yakin ingin menghapus omset')">
                                                            <i class="fa-solid fa-trash-can" title="Hapus"></i>
                                            </td>
                                            <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->

                                        </tr>

                                    <?php
                                        $no++;
                                    }
                                } else { ?>

                                    <tr>
                                        <td colspan="5">Tidak ada data(kosong)..........................!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!</td>
                                    </tr>
                                <?php


                                } ?>


                            </tbody>

                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->


<?= $this->endsection(); ?>