<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>


<style type="text/css">
    .displaynone {
        display: none;
    }

    .currSign:before {
        content: 'Rp. ';
    }
</style>
<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Form Tambah Data Omset</h2>


                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">


                        <div class="panel-body">

                            <?php if (session('sukses-tambah-omset')) :  ?>
                                <div class="alert alert-info" role="alert">
                                    <?= session('sukses-tambah-omset');
                                    ?>
                                </div>
                            <?php endif; ?>


                            <form action="" method="post">


                                <div class="mb-1 row">
                                    <label class="col-sm-3 col-form-label">Kode </label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="kode" value="<?= $kode; ?>" readonly>
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="pekerjaan" class="col-sm-3 col-form-label">Pekerjaan</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="pekerjaan" id="pekerjaan" placeholder="Kegiatan">
                                        <span id="pekerjaan_error" class="text-danger"></span>
                                    </div>
                                </div>



                                <div class="mb-1 row">
                                    <label for="instansi" class="col-sm-3 col-form-label">Instansi</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="instansi" id="instansi" placeholder="Instansi">
                                    </div>
                                </div>


                                <div class="input-group mb-3">
                                    <label class="input-group-text" style="width: 280px;">Jenis</label>
                                    <select class="form-select" style="margin-right: 20px; width: 280px; height:35px" name="jenis" id="jenis">
                                        <option selected>Pilih Jenis</option>
                                        <option value="Assessment Center">Assessment Center</option>
                                        <option value="Manajemen SDM">Manajemen SDM</option>
                                    </select>
                                </div>


                                <div class="mb-1 row">
                                    <label for="no_kontrak" class="col-sm-3 col-form-label">No. Kontrak</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="no_kontrak" id="no_kontrak">
                                    </div>
                                </div>

                                <div class="mb-1 row">
                                    <label for="mulai" class="col-sm-3 col-form-label">Mulai</label>
                                    <div>
                                        <input type="hidden" class="form-control" name="mulai" id="real_mulai">
                                    </div>
                                    <div class="col-sm-2">
                                        <input type="date" class="form-control" id="start" onchange="formatToMySQL()">
                                    </div>
                                    <label for="selesai" class="col-sm-1 col-form-label">Selesai</label>
                                    <div>
                                        <input type="hidden" class="form-control" name="selesai" id="real_selesai">
                                    </div>
                                    <div class="col-sm-2">
                                        <input type="date" class="form-control" id="finish" onchange="formatToMySQLAndCalculate()">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Nilai kontrak</label>
                                    <div class="col-sm-4">
                                        <!-- diambil dari https://codepen.io/akalkhair/pen/dyPaozZ -->
                                        <!-- Memakai JQuery > fungsi formatCurrency dan formatNumber() > pada script di bawah v --->
                                        <input type="text" name="nilaisementara" id="currency-field" pattern="^\Rp\d{1.3}(.\d{3})*(\,\d+)?Rp" data-type="currency" placeholder="Rp 1.000.000,00" onfocusout="formatnilai()" />
                                        <input type="hidden" name="nilai" id="real_nilai">
                                    </div>
                                </div>

            
                                <div class="modal-footer">
                                    <a href="/omset" class="btn btn-primary m-2" style="height: 35px; width: 90px">
                                        <i class="fa-solid fa-circle-left"></i></i>Kembali</a>
                                    <button type="submit" class="btn btn-success" id="save">Simpan</button>
                                </div>
                            </form>
                            <div class="form-group" id="process" style="display:none">
                                <div class="progress">
                                    <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->
<script>
    /*  ########## JQuery memakai Google CDN (ada di dashboard-layout.php) ######## */
    $("input[data-type='currency']").on({
        keyup: function() {
            // alert('Hai');
            formatCurrency($(this));
        },
        blur: function() {
            formatCurrency($(this), "blur");
        }
    });

    function formatNumber(n) {
        // format number 1000000 to 1.234.567
        return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ".")
    }

    function formatCurrency(input, blur) {
        //  alert('Hai');
        // appends $ to value, validates decimal side
        // and puts cursor back in right position.

        // get input value
        var input_val = input.val();

        // don't validate empty input
        if (input_val === "") {
            return;
        }

        // original length
        var original_len = input_val.length;

        // initial caret position 
        var caret_pos = input.prop("selectionStart");

        // check for decimal
        if (input_val.indexOf(",") >= 0) {

            // get position of first decimal
            // this prevents multiple decimals from
            // being entered
            var decimal_pos = input_val.indexOf(",");

            // split number by decimal point
            var left_side = input_val.substring(0, decimal_pos);
            var right_side = input_val.substring(decimal_pos);

            // add commas to left side of number
            left_side = formatNumber(left_side);

            // validate right side
            right_side = formatNumber(right_side);

            // On blur make sure 2 numbers after decimal
            if (blur === "blur") {
                right_side += "00";
            }

            // Limit decimal to only 2 digits
            right_side = right_side.substring(0, 2);

            // join number by .
            input_val = "Rp" + left_side + "," + right_side;

        } else {
            // no decimal entered
            // add commas to number
            // remove all non-digits
            input_val = formatNumber(input_val);
            input_val = "Rp" + input_val;

            // final formatting
            if (blur === "blur") {
                input_val += ",00";
            }
        }

        // send updated string to input
        input.val(input_val);

        // put caret back in the right position
        var updated_len = input_val.length;
        caret_pos = updated_len - original_len + caret_pos;
        input[0].setSelectionRange(caret_pos, caret_pos);
    }
</script>


<script>
    function formatnilai() {
        nilai = document.getElementById('currency-field').value;
        nilai = nilai.replace(",00", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace("Rp", "");
        document.getElementById('real_nilai').value = nilai;
    }

    function getYear() {
        const thn = document.getElementById("tahun").value;
        let tahun = thn.substring(0, 4);
        document.getElementById("real_tahun").value = tahun;
    }

    function formatToMySQL() {

        const tglawal = new Date(document.getElementById('start').value);
        let tahuntglawal = tglawal.getFullYear();
        let bulantglaw = tglawal.getMonth() + 1; // Months start at 0
        let haritglaw = tglawal.getDate();
        let tgl = tahuntglawal + '-' + bulantglaw + '-' + haritglaw;
        //  alert(tgl);
        document.getElementById('real_mulai').value = tgl;
    }

    function formatToMySQLAndCalculate() { //start, finish
        let awal = document.getElementById('start').value;
        if (awal != "") {
            const tglawal = new Date(document.getElementById('start').value);
            const tglakhir = new Date(document.getElementById('finish').value);
            let time_difference = tglakhir.getTime() - tglawal.getTime();
            let Years_difference = 0;
            let SisaBulan = 0;
            let SisaHari = 0;
            let JmlBln = 0;
            var inter = "( ";
            //calculate days difference by dividing total milliseconds in a day  
            let days_difference = time_difference / (1000 * 60 * 60 * 24);

            let Months_difference = Math.floor(days_difference / 30);
            if (Months_difference > 12) {
                Years_difference = Math.floor(Months_difference / 12);
                SisaBulan = Months_difference % 12;
                SisaHari = days_difference - ((Years_difference * 360) + (SisaBulan * 30));
                inter += Years_difference + " tahun ";
                inter += SisaBulan + " bulan ";
                inter += SisaHari + " hari ";
                if (SisaHari > 0) {
                    JmlBln = SisaBulan + 1;
                } else {
                    JmlBln = SisaBulan;
                }
            } else if (Months_difference > 0) {
                SisaHari = days_difference % 30;
                inter += Months_difference + " bulan ";
                inter += SisaHari + " hari ";
                if (SisaHari > 0) {
                    JmlBln = Months_difference + 1;
                } else {
                    JmlBln = Months_difference;
                }
            } else {
                inter += days_difference + " hari ";
                JmlBln = 1;
                //alert(inter);
            }
            inter += " )";
            if (Years_difference > 0) {
                JmlBln = JmlBln + (Years_difference * 12);
            }
            let tahuntglakhir = tglakhir.getFullYear();
            let bulantglakhir = tglakhir.getMonth() + 1; // Months start at 0
            let haritglakhir = tglakhir.getDate();
            let tglSelesai = tahuntglakhir + '-' + bulantglakhir + '-' + haritglakhir;
            document.getElementById('real_selesai').value = tglSelesai;
            document.getElementById('inter').value = inter;
            document.getElementById('jml_bln').value = JmlBln;
        }
    }
</script>

<!-- Script from https://makitweb.com/how-to-upload-a-file-using-jquery-ajax-in-codeigniter-4/ -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
    //$(document).ready(function(){


    //   });
</script>

<script>
    $(document).ready(function() {
        // alert('Hai');
        $('#sampel_form').on('submit', function(event) {
            event.preventDefault();
            var count_error = 0;

            if ($('#pekerjaan').val() == '') {
                $('#pekerjaan_error').text('Pekerjaan harus diisi !!!!!!!!!???????...');
                count_error++;
            } else {
                $('#pekerjaan_error').text('');
            }

            if ($('#tahun').val() == '') {
                $('#tahun_error').text('Tahun harus diisi !!!!!!!!!???????...');
                count_error++;
            } else {
                $('#tahun_error').text('');
            }

            if (count_error == 0) {
                $.ajax({
                    url: "save_exp",
                    method: "POST",
                    data: $(this).serialize(),
                    beforeSend: function() {
                        $('#save').attr('disabled', 'disabled');
                        $('#process').css('display', 'block');
                    },
                    success: function(data) {
                        // alert(data);
                        var percentage = 0;
                        var timer = setInterval(function() {
                            percentage = percentage + 20;
                            progress_bar(percentage, timer);
                        }, 1000);
                    }
                })
            } else {
                return false;
            }
        });

        function progress_bar(percentage, timer) {
            $('.progress-bar').css('width', percentage + '%');
            if (percentage > 100) {
                clearInterval(timer);
                $('#sampel_form')[0].reset();
                $('#process').css('display', 'none');
                $('.progress-bar').css('width', '0%');
                $('#save').attr('disabled', false);
                $('#success_message').html("<div class='alert alert-success'>Data sudah tersimpan</div>");
                setTimeout(function() {
                    $('#success_message').html('');
                }, 5000);
            }
        }
    });
</script>

<?= $this->endsection(); ?>