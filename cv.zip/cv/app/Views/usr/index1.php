<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <!--    
        Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
        Perlu penyesuaian versi bootstrap dari 3.4.1 ke 5.1.3
    -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="sweetalert2.min.css">
</head>

<style>
      .corner1 {
        border-radius: 10px;
        color: blue;
        width: 600px;
        height: 40px;
    }
    .tgl {
        border-radius: 10px;
        color: blue;
        width: 200px;
        height: 40px;
    }
     /*https://stackoverflow.com/questions/47789667/table-cells-as-a-password-type*/
  .hidetext {
    -webkit-text-security: disc;
    /* Default */
  }
</style>

<body>
    <div class="container">
        <center>
            <h1 style="font-weight: bold; font-family: Georgia" ;>Daftar User</h1>
        </center>

        <button class="btn btn-success" onclick="add_user()"><i class="glyphicon glyphicon-plus"></i>Tambah</button>
        <br><br>
        <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama user</th>
                    <th>Password</th>
                    <th>e-Mail</th>
                    <th>Tgl. pembuatan</th>
                    <th style="width: 200px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $n = 0;
                    foreach ($users as $user) { 
                    $n++;
                    ?>
                    <tr>
                        <td><?php echo $n; ?></td>
                        <td id="namanya"><?php echo $user['username']; ?></td>
                        <td class="hidetext"><?php echo $user['password']; ?></td>
                        <td><?php echo $user['email']; ?></td>
                        <td><?php echo $user['created_at']; ?></td>
                        
                        <td>
                            <button class="btn btn-info" onclick="baca(<?php echo $user['id']; ?>)">Baca</button>
                            <button class="btn btn-warning" onclick="edit_user(<?php echo $user['id']; ?>)">Edit</button>
                            <button class="btn btn-danger" onclick="delete_user(<?php echo $user['id']; ?>)">Delete</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="sweetalert2.all.min.js"></script>
    <!--
    Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
    Perlu penyesuaian versi bootstrap dari 3.4.1 ke 5.1.3 (di atas)
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    -->

    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
        var save_method; //for save method string
        var table;

        function add_user() {
            save_method = 'add';
            $('#form')[0].reset(); // reset form on modals
            $('#btnSave').css("display", "true");
            $('#modal_form').modal('show'); // show bootstrap modal
            $('.modal-title').text('Tambah Data'); // Set Title to Bootstrap modal title
        }

        function baca(id) { //  Membaca data per ID
            $('#form')[0].reset(); // reset form on modals
            <?php header('Content-type: application/json'); ?>

            $.ajax({
                url: "/user/ajax_read/" + id,
                type: "GET",
                dataType: "JSON",

                success: function(data) {
                    console.log(data);
                    $('[name="id"]').val(data.id);
                    $('[name="username"]').val(data.username);
                    $('[name="password"]').val(data.password);
                    $('[name="email"]').val(data.email);
                    $('[name="created_at"]').val(data.created_at);
//                    $('#tanggal').css("display", "none");
                    $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                    $('.modal-title').text('Baca Data'); // Set title to Bootstrap modal title
                },
                complete: function() {
                    $("button#btnSave").css("display", "none");
                    $("button#btnTutup").css("background-color", "green");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR);
                    alert('Error baca data memakai ajax');
                }
            });
        }

        function edit_user(id) {
            save_method = 'update';
            //   alert(id);
            $('#form')[0].reset(); // reset form on modals
            <?php header('Content-type: application/json'); ?>
            //Ajax Load data from ajax
            $.ajax({
                url: "/user/ajax_edit/" + id,
                type: "GET",
                dataType: "JSON",
                success: function(data) {
                    console.log(data);
                    $('[name="id"]').val(data.id);
                    $('[name="username"]').val(data.username);
                    $('[name="password"]').val(data.password);
                    $('[name="email"]').val(data.email);
                    $('[name="created_at"]').val(data.created_at);
                 //   $('#tanggal').css("display", "true");
                    $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                    $('.modal-title').text('Edit Data'); // Set title to Bootstrap modal title
                    $("#btnSave").css("display", "true");
                    $("#btnSave").css("background-color", "green");
                },
                complete: function() {
                    $("button#btnSave").show();
                    $("button#btnSave").css("background-color", "green");
                    $("button#btnTutup").css("background-color", "red");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR);
                    alert('Error edit data memakai ajax');
                }
            });
        }

        function save() {
            var url;
            if (save_method == 'add') {
                url = "/user/user_add";
                judulSweet = 'Tambah';
            } else {
                url = "/user/update";
                judulSweet = 'Update';
            }
            $.ajax({
                url: url,
                type: "POST",
                data: $('#form').serialize(),
                dataType: "JSON",
                success: function(data) {
                    //if success close modal and reload ajax table
                    $('#modal_form').modal('hide');
                    location.reload(); // for reload a page
                    //  Tampilkan komentar Sweet Alert
                    Swal.fire(
                        judulSweet,
                        data.status,
                        'success'
                    );
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert('Error tambah / update data');
                }
            });
        }

        function delete_user(id) {
            namanya = $('#namanya').val();
          //  alert(namanya);
            Swal.fire({
                title: 'Apakah anda yakin menghapus data dengan id = ' + id,
                text: "Anda tidak bisa membatalkan !",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus !'
            }).then((result) => {
                if (result.isConfirmed) {

                    $.ajax({
                        url: "user/user_delete/" + id,
                        type: "POST",
                        dataType: "JSON",
                        success: function(data) {
                            location.reload();
                            //  Tampilkan komentar Sweet Alert
                            Swal.fire(
                                'Terhapus !',
                                data.status,
                                'success'
                            )
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            console.log(jqXHR);
                            alert('Error hapus data memakai ajax');
                        }
                    });
                }
            })
        }
    </script>

    <!-- Modal -->
    <div class="modal" id="modal_form" data-bs-backdrop="false" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="false">
        <div class="modal-dialog modal-xl" style="width: 1000px;">
            <div class="modal-content">
                <div class="modal-header">

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">x</button>
                </div>
                <center>
                    <h1 class="modal-title" style="font-weight: bold; font-family: Georgia" ;>Judul</h1>
                </center>
                
                <div class="modal-body" style="width: 900px;">
                    <form action="#" id="form" class="form-horizontal">
                        <input type="hidden" value="" name="id" />
                        <div class="form-body">
                            <div class="form-group">
                                <label class="control-label col-sm-3">Nama user</label>
                                <div class="col-md-9">
                                    <input name="username" placeholder="Nama user" class="form-control corner1" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Password</label>
                                <div class="col-md-9">
                                    <input name="password" placeholder="Password" class="form-control corner1 hidetext" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">e-Mail</label>
                                <div class="col-md-9">
                                    <input name="email" placeholder="e-Mail" class="form-control corner1" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Tgl. pembuatan</label>
                                <div class="col-md-9">
                                    <input name="created_at" id="tanggal" class="form-control tgl" type="date" onchange="sesuaikan()">
                                </div>
                                <div class="col-md-9">
                                    <input name="created_at" id="tanggal1" class="form-control tgl" type="hidden">
                                </div>
                            </div>
                            
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" id="btnTutup" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                    <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </div>
    </div>
<script>
    function sesuaikan() {
        const tgl = new Date(document.getElementById('tanggal').value);
        //Mengubah ke format MySQL
        month = '' + (tgl.getMonth() + 1),
            day = '' + tgl.getDate(),
            year = tgl.getFullYear();
        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;
        tanggal = year + '-' + month + '-' + day;
      //  alert(tanggal);
        document.getElementById('tanggal1').value = tanggal;
     //   alert(document.getElementById('tanggal1').value);
    }
</script>

</body>
<?= $this->endsection(); ?>