<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        #header {
            position: relative;
            padding-top: 0px;
            left: 0px;
            top: 0px;
            right: 0px;
            height: 60px;
            background-color: green;
            text-align: center;
            color: white;
            font-variant-caps: all-petite-caps;
            font-size: large;
        }

        .spasi-thead {
            margin-top: 5px;
        }

        .gbr {
            position: fixed;
            left: 50px;
            top: 500px;
            right: 0px;
            margin-left: -70px;
            margin-top: 0px;
            color: lightgrey;
            opacity: 0.2;
            font-size: 300px;
            transform: rotate(50deg);
            -webkit-transform: rotate(-40deg);
        }

        /*https://stackoverflow.com/questions/1542320/margin-while-printing-html-page*/
        @page Section1 {
            margin-top: 15in;
            margin-bottom: 15in;
            size: 9in 11in;
            margin: 1in 0in .5in 0in;
            mso-header-margin: 5in;
            mso-footer-margin: 5in;
            mso-paper-source: 0;
        }

        div.Section1 {
            @page: Section1;
        }
    </style>
    <!------------------------Fontawesome------------------------------------------------------------------>
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <!------------------------Fontawesome------------------------------------------------------------------>

</head>

<body>

    <div class="Section1">
        <div style="vertical-align:middle; font-weight:bold;" id="header">
            <h1>
                <center>DAFTAR RIWAYAT HIDUP</center>
            </h1>
            <br>
            <button type="button" onClick="cetak()" style="background: white" id="myDIV">
                <i class="fa-solid fa-print" title="Cetak Riwayat Hidup"></i>
            </button>

        </div>

        <?php
        if ($ta) {
            $skrg = date('d-M-Y');
            $posisi = isset($ta['posisi']) ? $ta['posisi'] : '';
            $nama = isset($ta['nama']) ? $ta['nama'] : '';
        }
        ?>
        <!-- <div style="position:relative; margin-top: 100px; ">-->
        <img class="gbr" style="width:800px;" src='<?= base_url("/img/LogoQuantum.jpeg") ?>'>

        <table style="border: 1px; margin-left: 10px; margin-right: 10px; margin-top: 5px">
            <thead>
                <tr>
                    <td>
                        <!--place holder for the fixed-position header-->
                        <div class="spasi-thead"></div>
                    </td>
                </tr>
            </thead>

            <tbody>
                <tr>
                    <td style="column-width:500px">1. Posisi yang diusulkan</td>
                    <td style="column-width:5px">:</td>
                    <td style="column-width:1200px"><?= $posisi ?></td>
                </tr>
                <tr>
                    <td>2. Nama perusahaan</td>
                    <td>:</td>
                    <td><?= $ta['perusahaan'] ?></td>
                </tr>
                <tr>
                    <td>3. Nama personil</td>
                    <td>:</td>
                    <td><?= $ta['nama'] ?></td>
                </tr>
                <tr>
                    <td>4. Tempat lahir</td>
                    <td>:</td>
                    <td><?= $ta['kota'] ?></td>
                </tr>
                <tr>
                    <td>5. Tanggal lahir</td>
                    <td>:</td>
                    <td><?= $tgl_lahir ?></td>
                </tr>
                <tr>
                    <td>6. No. NPWP</td>
                    <td>:</td>
                    <td><?= $ta['no_npwp'] ?></td>
                </tr>
                <tr>
                    <td>7. No. Telp.</td>
                    <td>:</td>
                    <td><?= $ta['no_telp'] ?></td>
                </tr>
                <tr>
                    <td>8. No. HP</td>
                    <td>:</td>
                    <td><?= $ta['no_hp'] ?></td>
                </tr>
            </tbody>

            <tfoot>
                <tr>
                    <td>
                        <!--place holder for the fixed-position footer-->
                        <div class="page-footer-space"></div>
                    </td>
                </tr>
            </tfoot>

        </table>


        <table style="margin-left: 10px; margin-right: 10px; margin-top: 5px;">

            <thead>
                <tr>
                    <td>
                        <!--place holder for the fixed-position header-->
                        <div class="spasi-thead"></div>
                    </td>
                </tr>
            </thead>

            <tr>
                <td><b>Pendidikan :</b></td>
            </tr>
            <?php
            foreach ($pendidikan as $v) {
                $strata = isset($v['strata']) ? $v['strata'] : '';
                if ($strata != '') { ?>

                    <tr>
                        <td><?= $v['strata'] ?></td>
                    </tr>
                    <tr>
                        <td style="column-width:300px">Jurusan</td>
                        <td style="column-width:5x">:</td>
                        <td style="column-width:450px"><?= $v['jurusan'] ?></td>
                    </tr>
                    <tr>
                        <td>Universitas</td>
                        <td>:</td>
                        <td><?= $v['universitas'] ?></td>
                    </tr>
                    <tr>
                        <td>Tahun lulus</td>
                        <td>:</td>
                        <td><?= $v['thn_lulus'] ?></td>
                    </tr>

                <?php

                }  ?>
                <tr>

                </tr>
            <?php
            }
            ?>
        </table>


        <table style="margin-left: 10px; margin-right: 10px; margin-top: 5px;">

            <thead>
                <tr>
                    <td>
                        <!--place holder for the fixed-position header-->
                        <div class="spasi-thead"></div>
                    </td>
                </tr>
            </thead>
            <tr>
                <td><b>Sertifikat :</b></td>
            </tr>
            <?php
            foreach ($srt as $v) {
                $SertTgl = isset($v['tgl_kadaluarsa']) ? $v['tgl_kadaluarsa'] : '';
                if ($SertTgl != '0000-00-00' && $SertTgl != null && $SertTgl != '') {
                    $tgl = substr($SertTgl, 8, 2);
                    $bln = substr($SertTgl, 5, 2);
                    //  Memanggil helper 
                    helper('custom_helper'); // Loading single helper
                    //  Memanggil fungsi NamaBulan() untuk mencetak nama-nama bulan
                    $bulan = NamaBulan($bln);
                    $thn = substr($SertTgl, 0, 4);
                    $tanggalKadaluarsa = $tgl . ' ' . $bulan . ' ' . $thn;
                } else {
                    $tanggalKadaluarsa = '';
                } ?>
                <tr>
                    <td><?= $v['nama_sertifikat'] ?> , nomor: <?= $v['nomor_sertifikat'] ?> , kadaluarsa : <?= $tanggalKadaluarsa ?></td>
                </tr>
            <?php
            }
            ?>
        </table>

        <table style="margin-left: 10px; margin-right: 10px; margin-top: 5px;">
            <thead>
                <tr>
                    <td>
                        <!--place holder for the fixed-position header-->
                        <div class="spasi-thead"></div>
                    </td>
                </tr>
            </thead>
            <tr>
                <td><b>Bahasa :</b></td>
            </tr>
            <?php
            foreach ($bhs as $v) {
            ?>
                <tr>
                    <td>Bahasa Indonesia : <?= $v['nilai_bhs_indo'] ?> , Bahasa Inggris : <?= $v['nilai_bhs_inggris'] ?> ,
                        Bahasa Daerah : <?= $v['nilai_bhs_setempat'] ?></td>
                </tr>
            <?php
            }
            ?>
        </table>
        <br><br>
        <b style="width: max-content;">Pengalaman diluar Quantum :</b>
        <table style="margin-left: 10px; margin-right: 10px; margin-top: 0px; padding-top:5px;">
            <thead>
                <tr>
                    <td>
                        <!--place holder for the fixed-position header-->
                        <div class="spasi-thead"></div>
                    </td>
                </tr>

            </thead>
            <?php
            $n = 0;
            if (count($pengalamanNonQ) > 0) {
                foreach ($pengalamanNonQ as $v) {
                    $kode_posisi = $v['kode_posisi'];
                    $posisi = new \App\Models\posisiModel();
                    $positions = $posisi->CariKodePosisi($kode_posisi);
                    $posisitugas = $positions['posisitugas'];
                    $uraiantugas = $positions['uraiantugas'];
                    $uraiantugas = str_replace("&lt;ol&gt;", "<ol>", $uraiantugas);
                    $uraiantugas = str_replace("&lt;/ol&gt;", "</ol>", $uraiantugas);
                    $uraiantugas = str_replace("&lt;li&gt;", "<li>", $uraiantugas);
                    $uraiantugas = str_replace("&lt;/li&gt;", "</li>", $uraiantugas);
                    $uraiantugas = str_replace("&amp;nbsp;", "", $uraiantugas);

                    //  Konversi format tanggal mulai, contoh : 1 Januari 2023 
                    $mulai = isset($v['mulai']) ? $v['mulai'] : '';
                    if ($mulai != null && $mulai != '0000-00-00' && $mulai != '') {
                        $tgl = substr($mulai, 8, 2);
                        $bln = substr($mulai, 5, 2);
                        //  Memanggil helper 
                        helper('custom_helper'); // Loading single helper
                        //  Memanggil fungsi NamaBulan() untuk mencetak nama-nama bulan
                        $bulan = NamaBulan($bln);
                        $thn = substr($mulai, 0, 4);
                        $mulai = $tgl . ' ' . $bulan . ' ' . $thn;
                    }
                    //  Konversi format tanggal selesai, contoh : 1 Januari 2023
                    $selesai = isset($v['selesai']) ? $v['selesai'] : '';
                    if ($selesai != null && $selesai != '0000-00-00' && $selesai != '') {
                        $tgl = substr($selesai, 8, 2);
                        $bln = substr($selesai, 5, 2);
                        //  Memanggil helper 
                        helper('custom_helper'); // Loading single helper
                        //  Memanggil fungsi NamaBulan() untuk mencetak nama-nama bulan
                        $bulan = NamaBulan($bln);
                        $thn = substr($selesai, 0, 4);
                        $selesai = $tgl . ' ' . $bulan . ' ' . $thn;
                    }

            ?>
                    <tr>
                        <td style="background-color:lightblue; margin-top: 0px; colspan:3; column-width:1500px">Tahun : <?= $v['tahun'] ?></td>
                    </tr>
                    <tr>
                        <td style="column-width:700px">a. Nama kegiatan</td>
                        <td style="column-width:5px">:</td>
                        <td style="column-width:700px"><?= $v['pekerjaan'] ?></td>
                    </tr>
                    <tr>
                        <td>b. Lokasi kegiatan</td>
                        <td>:</td>
                        <td><?= $v['lokasi'] ?></td>
                    </tr>
                    <tr>
                        <td>c. Pengguna jasa</td>
                        <td>:</td>
                        <td><?= $v['nama_instansi'] ?></td>
                    </tr>
                    <tr>
                        <td>d. Nama Perusahaan</td>
                        <td>:</td>
                        <td><?= $v['nama_perusahaan'] ?></td>
                    </tr>
                    <tr>
                        <td>e. Uraian Tugas</td>
                        <td>:</td>
                        <td><?= $uraiantugas ?></td>
                    </tr>
                    <tr>
                        <td>f. Waktu Pelaksanaan</td>
                        <td>:</td>
                        <td><?= $mulai ?> - <?= $selesai ?></td>
                    </tr>
                    <tr>
                        <td>g. Posisi Penugasan</td>
                        <td>:</td>
                        <td><?= $posisitugas ?></td>
                    </tr>
                    <tr>
                        <td>h. Status Kepegawaian</td>
                        <td>:</td>
                        <td><?= $v['status_kepegawaian'] ?></td>
                    </tr>
                    <tr>
                        <td>i. Surat Referensi</td>
                        <td>:</td>
                        <td><?= $v['surat_referensi'] ?></td>
                    </tr>
            <?php
                    $n++;
                }
            }
            ?>
        </table>

        <table style="margin-left: 10px; margin-right: 10px; margin-top: 10px; padding-top:5px;">
            <thead>
                <tr>
                    <td>
                        <!--place holder for the fixed-position header-->
                        <div class="spasi-thead"></div>
                    </td>
                </tr>
            </thead>

            <tr>
                <td><b>Pengalaman proyek Quantum :</b></td>
            </tr>
            <?php
            $n = 0;
            if (count($pengalaman) > 0) {
                foreach ($pengalaman as $v) {
                    //  Mengupas (menghilangkan HTML) agar tampilan uraian tugas lebih rapi
                    $uraiantugas = $pengalaman[$n]['uraiantugas'];
                    $uraiantugas = str_replace("&lt;ol&gt;", "<ol>", $uraiantugas);
                    $uraiantugas = str_replace("&lt;/ol&gt;", "</ol>", $uraiantugas);
                    $uraiantugas = str_replace("&lt;li&gt;", "<li>", $uraiantugas);
                    $uraiantugas = str_replace("&lt;/li&gt;", "</li>", $uraiantugas);
                    $uraiantugas = str_replace("&amp;nbsp;", "", $uraiantugas);

                    //  Konversi format tanggal mulai, contoh : 1 Januari 2023 
                    $mulai = isset($v['mulai']) ? $v['mulai'] : '';
                    if ($mulai != null && $mulai != '0000-00-00' && $mulai != '') {
                        $tgl = substr($mulai, 8, 2);
                        $bln = substr($mulai, 5, 2);
                        //  Memanggil helper 
                        helper('custom_helper'); // Loading single helper
                        //  Memanggil fungsi NamaBulan() untuk mencetak nama-nama bulan
                        $bulan = NamaBulan($bln);
                        $thn = substr($mulai, 0, 4);
                        $mulai = $tgl . ' ' . $bulan . ' ' . $thn;
                    }
                    //  Konversi format tanggal selesai, contoh : 1 Januari 2023
                    $selesai = isset($v['selesai']) ? $v['selesai'] : '';
                    if ($selesai != null && $selesai != '0000-00-00' && $selesai != '') {
                        $tgl = substr($selesai, 8, 2);
                        $bln = substr($selesai, 5, 2);
                        //  Memanggil helper 
                        helper('custom_helper'); // Loading single helper
                        //  Memanggil fungsi NamaBulan() untuk mencetak nama-nama bulan
                        $bulan = NamaBulan($bln);
                        $thn = substr($selesai, 0, 4);
                        $selesai = $tgl . ' ' . $bulan . ' ' . $thn;
                    }

            ?>

                    <tr>
                        <td style="background-color:lightblue;">Tahun : <?= $v['tahun'] ?></td>
                    </tr>
                    <tr>
                        <td style="column-width:700px">a. Nama kegiatan</td>
                        <td style="column-width:5px">:</td>
                        <td style="column-width:700px"><?= $v['pekerjaan'] ?></td>
                    </tr>
                    <tr>
                        <td>b. Lokasi kegiatan</td>
                        <td>:</td>
                        <td><?= $v['lokasi'] ?></td>
                    </tr>
                    <tr>
                        <td>c. Pengguna jasa</td>
                        <td>:</td>
                        <td><?= $v['instansi'] ?></td>
                    </tr>
                    <tr>
                        <td>d. Nama Perusahaan</td>
                        <td>:</td>
                        <td>PT. QUANTUM HRM INTERNASIONAL</td>
                    </tr>
                    <tr>
                        <td>e. Uraian Tugas</td>
                        <td>:</td>
                        <td><?= $uraiantugas ?></td>
                    </tr>
                    <tr>
                        <td>f. Waktu Pelaksanaan</td>
                        <td>:</td>
                        <td><?= $mulai ?> - <?= $selesai ?></td>
                    </tr>
                    <tr>
                        <td>g. Posisi Penugasan</td>
                        <td>:</td>
                        <td><?= $v['posisitugas'] ?></td>
                    </tr>
                    <tr>
                        <td>h. Status Kepegawaian</td>
                        <td>:</td>
                        <td><?= $status ?></td>
                    </tr>
                    <tr>
                        <td>i. Surat Referensi</td>
                        <td>:</td>
                        <td><?= $v['referensi'] ?></td>
                    </tr>
            <?php
                    $n++;
                }
            }
            ?>
        </table>


        <section> <!--style="page-break-inside: avoid-->
            <div style="page-break-inside: avoid; padding-top:75px; margin-left: 10px; margin-right: 10px; ">
                <p style="font-size:14px;font-family:Times New Roman">Pernyataan :</p>
                <ol style="font-size:14px;font-family:Times New Roman">
                    <li>Daftar riwayat hidup ini sesuai dengan kualifikasi dan pengalaman saya</li>
                    <li style="text-align: justify;">Saya akan melaksanakan penugasan sesuai dengan waktu yang telah dijadwalkan
                        dalam proposal penawaran, kecuali terdapat permasalahan kesehatan yang mengakibatkan saya tidak bisa melaksanakan tugas</li>
                    <li>Saya berjanji melaksanakan semua penugasan</li>
                    <li>Saya bukan merupakan bagian dari tim yang menyusun Kerangka Acuan Kerja</li>
                    <li>Saya akan memenuhi semua ketentuan Klausul 4 dan 5 pada IKP</li>
                </ol>
                <p style="text-align:justify;font-size:14px;font-family:Times New Roman">Jika terdapat pengungkapan
                    keterangan yang tidak benar secara sengaja atau sepatutnya diduga
                    maka saya siap untuk digugurkan dari proses seleksi atau dikeluarkan jika sudah dipekerjakan.</p>

                <table>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>Surabaya, <?= $skrg ?></td>
                    </tr>

                    <tr>
                        <td style="width: 200px;">Mengetahui, </td>
                        <td style="width: 300px;"></td>
                        <td style="width: 200px;">Yang membuat pernyataan</td>
                    </tr>
                    <tr>
                        <?php
                        //	Jika nama TA = Pribadiyono,Ir., MS., Dr., Prof, 
                        //	maka yang tanda tangan Bu Nuri, sebagai Komisaris Utama
                        if ($ta['nama'] == "Pribadiyono,Ir., MS., Dr., Prof") {  ?>
                            <td><img src="<?= base_url('/tt/Nuri.jpeg') ?>" style="width:200px; height:100px"></td>
                        <?php
                        } else {
                            //	Jika nama TA <> Pribadiyono,Ir., MS., Dr., Prof, 
                            //	maka yang tanda tangan Pribadiyono,Ir., MS., Dr., Prof, sebagai Direktur
                        ?>
                            <td><img src="<?= base_url('/tt/Pribadiyono.jpg') ?>" style="width:200px; height:100px"></td>
                        <?php
                        }
                        ?>

                        <td></td>
                        <!-- Variabel $tt diperoleh dari controller CV, rhModel->getViewTandaTangan($kode) > view_tt -->
                        <?php
                        //	Jika nama TA = Pribadiyono,Ir., MS., Dr., Prof, 
                        //	maka yang tanda tangan Pribadiyono,Ir., MS., Dr., Prof, sebagai Direktur

                        if ($ta['nama'] == "Pribadiyono,Ir., MS., Dr., Prof") {  ?>
                            <td><img src="<?= base_url('/tt/Pribadiyono.jpg') ?>" style="width:200px; height:100px"></td>
                        <?php
                        } else
                        //	Jika nama TA <> Pribadiyono,Ir., MS., Dr., Prof, 
                        //	maka yang tanda tangan tenaga ahli masing-masing
                        {
                        ?>
                            <td><img src="<?= base_url($tt) ?>" style="width:200px; height:100px"></td>
                        <?php
                        }
                        ?>


                    </tr>
                    <?php
                    $direktur = '';
                    $jabatan = '';
                    if ($ta['nama'] == "Pribadiyono,Ir., MS., Dr., Prof") {
                        $direktur = 'Noeri Djati Perwitasari, S.Psi., M.Psi';
                        $jabatan = 'Komisaris Utama';
                        $ta = 'Pribadiyono,Ir., MS., Dr., Prof';
                    } else {
                        $direktur = 'Pribadiyono Prof. Dr., Ir., MS.';
                        $jabatan = 'Direktur';
                        $ta = $ta['nama'];
                    }
                    ?>
                    <tr>
                        <td style="width: 200px;"><?= $direktur ?></td>
                        <td></td>
                        <td style="width: 200px;"><?= $ta ?></td>
                    </tr>
                    <tr>
                        <td><?= $jabatan ?></td>
                        <td></td>

                        <td></td>
                    </tr>

                </table>
                <br><br>
            </div>
        </section><!--style="page-break-inside: avoid-->
    </div> <!--<div class="Section1"> -->
</body>

<script>
    //  Ini hanya untuk menyembunyikan tombol saat dicetak
    function cetak() {
        var x = document.getElementById("myDIV");
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
        /*https://plnkr.co/edit/lWk6Yd?preview*/
        window.print();
    }
</script>

</html>