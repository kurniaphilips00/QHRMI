<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
<style>
        .no_edit {
        border-radius: 5px;
        background-color: #1dbcdb;
        color: white;
        width: 700px;
        height: 40px;
        font-family: "Times New Roman", Times, serif;
        font-weight: bold;
        color: black;
    }
       .pendek {
        border-radius: 5px;
        background-color: #1659c4;
        color: white;
        width: 415px;
        height: 40px;
        margin-right: 10px;
    }
</style>
<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">

                    <!-- /.card-header -->
                    <div class="card-body">
                        <form action="<?= route_to('old-exp/edit') ?>" method="post">

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Pengalaman</label>
                                <div class="col-sm-10">
                                    <input type="text" class="no_edit" 
                                    value="<?= $expert['kode_pengalaman'] ?>" readonly>

                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Proyek</label>
                                <div class="col-sm-10">
                                    <input type="text" class="no_edit" 
                                    value="<?= $expert['kode_proyek'] ?>" readonly>

                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kegiatan(pekerjaan)</label>
                                <div class="col-sm-10">
                                    <input type="text" class="no_edit" name="kegiatan" 
                                    value="<?= $expert['nama_pekerjaan'] ?>" readonly>

                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Instansi</label>
                                <div class="col-sm-8">
                                    <input type="text" class="no_edit" readonly 
                                    value="<?= $expert['nama_instansi'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Tenaga Ahli</label>
                                <div class="col-sm-10">
                                    <input type="text" class="no_edit" readonly 
                                    value="<?= $expert['kode_ta'] ?>">
                                </div>
                            </div>


                            <div class="mb-3 row">
                                <label for="Nama_Personil" class="col-sm-2 col-form-label">Nama Tenaga Ahli</label>
                                <div class="col-sm-10">
                                    <input type="text" class="no_edit" readonly 
                                    name="nama_TA" id="Nama_Personil" value="<?= $expert['nama_ta'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Posisi</label>
                                <div class="col-sm-8">
                                    <input type="text" class="no_edit" readonly 
                                    value="<?= $expert['kode_posisi'] ?>">
                                </div>
                            </div>


                            <div class="mb-3 row">
                                <label for="jabatan" class="col-sm-2 col-form-label">Posisi Tugas</label>
                                <div class="col-sm-8">
                                    <input type="text" class="no_edit" readonly 
                                    name="posisi" id="jabatan" value="<?= $expert['posisitugas'] ?>">
                                </div>
                            </div>

                            <br>

                            <a href="/old-exp/" class="btn btn-primary m-2" style="height: 40px; width: 100px"><i class="fa-solid fa-circle-left"></i></i> Kembali</a>
                            
                        </form>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<script>
    function IsiNama() {
        const sel = document.getElementById("ta_ID");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("Nama_Personil").value = teks;
    }

    function IsiJabatan() {
        const sel = document.getElementById("positions");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("jabatan").value = teks;
    }

    function IsiID() {

        let ta = document.getElementById('ta_ID').value;
        const sel = document.getElementById("ta_ID");
        sel.options[sel.selectedIndex].text = ta;
    }

    function ShowExperts($id) {
        //      let nama = document.getElementById('#intermitten').innerText;
        window.location.href = "/ExpertsList/" + $id
    }

    function IsiIDPekerjaan() {
        let idKegiatan = document.getElementById('pekerjaan').value;
        const sel = document.getElementById("pekerjaan");
        sel.options[sel.selectedIndex].text = idKegiatan;
    }

    function IsiPekerjaan() {
        const sel = document.getElementById("pekerjaan");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("aktifitas").value = teks;
    }
</script>
<!-- Start ckEditor 4 -->
<script src="//cdn.ckeditor.com/4.20.1/full/ckeditor.js"></script>
<script>
    CKEDITOR.replace('editor1');
</script>
<!--    End ckEditor 4 -->
<?= $this->endsection(); ?>