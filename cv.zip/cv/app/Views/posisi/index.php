<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <link rel="stylesheet" href="sweetalert2.min.css">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
</head>

<style>
    .corner1 {
        border-radius: 10px;
        background-color: green;
        color: whitesmoke;
        width: 600px;
        height: 40px;
        font: weight 10px;
        font-size: medium;
        font-family: Georgia;
    }

    .corner {
        border-radius: 10px;
        background-color: green;
        color: whitesmoke;
        width: 120px;
        height: 40px;
        font: weight 10px;
        ;
        font-size: medium;
        font-family: Georgia;
    }

    .modal {
        display: none;
        /* Hidden by default */
        position: fixed;
        /* Stay in place */
        z-index: 1;
        /* Sit on top */
        padding-top: 100px;
        padding-left: 300px;
        /* Location of the box */
        left: 100;
        top: 0;
        width: 100%;
        /* Full width */
        height: 100%;
        /* Full height */
        overflow: auto;
        /* Enable scroll if needed */
        background-color: rgb(0, 0, 0);
        /* Fallback color */
        background-color: rgba(0, 0, 0, 0.4);
        /* Black w/ opacity */

    }

    .judul {
        padding-left: 250px;
        font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        font-weight: 900;
    }

    /* Modal Content */
    .modal-content {
        background-color: #fefefe;
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
    }

    /* The Close Button */
    .close {
        color: #aaaaaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: #000;
        text-decoration: none;
        cursor: pointer;
    }
</style>

<body>
    <div class="container">
        <center>
            <h1 style="font-weight: bold; font-family: Georgia" ;>Daftar Posisi</h1>
        </center>
        <button type="button" title="Tambah Data" id="tombol_tambah" class="corner"><i class="fas fa-plus-circle"></i>Tambah</button>

        <br><br>
        <table id="example1" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Kode</th>
                    <th>Posisi</th>
                    <th>Uraian</th>
                    <th style="width: 200px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $n = 0;
                foreach ($posisi as $position) {
                    $uraiantugas = isset($v['uraiantugas']) ? $v['uraiantugas'] : '';
                    $n++;
                ?>
                    <tr>
                        <td><?php echo $n; ?></td>
                        <td><?php echo $position['kode_posisi']; ?></td>
                        <td><?php echo $position['posisitugas']; ?></td>
                        <td><?php echo $position['uraiantugas']; ?></td>
                        <td>
                            <button class="btn btn-info" onclick="baca(<?php echo $position['id']; ?>)">Baca</button>
                            <button class="btn btn-warning" onclick="edit_posisi(<?php echo $position['id']; ?>)">Edit</button>
                            <button class="btn btn-danger" onclick="delete_posisi(<?php echo $position['id']; ?>)">Delete</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <!-- My Modal diambil dari https://www.w3schools.com/howto/howto_css_modals.asp (modal tanpa bootstrap)-->
        <div id="add_post_modal" class="modal">
            <!-- Modal content -->
            <div class="modal-content">
                <span class="close">&times;</span>
                <h1 class="judul">Posisi</h1>
                <form action="#" id="add_post_form" class="form-horizontal">
                    <input type="hidden" value="" name="id" />
                    <div class="form-body">
                        <div class="form-group" id="kodeposisi"> <!--id=kodeposisi untuk menyembunyikan input kode, karena dihitung di controller-->
                            <label class="control-label col-sm-2">Kode posisi</label>
                            <div class="col-md-9">
                                <input name="kode_posisi" id="detil_kode_posisi" type="text" placeholder="Kode posisi" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Posisi</label>
                            <div class="col-md-9">
                                <input name="posisitugas" id="detil_posisitugas" type="text" id="posisi_err" placeholder="Posisi tugas" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Uraian tugas</label>
                            <div class="col-md-9">
                                <textarea name="uraiantugas" id="summernote" cols="100" rows="11"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="btnTutup" onclick="tutup()" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" id="add_post_btn" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>

        <script>
            function baca(id) { //  Membaca data per ID
                //  Memakai modal dari bootstrap
                $('#form')[0].reset();
                <?php header('Content-type: application/json'); ?>

                $.ajax({
                    url: "/posisi/baca/" + id,
                    type: "GET",
                    dataType: "JSON",
                    success: function(data) {
                        console.log(data);
                        $('#kodeposisi').show();
                        $('[name="id"]').val(data.id);
                        $('[name="kode_posisi"]').val(data.kode_posisi);
                        $('[name="posisitugas"]').val(data.posisitugas);
                        $('[name="uraiantugas"]').val(data.uraiantugas);
                        $('#modal_form').modal('show');
                        $('.judul').text('Baca Data'); // Set title to Bootstrap modal title
                    },
                    complete: function() {
                        
                        $("button#btnSave").css("display", "none");
                        $("button#btnTutup").css("background-color", "green");
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR);
                        alert('Error baca data memakai ajax');
                    }
                });
            }

            function edit_posisi(id) {                  //  Memakai modal dari bootstrap
                $('#form')[0].reset();                  //  Reset form di dalam modal
                <?php header('Content-type: application/json'); ?>
                $.ajax({
                    url: "/posisi/edit/" + id,
                    type: "GET",
                    dataType: "JSON",
                    success: function(data) {
                        console.log(data);

                        $("#kodeposisi").prop("readonly", true);
                        
                        $('[name="id"]').val(data.id);
                        $('[name="kode_posisi"]').val(data.kode_posisi);
                        $('[name="posisitugas"]').val(data.posisitugas);
                        $('[name="uraiantugas"]').val(data.uraiantugas);
                        

                        $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                        $('.modal-title').text('Edit Data'); // Set title to Bootstrap modal title
                        $("#btnSave").css("display", "true");
                        $("#btnSave").css("background-color", "green");
                    },
                    complete: function() {
                        $("button#btnSave").show();
                        $("button#btnSave").css("background-color", "green");
                        $("button#btnTutup").css("background-color", "red");
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(jqXHR);
                        alert('Error edit data memakai ajax');
                    }
                });
            }
            function update() {
                $.ajax({
                    url: "/posisi/update",
                    type: "POST",
                    data: $('#form').serialize(),
                    dataType: "JSON",
                    success: function(data) {
                        //if success close modal and reload ajax table
                        $('#modal_form').modal('hide');
                        location.reload(); // for reload a page
                        //  Tampilkan komentar Sweet Alert
                        Swal.fire(
                            "Update",
                            data.status,
                            'success'
                        );
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        alert('Error tambah / update data');
                    }
                });
            }


            $(function() {
                // Tambah data memakai modal tanpa bootstrap ( menggunakan CSS )
                $("#add_post_form").submit(function(e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    $("#add_post_btn").text("Adding...");
                    $.ajax({
                        url: '<?= base_url('posisi/tambah') ?>',
                        method: 'post',
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        dataType: 'json',
                        success: function(response) {
                            if (response.error) {
                                $("#posisi_err").addClass('is-invalid');
                                $("#posisi_err").next().text(response.status);
                            } else {
                                location.reload();
                                $("#add_post_modal").modal('hide');
                                $("#add_post_form")[0].reset();
                                $("#posisi_err").removeClass('is-invalid');
                                $("#posisi_err").next().text('');
                                $("#add_post_form").removeClass('was-validated');
                                Swal.fire(
                                    'Simpan',
                                    response.status,
                                    'success'
                                );
                            }
                            $("#add_post_btn").text("Add Post");
                        }
                    });
                });
            });

            function delete_posisi(id) {
                // preventDefault();
                Swal.fire({
                    title: 'Apakah anda yakin menghapus data dengan id = ' + id,
                    text: "Anda tidak bisa membatalkan !",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, hapus !'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "posisi/hapus/" + id,
                            type: "POST",
                            dataType: "JSON",
                            success: function(data) {
                                location.reload();
                                //  Tampilkan komentar Sweet Alert
                                Swal.fire(
                                    'Terhapus !',
                                    data.status,
                                    'success'
                                )
                            },
                            error: function(jqXHR, textStatus, errorThrown) {
                                console.log(jqXHR);
                                alert('Error hapus data memakai ajax');
                            }
                        });
                    }
                })
            }
        </script>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="sweetalert2.all.min.js"></script>

    <!--    Modal memakai bootstrap 
            Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
        -->
    <div class="modal" id="modal_form" data-bs-backdrop="false" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="false">
        <div class="modal-dialog" style="width: 100%; margin-left:-15%">
            <div class="modal-content">
                <div class="modal-header">

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">x</button>
                </div>

                <h2 class="modal-title judul" style="margin-left: 100px;">Modal title</h2>

                <div class="modal-body">
                    <form action="#" id="form" class="form-horizontal">
                        <input type="hidden" value="" name="id" />
                        <div class="form-body">
                            <div class="form-group" id="kodeposisi">
                                <label class="control-label col-sm-2">Kode posisi</label>
                                <div class="col-md-9">
                                    <input name="kode_posisi" placeholder="Kode posisi" style="color:black"
                                    class="form-control corner1" type="text" readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Posisi tugas</label>
                                <div class="col-md-9">
                                    <input name="posisitugas" placeholder="Posisi tugas" class="form-control corner1" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Uraian tugas</label>
                                <div class="col-md-9">
                                    <textarea name="uraiantugas" style="height: 250px; width: 595px" id="summernote" cols="90" rows="15"></textarea>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" id="btnTutup" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                    <button type="button" id="btnSave" onclick="update()" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </div>
    </div>
    <script>
        // Get the modal
        var modal = document.getElementById("add_post_modal");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // Tombol untuk menambah data (+)
        var btn = document.getElementById("tombol_tambah");


        // Tombol tambah diklik, tampilkan modal 
        btn.onclick = function() {
            modal.style.display = "block";
            save_method = 'add';
            $('#add_post_form')[0].reset(); // reset form on modals
            $('.judul').text('Tambah Data Posisi'); // Judul modal
            $('#kodeposisi').hide(); //  Sembunyikan field kode
        }

        // Jika tombol <span> (x) diklik, tutup modal
        span.onclick = function() {
            modal.style.display = "none";
        }
    </script>

    <script>
        function tutup() {
            //  Ini untuk menutup modal melalui tombol tutup (berwarna merah)
            var modal = document.getElementById("add_post_modal");
            modal.style.display = "none";
        }
    </script>

    <!--Summernote untuk mengisi textarea-->
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script>
        $('#summernote').summernote({
            placeholder: 'Ketik uraian tugas',
            tabsize: 2,
            height: 120,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'clear']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['table', ['table']],
                ['insert', ['link', 'picture', 'video']],
                ['view', ['fullscreen', 'codeview', 'help']]
            ]
        });
    </script>
</body>
<?= $this->endsection(); ?>