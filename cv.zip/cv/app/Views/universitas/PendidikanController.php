<?php

namespace App\Controllers;

use App\Models\rhModel;
use App\Models\eduModel;
use App\Controllers\BaseController;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PDO;

class PendidikanController extends BaseController
{
    protected $taModel;
    protected $eduModel;

    public function __construct()
    {
        //  ta diperlukan untuk menampilkan nama pada...
        // drop down pilihan nama tenaga ahli (index & modal tambah)
        $ta = $this->taModel = new rhModel();
        $pendidikan = $this->eduModel = new eduModel();
    }
    public function index()
    {
        if (session()->get('id')) {
            $ta = $this->taModel->getCV();
            $pendidikan = $this->eduModel->getPendidikan();
            $data = [
                'judul' => 'Data Pendidikan Tenaga Ahli',
                'ta' => $ta,
                'pendidikan' =>  $pendidikan
            ];
            return view('pendidikan/index', $data);
        } else
            return redirect()->to('/');
    }
    public function FilterByName($nama)
    {
        return $this->index($nama);
    }
    public function tambah()
    {
        if (session()->get('id')) {
            $taKode = $this->taModel->getTAOrderByKode(); // Untuk memilih Tenaga Ahli urut berdasarkan ID
            $taName = $this->taModel->getTAOrderByName(); // Untuk memilih Tenaga Ahli urut berdasarkan nama
            $pendidikan = $this->eduModel->getPendidikan();
            $n = 0;
            foreach ($taName as $val) {
                $nama[$n] = $val['nama'];
                $kode[$n] = $val['kode_ta'];
                $n++;
            }
            $data = [
                'judul' => 'Tambah Data Pendidikan',
                'taKode' => $taKode,
                'taName' => $taName,
                'pendidikan' =>  $pendidikan,
                'nama' => $nama,
                'kode' => $kode,
                'validation' => \Config\Services::validation()
            ];
            return view('pendidikan/tambah', $data);
        } else
            return redirect()->to('/');
    }
    public function simpan()
    {
        $rules = $this->validate([
            'kode_ta'      => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Kode tenaga ahli harus diisi.',
                ],

            ],
            'nama_ta'      => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Nama tenaga ahli harus diisi.',
                ],
            ]
        ]);
        if (!$rules) {
            session()->setFlashdata('gagal-menambah-pendidikan', 'Tambah data pendidikan gagal !!!');
            return redirect()->back()->withInput();
        }
        $this->eduModel->save([
            'kode_ta' => esc($this->request->getPost('kode_ta')),
            'nama_ta' => esc($this->request->getPost('nama_ta')),
            'strata' => esc($this->request->getPost('strata')),
            'jurusan' => esc($this->request->getPost('jurusan')),
            'universitas' => esc($this->request->getPost('universitas')),
            'thn_lulus' => esc($this->request->getPost('thn_lulus'))
        ]);
        return redirect()->to(base_url('/pendidikan/tambah'))->with('sukses-tambah-pendidikan', 'Pendidikan berhasil disimpan');
    }
    public function edit($id)
    {
        if (session()->get('id')) {
            $taID = $this->taModel->getTAOrderByID(); // Untuk memilih Tenaga Ahli urut berdasarkan ID
            $taName = $this->taModel->getTAOrderByName(); // Untuk memilih Tenaga Ahli urut berdasarkan nama
            $pendidikan = $this->eduModel->getPendidikan($id);
            $data = [
                'judul' => 'Edit Data Pendidikan',
                'taID' => $taID,
                'taName' => $taName,
                'pendidikan' =>  $pendidikan,
                'validation' => \Config\Services::validation()
            ];
            return view('pendidikan/edit', $data);
        } else
            return redirect()->to('/');
    }
    public function update($id)
    {
        // dd($this->request->getVar('nomor_sert'));
        $this->eduModel->save([
            'id' => $id,
            'kode_ta' => esc($this->request->getPost('kode_ta')),
            'nama_ta' => esc($this->request->getPost('nama_ta')),
            'strata' => esc($this->request->getPost('strata')),
            'jurusan' => esc($this->request->getPost('jurusan')),
            'universitas' => esc($this->request->getPost('universitas')),
            'thn_lulus' => esc($this->request->getPost('thn_lulus'))
        ]);
        return redirect()->to(base_url('/pendidikan'))->with('sukses-update-srt', 'Pendidikan berhasil diupdate');
    }
    public function delete($id)
    {
        // dd($id);
        $this->eduModel->delete($id);
        session()->setFlashdata('del', 'Pendidikan berhasil dihapus');
        return redirect()->to('/pendidikan');
    }
    public function baca($id)
    {
        if (session()->get('id')) {
            $pendidikan = $this->eduModel->getPendidikan(($id));
            $data = [
                'judul' => 'Baca Data Pendidikan',
                'pendidikan' =>  $pendidikan
            ];
            return view('pendidikan/read', $data);
        } else
            return redirect()->to('/');
    }

    public function exportExcel()
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        //      Baris pertama berisi judul

        $sheet->setCellValue('A1', 'Kode');
        $sheet->setCellValue('B1', 'Nama Tenaga Ahli');
        $sheet->setCellValue('C1', 'Strata');
        $sheet->setCellValue('D1', 'Jurusan');
        $sheet->setCellValue('E1', 'Universitas');
        $sheet->setCellValue('F1', 'Tahun Lulus');

        $row = 2;   // row 1 dipakai untuk header (judul-judul kolom di atas)
        $edu = $this->eduModel->getPendidikan();
        foreach ($edu as $v => $item) {
            $sheet
                ->setCellValue('A' . $row, $item['kode_ta'])
                ->setCellValue('B' . $row, $item['nama_ta'])
                ->setCellValue('C' . $row, $item['strata'])
                ->setCellValue('D' . $row, $item['jurusan'])
                ->setCellValue('E' . $row, $item['universitas'])
                ->setCellValue('F' . $row, $item['thn_lulus']);
            $row++;
        }

        $filename = "pendidikan";
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename=' . $filename . '.xlsx');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
    }


    //pendidikan/importExcel
    public function importExcel()
    { //importExcel
        $spreadsheet = new Spreadsheet();
        //  Ambil file dari name (input type="file".... name="excel".....) di dalam index.php
        $file = $this->request->getFile('excel');

        $ext = $file->getExtension();


        if ($ext === "xls" || $ext === "xlsx") {

            if ($ext === "xls") $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();    //  Jika ekstensinya xls
            else $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx(); //  Jika ekstensinya xlsx
            $spread = $reader->load($file); //   Muat ke reader, tampung ke variabel $spread
            $sheet = $spread->getActiveSheet()->toArray(); //    Membaca sheet aktif dan menampung ke array
            foreach ($sheet as $index => $item) {
                if ($index == 0) continue; // Baris ke 0 berisi header(judul), bukan data, jadi diabaikan
                // Jika menemui baris terakhir berhenti
                if (
                    $item[0] == "" && $item[1] == "" && $item[2] == "" && $item[3] == "" && $item[4] == ""
                    && $item[5] == "" && $item[6] == ""
                ) {
                    break;
                }
                if ($item[0] != "" && $item[1] != "" && $item[2] != "" && $item[3] != "" && $item[4] != "" && $item[5] != "") {
                    $data =
                        [
                            'kode_ta' => $item[0],        //      kolom B
                            'nama_ta' => $item[1],        //      kolom C
                            'strata' => $item[2],         //      kolom D
                            'jurusan' => $item[3],        //      kolom E
                            'universitas' => $item[4],    //      kolom F
                            'thn_lulus' => $item[5],      //      kolom G
                        ];
                    $this->eduModel->insert($data);  // mulai baris 1 dan seterusnya 
                }
            }
            session()->setFlashdata('import', 'Data berhasil di-impor');
        } else {
            session()->setFlashdata('error', 'Bukan format file excel');
        }
        return redirect()->to('/pendidikan');
    }

    public function kosong()
    { //Mengosongkan tabel
        $this->eduModel->kosongkan();
        return redirect()->to('/pendidikan');
    }
}
