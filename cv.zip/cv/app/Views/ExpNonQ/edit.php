<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <!--    
        Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
        Perlu penyesuaian versi bootstrap dari 3.4.1 ke 5.1.3
    -->
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="sweetalert2.min.css">
</head>
<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">


                <div class="card">


                    <center>
                        <h1 style="font-weight: bold; font-family: Georgia" ;>Edit Pengalaman Non Quantum</h1>
                    </center>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <form action="" method="post" enctype="multipart/form-data" id="frmEdit">


                            <input type="hidden" name="id" id="TxtID" value="<?= $expNonQ['id'] ?>">

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nama Tenaga Ahli</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="nama_ta" id="Tenaga_Ahli" value="<?= $expNonQ['nama_ta'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Tenaga Ahli</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="kode_ta" id="TA_Code" value="<?= $expNonQ['kode_ta'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Pengalaman</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="kode_pengalaman" value="<?= $expNonQ['kode_pengalaman'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Posisi Penugasan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="PosisiPenugasan" value="<?= $nama_posisi_nya ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Posisi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="kode_posisi" id="Posisi_Code" onfocus="isikodeposisi()" 
                                    value="<?= $expNonQ['kode_posisi'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Instansi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="nama_instansi" id="Instansi" 
                                    value="<?= $expNonQ['nama_instansi'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Instansi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="kode_instansi" 
                                    onfocus="isi_kode_instansi()" id="Instansi_Code" value="<?= $expNonQ['kode_instansi'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Pekerjaan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="pekerjaan" value="<?= $expNonQ['pekerjaan'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Lokasi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="lokasi" value="<?= $expNonQ['lokasi'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Alamat</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="alamat" value="<?= $expNonQ['alamat'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nomor kontrak</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="nokontrak" value="<?= $expNonQ['nokontrak'] ?>">
                                </div>
                            </div>
                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Mulai</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" name="mulai" id="aw" value="<?= $expNonQ['mulai'] ?>">
                                </div>
                                <div class="col-sm-2">
                                    <input type="date" class="form-control" id="tgl_awal" onchange="start()">
                                </div>
                                <label class="col-sm-1 col-form-label">tahun</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" name="tahun" id="THN" value="<?= $expNonQ['tahun'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Selesai</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" name="selesai" id="ak" value="<?= $expNonQ['selesai'] ?>">
                                </div>
                                <div class="col-sm-2">
                                    <input type="date" class="form-control" id="tgl_akhir" onchange="hitung_intermitten()" />
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Intermitten</label>
                                <div class="col-sm-6 mx-0">
                                    <input type="text" class="form-control mx-0" name="inter" value="<?= $expNonQ['inter'] ?>" id="intermitten" style="width:500">
                                </div>
                                <label class="col-sm-2 col-form-label">Jumlah Bulan</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" name="jml_bln" value="<?= $expNonQ['jml_bln'] ?>" id="jmlbln" value="<?= old('jml_bln') ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nilai</label>
                                <div class="col-sm-4">
                                    <input type="text" name="nilaisementara" id="the_fake_nilai" 
                                    pattern="^\Rp\d{1.3}(.\d{3})*(\,\d+)?Rp" data-type="currency" value="<?= $expNonQ['nilai'] ?>"
                                    placeholder="Rp 1.000.000,00" onfocusout="format_nilai()" />
                                    <input type="hidden" name="nilai" id="the_real_nilai">      
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nama Perusahaan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="nama_perusahaan" value="<?= $expNonQ['nama_perusahaan'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Status Kepegawaian</label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" name="status_kepegawaian" value="<?= $expNonQ['status_kepegawaian'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Surat Referensi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="surat_referensi" id="File_Referensi" 
                                    value="<?= $expNonQ['surat_referensi'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Pilih file referensi (pdf)</label>
                                <input type="file" name="file" multiple="true" id="finput" style="width: 500px;" class="col-sm-9" accept="application/pdf">
                            </div>
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="width:700px; margin-left: 210px;" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                        <div id="file-progress-bar" class="progress-bar"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <a href="/pengalaman-non-quantum" class="btn btn-primary m-2" style="height: 35px; width: 90px">
                                    <i class="fa-solid fa-circle-left"></i></i>Kembali</a>
                                <button type="submit" id="btnUpdate" class="btn btn-success">Simpan</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="sweetalert2.all.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(document).ready(function() {
        /*          <!--    https://techarise.com/demos/ci/file-upload-with-progress-bar-jquery-ajax  
                            https://techarise.com/upload-image-and-create-multiple-thumbnails-using-php/ -->
                    <!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example -->        */
        $('#frmEdit').on('submit', function(e) {
            $('#btnUpdate').prop('Disabled');
            e.preventDefault();
            id = $('#TxtID').val();
            //  Periksa TA_Code, Posisi_Code, Instansi_Code
            if ($('#TA_Code').val() == '' || $('#Posisi_Code').val() == '' || $('#Instansi_Code').val() == '') {
                //alert("Kode harus diisi ...!");
                let timerInterval
                Swal.fire({
                    title: 'Kode Tenaga Ahli, Kode Instansi, Kode Posisi harus diisi ...!',
                    html: 'Tunggu dalam <b></b> milli detik....',
                    timer: 7000,
                    timerProgressBar: true,
                    didOpen: () => {
                        Swal.showLoading()
                        const b = Swal.getHtmlContainer().querySelector('b')
                        timerInterval = setInterval(() => {
                            b.textContent = Swal.getTimerLeft()
                        }, 100)
                    },
                    willClose: () => {
                        clearInterval(timerInterval)
                    }
                }).then((result) => {
                    /* Read more about handling dismissals below */
                    if (result.dismiss === Swal.DismissReason.timer) {
                        console.log('I was closed by the timer')
                    }
                })
                $('#uploadBtn').prop('enabled');
                document.getElementById("upload_image_form").reset();
                $('#TA_Code').focus();
            } else {
                if ($('#finput').val() != '') {
                    $.ajax({
                        xhr: function() {
                            var xhr = new window.XMLHttpRequest();
                            //  Kemajuan progres bar dihitung di sini
                            xhr.upload.addEventListener("progress", function(element) {
                                if (element.lengthComputable) {
                                    var percentComplete = ((element.loaded / element.total) * 100);
                                    $("#file-progress-bar").width(percentComplete + '%');
                                    $("#file-progress-bar").html(percentComplete + '%');
                                }
                            }, false);
                            return xhr;
                        },
                        url: "updatenonq_with_ajax",
                        method: "POST",
                        data: new FormData(this),
                        processData: false,
                        contentType: false,
                        cache: false,
                        dataType: "json",
                        beforeSend: function() {
                            $("#file-progress-bar").width('0%');
                            $('#btnUpdate').html('Uploading ...');
                        },
                        success: function(res) {
                            if (res.success == true) {
                                $('#btnUpdate').html('Sukses upload...');
                                $("button#btnUpdate").css("background-color", "green");
                                Swal.fire(
                                    'Sweet,....!', res.msg, 'success'
                                );
                            } else if (res.success == false) {
                                Swal.fire(
                                    'Bad,.....!', res.msg, 'error'
                                );
                            }
                            $('#btnUpdate').prop('Enabled');
                            document.getElementById("frmEdit").reset();
                        },
                        complete: function() {
                            $('#btnUpdate').html('Simpan');
                        },
                        error: function(xhr, ajaxOptions, thrownError) {
                            console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                        }
                    });
                } else {
                    //  Tidak ada file yang di-upload
                    $.ajax({
                        url: "updatenonq_with_ajax",
                        method: "POST",
                        data: new FormData(this),
                        processData: false,
                        contentType: false,
                        cache: false,
                        dataType: "json",
                        success: function(res) {
                            if (res.success == true) {
                                $('#btnUpdate').html('Sukses menyimpan data...');
                                $("button#btnUpdate").css("background-color", "green");
                                Swal.fire(
                                    'Sweet,....!', res.msg, 'success'
                                );

                            } else if (res.success == false) {
                                Swal.fire(
                                    'Bad,.....!', res.msg, 'error'
                                );
                            }
                            //$('.btnUpdate').html('Upload');
                            $('#btnUpdate').prop('Enabled');
                            document.getElementById("frmEdit").reset();
                        },

                        complete: function() {
                            $('#btnUpdate').html('Simpan');
                        },
                        error: function(xhr, ajaxOptions, thrownError) {
                            console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                        }
                    });
                }
            }
        });
    });
</script>

<script>
    // https://dev.to/faddalibrahim/filtering-and-validating-file-uploads-with-javascript-327p
    /* Ini harus dipasang agar ajax upload file di atas berhasil     */
    document.getElementById("file").addEventListener("change", validateFile)
    function validateFile() {
        const allowedExtensions = ['pdf'], //  png diganti pdf
            sizeLimit = 1_000_000; // 1 megabyte
        // destructuring file name and size from file object
        const {
            name: fileName,
            size: fileSize
        } = this.files[0];
        /*
         * if filename is apple.png, we split the string to get ["apple","png"]
         * then apply the pop() method to return the file extension
         *
         */
        const fileExtension = fileName.split(".").pop();
        /* 
            check if the extension of the uploaded file is included 
            in our array of allowed file extensions
        */
        if (!allowedExtensions.includes(fileExtension)) {
            alert("Tipe file bukan pdf");
            this.value = null;
        } else if (fileSize > sizeLimit) {
            alert("Ukuran file terlalu besar")
            this.value = null;
        }
    }
</script>

<script>
    /*  ########## FORMAT CURRENCY Rp1.000.000,00 ######## 
        diambil dari https://codepen.io/akalkhair/pen/dyPaozZ , memerlukan JQuery (3.5.1 di atas)
    */
    $("input[data-type='currency']").on({
        keyup: function() {
            // alert('Hai');
            formatCurrency($(this));
        },
        blur: function() {
            formatCurrency($(this), "blur");
        }
    });

    function formatNumber(n) {
        // format number 1000000 to 1.234.567
        return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ".")
    }

    function formatCurrency(input, blur) {
        //  alert('Hai');
        // appends $ to value, validates decimal side
        // and puts cursor back in right position.
        // get input value
        var input_val = input.val();
        // don't validate empty input
        if (input_val === "") {
            return;
        }
        // original length
        var original_len = input_val.length;
        // initial caret position 
        var caret_pos = input.prop("selectionStart");
        // check for decimal
        if (input_val.indexOf(",") >= 0) {
            // get position of first decimal
            // this prevents multiple decimals from
            // being entered
            var decimal_pos = input_val.indexOf(",");
            // split number by decimal point
            var left_side = input_val.substring(0, decimal_pos);
            var right_side = input_val.substring(decimal_pos);
            // add commas to left side of number
            left_side = formatNumber(left_side);
            // validate right side
            right_side = formatNumber(right_side);
            // On blur make sure 2 numbers after decimal
            if (blur === "blur") {
                right_side += "00";
            }
            // Limit decimal to only 2 digits
            right_side = right_side.substring(0, 2);
            // join number by .
            input_val = "Rp" + left_side + "," + right_side;
        } else {
            // no decimal entered
            // add commas to number
            // remove all non-digits
            input_val = formatNumber(input_val);
            input_val = "Rp" + input_val;
            // final formatting
            if (blur === "blur") {
                input_val += ",00";
            }
        }
        // send updated string to input
        input.val(input_val);
        // put caret back in the right position
        var updated_len = input_val.length;
        caret_pos = updated_len - original_len + caret_pos;
        input[0].setSelectionRange(caret_pos, caret_pos);
    }
    
    function format_nilai() {
        //Ini untuk mengambil nilai yang sesungguhnya (hidden), menghilangkan format currency
        nilai = document.getElementById('the_fake_nilai').value;
        nilai = nilai.replace(",00", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace(".", "");
        nilai = nilai.replace("Rp", "");
        document.getElementById('the_real_nilai').value = nilai;
    }

    /*  ########## FORMAT CURRENCY Rp1.000.000,00 ######## 
        diambil dari https://codepen.io/akalkhair/pen/dyPaozZ , memerlukan JQuery (3.5.1 di atas)
    */
</script>

<script>
      /*  
        https://www.w3schools.com/howto/howto_js_autocomplete.asp
        https://www.geeksforgeeks.org/how-to-pass-a-php-array-to-a-javascript-function/    
    */
    function autocomplete(inp, arr) {
        /*the autocomplete function takes two arguments,
        the text field element and an array of possible autocompleted values:*/
        var currentFocus;
        /*execute a function when someone writes in the text field:*/
        inp.addEventListener("input", function(e) {
            var a, b, i, val = this.value;
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!val) {
                return false;
            }
            currentFocus = -1;
            /*create a DIV element that will contain the items (values):*/
            a = document.createElement("DIV");
            a.setAttribute("id", this.id + "autocomplete-list");
            a.setAttribute("class", "autocomplete-items");
            /*append the DIV element as a child of the autocomplete container:*/
            this.parentNode.appendChild(a);
            /*for each item in the array...*/
            for (i = 0; i < arr.length; i++) {
                /*check if the item starts with the same letters as the text field value:*/
                if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                    /*create a DIV element for each matching element:*/
                    b = document.createElement("DIV");
                    /*make the matching letters bold:*/
                    b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                    b.innerHTML += arr[i].substr(val.length);
                    /*insert a input field that will hold the current array item's value:*/
                    b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                    /*execute a function when someone clicks on the item value (DIV element):*/
                    b.addEventListener("click", function(e) {
                        /*insert the value for the autocomplete text field:*/
                        inp.value = this.getElementsByTagName("input")[0].value;
                        /*close the list of autocompleted values,
                        (or any other open lists of autocompleted values:*/
                        closeAllLists();
                    });
                    a.appendChild(b);
                }
            }
        });
        /*execute a function presses a key on the keyboard:*/
        inp.addEventListener("keydown", function(e) {
            var x = document.getElementById(this.id + "autocomplete-list");
            if (x) x = x.getElementsByTagName("div");
            if (e.keyCode == 40) {
                /*If the arrow DOWN key is pressed,
                increase the currentFocus variable:*/
                currentFocus++;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 38) { //up
                /*If the arrow UP key is pressed,
                decrease the currentFocus variable:*/
                currentFocus--;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 13) {
                /*If the ENTER key is pressed, prevent the form from being submitted,*/
                e.preventDefault();
                if (currentFocus > -1) {
                    /*and simulate a click on the "active" item:*/
                    if (x) x[currentFocus].click();
                }
            }
        });

        function addActive(x) {
            /*a function to classify an item as "active":*/
            if (!x) return false;
            /*start by removing the "active" class on all items:*/
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = (x.length - 1);
            /*add class "autocomplete-active":*/
            x[currentFocus].classList.add("autocomplete-active");
        }

        function removeActive(x) {
            /*a function to remove the "active" class from all autocomplete items:*/
            for (var i = 0; i < x.length; i++) {
                x[i].classList.remove("autocomplete-active");
            }
        }

        function closeAllLists(elmnt) {
            /*close all autocomplete lists in the document,
            except the one passed as an argument:*/
            var x = document.getElementsByClassName("autocomplete-items");
            for (var i = 0; i < x.length; i++) {
                if (elmnt != x[i] && elmnt != inp) {
                    x[i].parentNode.removeChild(x[i]);
                }
            }
        }
        /*execute a function when someone clicks in the document:*/
        document.addEventListener("click", function(e) {
            closeAllLists(e.target);
        });
    }
    //  Dari https://www.geeksforgeeks.org/how-to-pass-a-php-array-to-a-javascript-function/
    var kode_posisi = <?php echo json_encode($kode_posisi); ?>;
    var posisitugas = <?php echo json_encode($posisitugas); ?>;
    var nama_instansi = <?php echo json_encode($nama_instansi); ?>;
    var kode_instansi = <?php echo json_encode($kode_instansi); ?>;
    
    autocomplete(document.getElementById("PosisiPenugasan"), posisitugas);
    autocomplete(document.getElementById("Instansi"), nama_instansi);
  /*  
        https://www.w3schools.com/howto/howto_js_autocomplete.asp
        https://www.geeksforgeeks.org/how-to-pass-a-php-array-to-a-javascript-function/    
    */
</script>
<script>
    function isikodeposisi() {
        const posisi = document.getElementById("PosisiPenugasan").value; //Ini id dari drop down/ fungsi onclick
        let index = posisitugas.indexOf(posisi);
        document.getElementById("Posisi_Code").value = kode_posisi[index];
    }
    
    function isi_kode_instansi() {
        //  alert('Hai');
        const pengguna = document.getElementById("Instansi").value; //Ini id dari drop down/ fungsi onclick
        let index = nama_instansi.indexOf(pengguna);
        document.getElementById("Instansi_Code").value = kode_instansi[index];
    }
    function start() {
        const tglawal = new Date(document.getElementById('tgl_awal').value);
        let tahuntglawal = tglawal.getFullYear();
        let bulantglaw = tglawal.getMonth() + 1; // Months start at 0
        let haritglaw = tglawal.getDate();
        let tgl = tahuntglawal + '-' + bulantglaw + '-' + haritglaw;
        document.getElementById('aw').value = tgl;
        document.getElementById('THN').value = tahuntglawal;
    }

    function hitung_intermitten() {
        let awal = document.getElementById('tgl_awal').value;
        if (awal != "") {
            const tglawal = new Date(document.getElementById('tgl_awal').value);
            const tglakhir = new Date(document.getElementById('tgl_akhir').value);
            let time_difference = tglakhir.getTime() - tglawal.getTime();
            let Years_difference = 0;
            let SisaBulan = 0;
            let SisaHari = 0;
            var inter = "( ";
            //calculate days difference by dividing total milliseconds in a day  
            let days_difference = time_difference / (1000 * 60 * 60 * 24);
            let Months_difference = Math.floor(days_difference / 30);
            console.log(Months_difference.toString());
            if (Months_difference > 12) {
                Years_difference = Math.floor(Months_difference / 12);
                SisaBulan = Months_difference % 12;
                SisaHari = days_difference - ((Years_difference * 360) + (SisaBulan * 30));
                inter += Years_difference + " tahun ";
                inter += SisaBulan + " bulan ";
                inter += SisaHari + " hari ";
            } else if (Months_difference > 0) {
                SisaHari = days_difference % 30;
                inter += Months_difference + " bulan ";
                inter += SisaHari + " hari ";
            } else {
                inter += days_difference + " hari ";
            }
            inter += " )";
            let tahuntglakhir = tglakhir.getFullYear();
            let bulantglakhir = tglakhir.getMonth() + 1; // Months start at 0
            let haritglakhir = tglakhir.getDate();
            let tglSelesai = tahuntglakhir + '-' + bulantglakhir + '-' + haritglakhir;
            document.getElementById('ak').value = tglSelesai;
            document.getElementById('intermitten').value = inter;
            document.getElementById('jmlbln').value = Months_difference;
        }
    }

</script>
<?= $this->endsection(); ?>