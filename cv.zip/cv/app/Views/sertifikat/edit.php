<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>

    <link rel="stylesheet" href="sweetalert2.min.css">
</head>
<style type="text/css">
    .alert-displaynone {
        display: none;
    }
</style>

<section class="showcase">
    <div class="container">
        <div class="pb-2 mt-4 mb-2 border-bottom">
            <h2>Edit Sertifikat</h2>
        </div>

        <!--        https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/        -->
        <form action="<?= route_to('/ta/edit/', $sertifikat['id_sert']) ?>" method="post" id="upload_image_form" enctype="multipart/form-data">

            <div class="mb-3 row">
                <label for="nama_ta" class="col-sm-2 col-form-label">Nama Tenaga Ahli</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" value="<?= $sertifikat['nama_ta']?>" readonly>

                </div>
            </div>

            <br>

            <div class="mb-3 row">
                <label class="col-sm-2 col-form-label">Nomor Sertifikat</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="nomor_sertifikat" value="<?= $sertifikat['nomor_sertifikat']?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label class="col-sm-2 col-form-label">Nama Sertifikat</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="nama_sertifikat" value="<?= $sertifikat['nama_sertifikat']?>">
                </div>
            </div>

            <br>


            
            <div class="mb-3 row">
                <label class="col-sm-2 col-form-label">Tanggal Terbit</label>
                <div class="col-sm-2">
                    <input type="date" class="form-control" id="tanggal_terbit" onchange="convertoMySQL()" value="<?= $sertifikat['tgl_terbit']?>">
                </div>
                <div class="col-sm-2">
                    <input type="hidden" class="form-control" name="tgl_terbit" id="terbit">
                </div>
            </div>

            <div class="mb-3 row">
                <label class="col-sm-2 col-form-label">Tanggal Kadaluarsa</label>
                <div class="col-sm-2">
                    <input type="date" class="form-control" id="tanggal_kadaluarsa" onchange="toMySQL()" value="<?= $sertifikat['tgl_kadaluarsa']?>">
                </div>
                <div class="col-sm-2">
                    <input type="hidden" class="form-control" name="tgl_kadaluarsa" id="kadaluarsa">
                </div>
            </div>

            <br>

            <!--        https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/        -->

            <div id="alertMessage" class="alert alert-info mb-3" style="display: none">
                <span id="alertMsg"></span>
            </div>
            <?php 
                $lokasi = isset($sertifikat['lokasi']) ? $sertifikat['lokasi'] : '';
                if ($lokasi != '') 
                    $img = substr($lokasi,11);
                else 
                    $img = 'https://via.placeholder.com/300';
            ?>
            <div class="d-grid text-center">
                <img class="mb-3" id="ajaxImgUpload" alt="Preview Image" src= "<?= $img ?>"/>
            </div>
            <div class="mb-3 row">
                <label for="Nama_lampiran" class="col-sm-2 col-form-label" style="width:210px">Pilih file image</label>
                <input type="file" name="file" multiple="true" id="finput" onchange="onFileUpload(this);" 
                style="width:900px" class="col-sm-4" accept="image/*">
                <!-- <button type="submit" class="btn btn-outline-secondary"  style="color:blue">Upload</button>-->
            </div>
            <!--        https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/        -->
            <hr>
            <div class="row align-items-center">
                <div class="col">
                    <div class="progress" style="width:500px; margin-left: 300px;">
                        <div id="file-progress-bar" class="progress-bar"></div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <a href="/sertifikat" class="btn btn-primary m-2" style="height: 40px; width: 110px"><i class="fa-solid fa-circle-left"></i></i> Kembali</a>
                <button id="uploadBtn" type="submit" class="btn btn-success" style="height: 40px; width: 110px">
                <i class="fa-solid fa-file-arrow-up"></i>Simpan</button>
            </div>

        </form>


    </div> <!--<div class="container">-->

</section>

<!--    https://techarise.com/demos/ci/file-upload-with-progress-bar-jquery-ajax   -->
<!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="sweetalert2.all.min.js"></script>
<script>
    function toMySQL() {
        const tglawal = new Date(document.getElementById('tanggal_kadaluarsa').value);
        let tahuntglawal = tglawal.getFullYear();
        let bulantglaw = tglawal.getMonth() + 1; // Months start at 0
        let haritglaw = tglawal.getDate();
        let tgl = tahuntglawal + '-' + bulantglaw + '-' + haritglaw;
        document.getElementById('kadaluarsa').value = tgl;
    }


    function convertoMySQL() {
        const tglawal = new Date(document.getElementById('tanggal_terbit').value);
        let tahuntglawal = tglawal.getFullYear();
        let bulantglaw = tglawal.getMonth() + 1; // Months start at 0
        let haritglaw = tglawal.getDate();
        let tgl = tahuntglawal + '-' + bulantglaw + '-' + haritglaw;
        document.getElementById('terbit').value = tgl;
    }

    function onFileUpload(input, id) {
        //  Menampilkan file setelah dipilih, menggantikan https://via.placeholder.com/300
        id = id || '#ajaxImgUpload';
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $(id).attr('src', e.target.result).width(300)
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
   
</script>

<?= $this->endsection(); ?>