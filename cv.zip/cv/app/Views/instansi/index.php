<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <!--    
        Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
        Perlu penyesuaian versi bootstrap dari 3.4.1 ke 5.1.3
    -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="sweetalert2.min.css">
</head>
<style>
      .corner1 {
        border-radius: 10px;
        color: blue;
        width: 300px;
        height: 40px;
    }
</style>
<body>
    <div class="container">
        <center>
            <h1 style="font-weight: bold; font-family: Georgia" ;>Daftar Instansi</h1>
        </center>

        <button class="btn btn-success" onclick="add_instansi()"><i class="glyphicon glyphicon-plus"></i>Tambah</button>
        <br><br>
        <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Kode</th>
                    <th style="width: 200px;">Nama instansi</th>
                    <th style="width: 200px;">Alamat</th>
                    <th style="width: 30px;">No. telp</th>
                    <th style="width: 10%;">e-Mail</th>
                    <th style="width: 200px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $n = 0;
                    foreach ($instansi as $ins) { 
                    $n++;    
                ?>
                    <tr>
                        <td><?php echo $n; ?></td>
                        <td><?php echo $ins['kode_instansi']; ?></td>
                        <td><?php echo $ins['nama_instansi']; ?></td>
                        <td><?php echo $ins['alamat']; ?></td>
                        <td><?php echo $ins['notelp']; ?></td>
                        <td style="width: 10%;"><?php echo $ins['email']; ?></td>
                        <td style="width: 200px;">
                            <button class="btn btn-info" onclick="baca(<?php echo $ins['id']; ?>)">Baca</button>
                            <button class="btn btn-warning" onclick="edit_instansi(<?php echo $ins['id']; ?>)">Edit</button>
                            <button class="btn btn-danger" onclick="delete_instansi(<?php echo $ins['id']; ?>)">Delete</button>
                        </td>
                    </tr>
                <?php 
                    } 
                ?>
            </tbody>
        </table>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="sweetalert2.all.min.js"></script>
    <!--
    Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
    Perlu penyesuaian versi bootstrap dari 3.4.1 ke 5.1.3 (di atas)
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    
    -->

    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
        var save_method; //for save method string
        var table;

        function add_instansi() {
            save_method = 'add';
            $('#form')[0].reset(); // reset form on modals
            $('#modal_form').modal('show'); // show bootstrap modal
            $('.modal-title').text('Tambah Data'); // Set Title to Bootstrap modal title
            $('.kodeinst').hide();
        }

        function baca(id) { //  Membaca data per ID
            $('#form')[0].reset(); // reset form on modals
            $('.kodeinst').show();
            <?php header('Content-type: application/json'); ?>

            $.ajax({
                url: "ajax_read_instansi/" + id,
                type: "GET",
                dataType: "JSON",

                success: function(data) {
                    console.log(data);
                    $('[name="id"]').val(data.id);
                    $('[name="kode_instansi"]').val(data.kode_instansi);
                    $('[name="nama_instansi"]').val(data.nama_instansi);
                    $('[name="alamat"]').val(data.alamat);
                    $('[name="notelp"]').val(data.notelp);
                    $('[name="email"]').val(data.email);

                    $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                    $('.modal-title').text('Baca Data'); // Set title to Bootstrap modal title
                },
                complete: function() {
                    $("button#btnSave").css("display", "none");
                    $("button#btnTutup").css("background-color", "green");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR);
                    alert('Error baca data memakai ajax');
                }
            });
        }

        function edit_instansi(id) {
            save_method = 'update';
            $('#form')[0].reset(); // reset form on modals
            <?php header('Content-type: application/json'); ?>
            $('.kodeinst').hide();
            $.ajax({
                url: "ajax_edit_instansi/" + id,
                type: "GET",
                dataType: "JSON",
                success: function(data) {
                    console.log(data);
                    $('[name="id"]').val(data.id);
                    $('[name="kode_instansi"]').val(data.kode_instansi);
                    $('[name="nama_instansi"]').val(data.nama_instansi);
                    $('[name="alamat"]').val(data.alamat);
                    $('[name="notelp"]').val(data.notelp);
                    $('[name="email"]').val(data.email);
                    $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                    $('.modal-title').text('Edit Data'); // Set title to Bootstrap modal title
                    $("#btnSave").css("display", "true");
                    $("#btnSave").css("background-color", "green");
                },
                complete: function() {
                    $("button#btnSave").show();
                    $("button#btnSave").css("background-color", "green");
                    $("button#btnTutup").css("background-color", "red");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR);
                    alert('Error edit data memakai ajax');
                }
            });
        }

        function save() {
            var url;
            if (save_method == 'add') {
                url = "add_instansi";
                judulSweet = 'Tambah';
            } else {
                url = "ajax_update_instansi";
                judulSweet = 'Update';
            }
            $.ajax({
                url: url,
                type: "POST",
                data: $('#form').serialize(),
                dataType: "JSON",
                success: function(data) {
                    //if success close modal and reload ajax table
                    $('#modal_form').modal('hide');
                    location.reload(); // for reload a page
                    //  Tampilkan komentar Sweet Alert
                    Swal.fire(
                        judulSweet,
                        data.status,
                        'success'
                    );
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert('Error tambah / update data');
                }
            });
        }

        function delete_instansi(id) {
            Swal.fire({
                title: 'Apakah anda yakin menghapus data dengan id = ' + id + ' ??',
                text: "Anda tidak bisa membatalkan !",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus !'
            }).then((result) => {
                if (result.isConfirmed) {

                    $.ajax({
                        url: "ajax_del_instansi/" + id,
                        type: "POST",
                        dataType: "JSON",
                        success: function(data) {
                            location.reload();
                            //  Tampilkan komentar Sweet Alert
                            Swal.fire(
                                'Terhapus !',
                                data.status,
                                'success'
                            )
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            console.log(jqXHR);
                            alert('Error hapus data memakai ajax');
                        }
                    });
                }
            })
        }
    </script>

    <!-- Modal -->
    <div class="modal" id="modal_form" data-bs-backdrop="false" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="false">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">x</button>
                </div>
                <center>
                    <h2 class="modal-title">Modal title</h2>
                </center>
                <div class="modal-body">
                    <form action="#" id="form" class="form-horizontal">
                        <input type="hidden" value="" name="id" />
                        <div class="form-body">
                            
                            <div class="form-group kodeinst">
                                <label class="control-label col-sm-3">Kode instansi</label>
                                <div class="col-md-9">
                                    <input name="kode_instansi" placeholder="Kode instansi" class="form-control corner1" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Nama instansi</label>
                                <div class="col-md-9">
                                    <input name="nama_instansi" placeholder="Nama instansi" class="form-control corner1" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Alamat</label>
                                <div class="col-md-9">
                                    <input name="alamat" placeholder="Alamat" class="form-control hidetext corner1" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Nomor telepon</label>
                                <div class="col-md-9">
                                    <input name="notelp" placeholder="Nomor telepon" class="form-control corner1" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">e-Mail</label>
                                <div class="col-md-9">
                                    <input name="email" placeholder="e-Mail" class="form-control corner1" type="text">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" id="btnTutup" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                    <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </div>
    </div>


</body>
<?= $this->endsection(); ?>