<!-- Mengambil layout dari dashboard-layout -->
<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
<!-- Mengambil layout dari dashboard-layout -->

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header mx-2">
                        <?php
                        helper("custom_helper"); // Single helper loading
                        ?>
                        <div class="row">
                            <div class="col-lg-3 col-xs-6">
                                <!-- small box -->
                                <div class="small-box bg-aqua">
                                    <div class="inner">
                                        <!--  Menampilkan SEMUA tenaga ahli(memakai helper) -->
                                        <h3><?= countData('tb_ta') ?></h3>
                                        <p>Tenaga Ahli</p>
                                    </div>
                                    <div class="icon">
                                        <i class="ion ion-person-stalker"></i>
                                    </div>
                                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                            <!-- ./col -->
                            <div class="col-lg-3 col-xs-6">
                                <!-- small box -->
                                <div class="small-box bg-green">
                                    <div class="inner">
                                    <!--  Menampilkan jumlah tenaga ahli psikologi (memakai helper) -->
                                    <h3><?= countData('view_psikologi') ?></h3>
                                        <p>Psikolog</p>
                                    </div>
                                    <div class="icon">
                                        <i class="ion ion-person"></i>
                                    </div>
                                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                            <!-- ./col -->
                            <div class="col-lg-3 col-xs-6">
                                <!-- small box -->
                                <div class="small-box bg-yellow">
                                    <div class="inner">
                                        <!--  Menampilkan jumlah tenaga ahli SDM (memakai helper) -->
                                        <h3><?= countData('view_sdm') ?></h3>
                                        <p>SDM</p>
                                    </div>
                                    <div class="icon">
                                        <i class="ion ion-person"></i>
                                    </div>
                                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                            <!-- ./col -->
                            <div class="col-lg-3 col-xs-6">
                                <!-- small box -->
                                <div class="small-box bg-red">
                                    <div class="inner">
                                        <!--  Menampilkan jumlah tenaga ahli selain psikologi dan SDM (memakai helper) -->
                                        <h3><?= countData('view_lain') ?></h3>
                                        <p>Lainnya</p>
                                    </div>
                                    <div class="icon">
                                        <i class="ion ion-pie-graph"></i>
                                    </div>
                                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                            <!-- ./col -->
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<!--Grafik pemasukan (omset) per bulan memakai chart.js-->
<!--Diambil dari https://stackoverflow.com/questions/71614256/how-to-select-and-pass-array-object-to-data-setting-of-chart-js-config-->
    <div>
        <div><canvas id="myChart"></canvas></div>
      <!--  <input type="hidden" id="0" value="10, 12">-->
        <?php
            helper("custom_helper"); // Single helper loading
            $oms = "";
            $Omset = HitungOmset(); 
            foreach ($Omset as $v) {
                $oms = $oms . $v['nilai'] . ",";
            }
            $total = HitungTotalOmsetBulanan();
            $label = 'Total Omset tahun '.  date("Y") . ' Rp.' . $total .' milyar';
            
        ?>
        <!--https://stackoverflow.com/questions/71614256/how-to-select-and-pass-array-object-to-data-setting-of-chart-js-config-->
        <!--The value of your hidden input is a string.
            You are creating an array with a single element containing that string.-->

            <!--  $oms sebagai ganti nilai > value="10, 12">-->
        <input type="hidden" id="0" value="<?=$oms?>">
        <input type="hidden" id="1" value="<?=$label?>">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            const ctx = document.getElementById('myChart');

            //  https://stackoverflow.com/questions/71614256/how-to-select-and-pass-array-object-to-data-setting-of-chart-js-config
            //  You need to split the string first, delimiting by the , character.
            //  Trimming whitespace is also helpful too
            obj = document.getElementById('0').value.replace(" ", "").split(',');
            obj1 = document.getElementById('1').value;
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Januari', 'Pebruari', 'Maret', 'April', 'Mei', 'Juni',
                        'Juli', 'Agustus', 'September', 'Oktober', 'Nopember', 'Desember'
                    ],
                    datasets: [{
                        label: obj1,
                        data: obj,
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>
    </div>

<!--Grafik pemasukan (omset) per tahun memakai chart.js-->
<!--Diambil dari https://stackoverflow.com/questions/71614256/how-to-select-and-pass-array-object-to-data-setting-of-chart-js-config-->
    <div>
        <div><canvas id="chart"></canvas></div>
        <?php
            helper("custom_helper"); // Single helper loading
            $n = "";
            $oms = HitungOmsetTahunan();
            foreach ($oms as $v) {
                $n = $n . $v['nilai'] . ",";
            }
        ?>
        <!--https://stackoverflow.com/questions/71614256/how-to-select-and-pass-array-object-to-data-setting-of-chart-js-config-->
        <!--The value of your hidden input is a string.
            You are creating an array with a single element containing that string.-->
            <!--  $n sebagai ganti nilai > value="10, 12">,
            id 0 dan 1 sudah dipakai di atas, jadi memakai id = 2-->
        <input type="hidden" id="2" value="<?=$n?>">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            const ct = document.getElementById('chart');
            //  https://stackoverflow.com/questions/71614256/how-to-select-and-pass-array-object-to-data-setting-of-chart-js-config
            //  You need to split the string first, delimiting by the , character.
            //  Trimming whitespace is also helpful too
            obj = document.getElementById('2').value.replace(" ", "").split(',');
            new Chart(ct, {
                type: 'bar',
                data: {
                    labels: ['2022','2023', '2024','2025','2026', '2027', '2028', '2029', '2030'],
                    datasets: [{
                        label: 'Total Omset ( milyar/tahun)',
                        data: obj,
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>
    </div>
</section>
<!-- /.content -->
<?= $this->endsection(); ?>

