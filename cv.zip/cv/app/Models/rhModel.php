<?php
namespace App\Models;

use CodeIgniter\Model;

class rhModel extends Model
{
    protected $table            = 'tb_ta';
    protected $primaryKey       = 'id';
    protected $useTimestamps    = true;
    
    protected $allowedFields    = ['id','kode_ta', 'nama','alamat','kota','tgl','no_ktp','no_npwp',
    'no_telp','no_hp','email','posisi','perusahaan','kategori','sipp','sipp_ed','str','str_ed',
    'kta','kta_ed','asosiasi','asosiasi_ed','file_pdf_referensi','lokasi_file_pdf_referensi','status_kepegawaian'];

    public function getCV($id=false) {
        if ($id==false) {
            return $this->orderBy('nama', 'ASC')->findAll();
        }
        return $this->where(['id'=>$id])->first();
    }

    public function CariKodeTA($kode=false) {
        return $this->where(['kode_ta'=>$kode])->first();
    }


    public function getCVwithKode($kode=false) {
        if ($kode==false) {
            return $this->orderBy('kode_ta', 'ASC')->findAll();
        }
        return $this->where(['kode_ta'=> $kode])->first();
    } 
    public function kosongkan() {
        return $this->db->query('TRUNCATE tb_ta');
    }
    public function hitung() {
        return $this->db->query('SELECT COUNT(*) FROM tb_ta');
    }
    public function getTAOrderByID() {
            return $this->orderBy('id', 'ASC')->findAll();
    } 
    public function getTAOrderByKode() {
        return $this->orderBy('kode_ta', 'ASC')->findAll();
    } 
    public function getTAOrderByName() {
        return $this->orderBy('nama', 'ASC')->findAll();
    } 
    public function getTAGroupByPosisi() {
        return $this->groupBy('posisi', 'ASC')->findAll();
    } 
    public function getTAGroupByS1() {
        return $this->groupBy('ijazahS1', 'ASC')->findAll();
    } 
    
    public function search($katakunci) {
        $tabel = $this->table('tb_ta');
        $tabel->like('nama', $katakunci);
        return $tabel;
    }
    public function getFilterPendidikanS3($pendidikan){
            return $this->db->table('view_pendidikan')
            ->select('kode_ta, nama, sipp, sipp_ed, strata, jurusan')
            ->where('strata', 'S3')
            ->like('jurusan', $pendidikan)
            ->get()->getResultArray();
      }
    public function getFilterPendidikanS2($pendidikan){
            return $this->db->table('view_pendidikan')
            ->select('kode_ta, nama, sipp, sipp_ed, strata, jurusan')
            ->where('strata', 'S2')
            ->like('jurusan', $pendidikan)
            ->get()->getResultArray();
    }
    public function getFilterPendidikanS1($pendidikan){
//a.sipp, a.sipp_ed, b.strata, b.jurusan
        return $this->db->table('view_pendidikan')
        ->select('kode_ta, nama, sipp, sipp_ed, strata, jurusan')
        ->where('strata', 'S1')
        ->like('jurusan', $pendidikan)
        ->get()->getResultArray();

     /*   $ResponseData="";
        //::You could past third parameter
        //$this->like('title', 'match', 'both');   // Produces: WHERE `title` LIKE '%match%' ESCAPE '!'
                $this->like('ijazahS1', $pendidikan);
            //    $this->limit(10);
                $this->orderBy("ijazahS1", "ASC");
                //:::::
                $query = $this->get();
        //$RecordCounted=count($query->getResultArray());   //::: 
            if($query->getResultArray()){
                $ResponseData=$query->getResultArray();
            }
            return $ResponseData;*/
    }

    public function getOrderBySIPP_ED() {
        
        $ResponseData="";
      
            $this->orderBy('sipp_ed', 'ASC');
            $query = $this->get();
            if($query->getResultArray()){
                $ResponseData=$query->getResultArray();
            }
            return $ResponseData;
    } 
    public function getFilterPosisi($p=false) {
       
        return $this->db->table('tb_ta')
        ->select('id, nama, sipp, sipp_ed, str_ed, usia')
        ->where('posisi =', $p)
        
        ->get()->getResultArray();
       // return $this->where(['posisi'=>$p])->findAll();
    } 
    public function getCVSIPP($id=false) {
        if ($id==false) {
            return $this->orderBy('sipp_ed', 'DESC')->findAll();
        }
        return $this->where(['id'=>$id])->first();
    } 
    public function tambahCV($data) {
        
        return $this->db->table('tb_ta')->insert($data);
    } 

    public function getPengalaman($id=false) {
       
        if ($id==false) {
            return $this->orderBy('sipp_ed', 'DESC')->findAll();
        }
        return $this->where(['id'=>$id])->first();
    } 
    
    public function getLaporan($id=false) {
        return $this->db->table('tb_exp')
        ->select('kode_ta,nama_ta,kegiatan,lokasi,pengguna,pers,referensi,statuse,tahun,uraian,posisitugas,mulai,selesai,jml_bln,inter')
        ->where(['kode_ta'=>$id])
        ->orderBy('tahun', 'DESC')  // Tidak bisa ditampilkan di dompdf jika memakai $returnType = 'object';
        ->get()->getResultArray();
    }
    public function getViewTandaTangan($kode=false) {
        return $this->db->table('view_tt')
        //kode_TA, a.nama, b.namafile, b.lampiran, b.lokasi
        ->select('kode_ta, nama, namafile, lampiran, lokasi')
        ->where('kode_ta', $kode)
        ->where('lampiran', 'tt')
        ->get()->getResultArray();
    }
    public function tampil($key = null, $start = 0, $length = 0) {
        $builder = $this->table('datatables_demo');
        if ($key) {
            $arr = explode(" ", $key);
            for ($i=0; $i < count($arr); $i++) {
                $builder = $builder->orlike('first_name', $arr[$i]);
                $builder = $builder->orlike('last_name', $arr[$i]);
                $builder = $builder->orlike('position', $arr[$i]);
            }
        }

        if ($start != 0 or $length != 0) {
            $builder = $builder->limit($length, $start);
        }
        return $builder->orderBy('first_name', 'asc')->get()->getResult();
    }

    public function update_TA($where, $data) {
        $this->db->table($this->table)->update($data, $where);
        return $this->db->affectedRows();
    }


  }
?>