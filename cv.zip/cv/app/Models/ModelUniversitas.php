<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelUniversitas extends Model
{
    protected $table            = 'tb_universitas';
    protected $primaryKey       = 'id';

    protected $allowedFields    = ['id', 'universitas'];
    public function getUniversitas($id = false)
    {
        if ($id == false) {
            return $this->orderBy('universitas', 'ASC')->findAll();
        }
        return $this->where(['id' => $id])->first();
    }
    public function update_universitas($where, $data)
    {
        $this->db->table($this->table)->update($data, $where);
        return $this->db->affectedRows();
    }
}
