<?php
namespace App\Models;

use CodeIgniter\Model;

class bhsModel extends Model
{
    protected $table            = 'tb_bahasa';   
    protected $primaryKey       = 'id_bahasa';
    protected $allowedFields    = [
        'id_bahasa','nilai_bhs_indo','nilai_bhs_inggris','nilai_bhs_setempat','kode_ta','nama_ta'
    ];
 
    public function getBahasa($kode=false) {
        
        if ($kode==false) {
            return $this->findAll();
        }
        return $this->where(['kode_ta'=>$kode])->first();
    }

    public function getBhsWithKode($kode=false) {
        return $this->where(['kode_ta'=>$kode])->findAll();
    }

    public function getBahasaByID($id=false) {
        
        if ($id==false) {
            return $this->findAll();
        }
        return $this->where(['id_bahasa'=>$id])->first();
    }


    public function getLaporanCV($kode=false) {
        $ResponseData="";   
        $query = $this->db->query("SELECT * FROM tb_bahasa WHERE kode_ta = '$kode' ORDER BY kode_ta ASC");
        if($query->getResultArray()){
                $ResponseData=$query->getResultArray();
        }
        return $ResponseData;
    }
    public function getJoin() {       
        $this->table('tb_bahasa')->join('tb_ta', 'tb_bahasa.kode_ta = tb_ta.id');
        return $this->findAll();
    }
    public function getFilterByName($nama) {
        $query = $this->db->query("SELECT * FROM tb_bahasa WHERE nama_ta = '$nama' ORDER BY nama ASC");
        return $query->getResultObject();    //  Hasil berupa array
    }

    public function update_Bahasa($where, $data) {
        $this->db->table($this->table)->update($data, $where);
        return $this->db->affectedRows();
    }
}
?>