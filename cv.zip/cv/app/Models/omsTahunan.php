<?php
namespace App\Models;

use CodeIgniter\Model;

class omsTahunan extends Model
{
    protected $table            = 'tb_omset_thn';   
    protected $primaryKey       = 'id';
   // protected $returnType       = 'object';
    protected $allowedFields    = ['nilai','tahun'];
 
    public function getNilaiOmsetTahunan($id=false) {
        return $this->orderBy('tahun', 'ASC')->findAll();
    }
}
?>