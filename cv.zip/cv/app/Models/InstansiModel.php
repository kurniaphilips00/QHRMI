<?php
namespace App\Models;
use CodeIgniter\Model;

class InstansiModel extends Model
{
    protected $table            = 'tb_instansi';   
    protected $primaryKey       = 'id';
   
    protected $allowedFields    = ['id', 'kode_instansi', 'nama_instansi', 'alamat', 'notelp', 'email'];
    public function getInstansi($id=false) {
        if ($id==false) {
            return $this->orderBy('nama_instansi', 'ASC')->findAll();
       }
       return $this->where(['id'=>$id])->first();
   }
   public function kosongkan() {
    return $this->db->query('TRUNCATE tb_instansi');
    }
    public function CariKodeInstansi($kode=false) {
        return $this->where(['kode_instansi'=>$kode])->first();
    }
    
    public function UpdateInstansi($where, $data) {
        $this->db->table($this->table)->update($data, $where);
        return $this->db->affectedRows();
    }

    public function CariKodeDariNamaInstansi($nama=false) {
        return $this->where(['nama_instansi'=>$nama])->first();
    }
}
?>