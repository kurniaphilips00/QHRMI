<?php
namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

$routes->setDefaultNamespace('App\Controllers');
// Rute controller yang pertama kali dipanggil
$routes->setDefaultController('Home');  //  Home memanggil welcome_message
// Function dari controller Home yang pertama kali dipanggil
$routes->setDefaultMethod('index');

//  Controller Home, function index sebagai controller awal
//  Kemudian menampilkan dashboard (dashb.php) yang mangambil layout dari (layout/dashboard-layout),
//  agar tampilan menjadi seragam,
//  pengaturan menu-menu ada di dashboard-layout

$routes->get('/', 'Home::index'); // 
$routes->group("home", function ($routes) {
    $routes->get('dashboard', 'Home::dashboard', ['as' => 'home.dashboard']);
    $routes->get('help', 'Home::help');
});

$routes->get('logout', 'Login::logout');
$routes->get('login', 'Login::index');
$routes->post('login', 'Login::index');

/**************************************Certificate (Sept 13, 2023) - start*********************************************/
$routes->get('/sertifikat', 'CloudCertificate::index');
$routes->group("sertifikat", function ($routes) {
    $routes->get('index', 'CloudCertificate::index', ['as' => 'sertifikat.index']);
    $routes->get('baca/(:num)', 'CloudCertificate::baca/$1', ['as' => 'sertifikat.baca']);
    $routes->get('tambah', 'CloudCertificate::tambah', ['as' => 'sertifikat.tambah']);     //  	Tambah sertifikat tenaga ahli 
    $routes->post('tambah', 'CloudCertificate::certupl', ['as' => 'sertifikat.tambah']);    //	Simpan/upload memakai progress bar (ajax)
    $routes->post('certupl', 'CloudCertificate::certupl', ['as' => 'sertifikat.certupl']);    //	Simpan/upload memakai progress bar (ajax)
    $routes->get('edit/(:num)', 'CloudCertificate::edit/$1', ['as' => 'sertifikat.edit']);
    $routes->post('edit/(:num)', 'CloudCertificate::update/$1', ['as' => 'sertifikat.edit']);
    $routes->get('hapus_sertifikat/(:num)', 'CloudCertificate::delete/$1', ['as' => 'sertifikat.hapus_sertifikat']);
});

$routes->get('/cv', 'CV::index');
$routes->group("cv", function ($routes) {
    $routes->get('home', 'CV::index', ['as' => 'cv.home']);
    // rh = mencetak riwayat memakai preview html
    $routes->get('rh/(:any)', 'CV::RiwayatHidup/$1', ['as' => 'cv.rh']);
    $routes->get('intermitten', 'CV::intermitten', ['as' => 'cv.intermitten']);
});

$routes->get('/rh', 'RH::index');
$routes->group("rh", function ($routes) {
    $routes->get('home', 'RH::index', ['as' => 'rh.home']);
    //  Mencetak preview pdf (download) dari 1 (satu) tenaga ahli
    //  Tampilkan dan langsung download halaman aktif
    $routes->get('preview/(:any)', 'RH::Preview/$1', ['as' => 'rh.preview']);
    //  Seperti preview, tapi lebih dari satu
    $routes->get('download', 'RH::MorePreview/$1', ['as' => 'rh.download']);
});

//  Mencetak intermitten untuk urutan yang berdekatan (pada halaman yang sama) 
$routes->get('/imt', 'Imt::index');
$routes->group("imt", function ($routes) {
    $routes->get('home', 'Imt::index', ['as' => 'imt.home']);
    $routes->get('cetak/(:any)', 'Imt::cetakCV/$1', ['as' => 'imt.cetak']);
    $routes->get('intermitten_detil', 'Imt::intermitten_detil', ['as' => 'imt.intermitten_detil']);
    $routes->get('tambah', 'Imt::tambah', ['as' => 'imt.tambah']);  //  dashboard (cv) > tambah data
    $routes->post('simpan', 'Imt::simpan');
});

//////////////////////// Laporan laporanIntermitten ////////////////////// 
$routes->get('laporanIntermitten/(:any)', 'PrintController::cetaklaporanIntermitten/$1');

//  Export   / import untuk tabel tb_ta (tenaga ahli)
//---------------------------- export - import file excel--------------------------------
$routes->get('exporExcel', 'ExcelController::exportExcel'); //  Export ke file Excel
$routes->post('imporExcel', 'ExcelController::importExcel'); //  Import dari file Excel
//$routes->get('uploadExcel', 'ExcelController::exportExcel');
//---------------------------- export - import file excel------------------
/////////////////////////////////// END FILTER   ///////////////////////////////////////////////////////////////////

////////////////  Pengalaman TENAGA AHLI ( Quantum )  //////////////////////////////////////////////

//Ini jika memakai Datatables Server Side
//$routes->get('tampilkan_ajax', 'ExpOnQ::tampilkan_ajax');
$routes->get('/pengalaman-di-quantum', 'ExpOnQ::index');
$routes->group("pengalaman-di-quantum", function ($routes) {
    $routes->get('home', 'ExpOnQ::index', ['as' => 'pengalaman-di-quantum.home']);
    $routes->get('baca/(:any)', 'ExpOnQ::baca/$1', ['as' => 'pengalaman-di-quantum.baca']);
    $routes->get('tambah', 'ExpOnQ::tambah', ['as' => 'pengalaman-di-quantum.tambah']);
    $routes->post('tambah', 'ExpOnQ::simpan', ['as' => 'pengalaman-di-quantum.tambah']);
    $routes->get('edit/(:num)', 'ExpOnQ::edit/$1', ['as' => 'pengalaman-di-quantum.edit']);
    $routes->post('edit/(:num)', 'ExpOnQ::update/$1', ['as' => 'pengalaman-di-quantum.edit']);
    $routes->get('hapus/(:num)', 'ExpOnQ::delete/$1', ['as' => 'pengalaman-di-quantum.hapus']);
    $routes->post('importExcel', 'ExpOnQ::importExcel', ['as' => 'pengalaman-di-quantum.importExcel']);
    $routes->get('exportToExcel', 'ExpOnQ::exportToExcel', ['as' => 'pengalaman-di-quantum.exportToExcel']);
    $routes->post('kosong', 'ExpOnQ::kosong', ['as' => 'pengalaman-di-quantum.kosong']);
});
////////////////  Pengalaman TENAGA AHLI ( Quantum )   //////////////////////////////////////////////
$routes->get('delete_all_pengalaman', 'OldPengalaman::delete_all_pengalaman');

/********************	Pengalaman TENAGA AHLI ( Non Quantum )-----------------------*/
$routes->get('/pengalaman-non-quantum', 'ExpNonQ::index');
$routes->group("pengalaman-non-quantum", function ($routes) {
    $routes->get('home', 'ExpNonQ::index', ['as' => 'pengalaman-non-quantum.home']);
    $routes->get('baca/(:any)', 'ExpNonQ::baca/$1', ['as' => 'pengalaman-non-quantum.baca']);
    $routes->get('tambah', 'ExpNonQ::tambah', ['as' => 'pengalaman-non-quantum.tambah']);
    $routes->post('tambah', 'ExpNonQ::uploadrefexpnonq', ['as' => 'pengalaman-non-quantum.tambah']);             //	Simpan/upload memakai progress bar (ajax)
    $routes->post('uploadrefexpnonq', 'ExpNonQ::uploadrefexpnonq', ['as' => 'pengalaman-non-quantum.uploadrefexpnonq']);    //	Simpan/upload memakai progress bar (ajax)
    $routes->get('hapus/(:num)', 'ExpNonQ::delete/$1', ['as' => 'pengalaman-non-quantum.hapus']);
    $routes->post('imporDariExcel', 'ExpNonQ::imporDariExcel', ['as' => 'pengalaman-non-quantum.imporDariExcel']);
    $routes->get('exporKeExcel', 'ExpNonQ::exporKeExcel', ['as' => 'pengalaman-non-quantum.exporKeExcel']);
});
/** Memakai ajax (diluar group) */
$routes->get('edit_nq/(:num)', 'ExpNonQ::edit_nq/$1');
$routes->post('edit_nq/updatenonq_with_ajax', 'ExpNonQ::updatenonq_with_ajax');
$routes->post('updatenonq_with_ajax', 'ExpNonQ::updatenonq_with_ajax');
/********************	Pengalaman TENAGA AHLI ( Non Quantum )  ---------------------*/

////////////////  OMSET  //////////////////////////////////////////////
$routes->get('/omset', 'Omset::index');
$routes->group("omset", function ($routes) {
    $routes->get('home', 'Omset::index', ['as' => 'omset.home']);
    $routes->get('baca/(:any)', 'Omset::baca/$1', ['as' => 'omset.baca']);
    $routes->get('tambah', 'Omset::tambah', ['as' => 'omset.tambah']);
    $routes->post('tambah', 'Omset::simpan', ['as' => 'omset.tambah']);
    $routes->get('edit/(:num)', 'Omset::edit/$1', ['as' => 'omset.edit']);
    $routes->post('edit/(:num)', 'Omset::update/$1', ['as' => 'omset.edit']);
    $routes->get('hapus/(:num)', 'Omset::delete/$1', ['as' => 'omset.hapus']);
    $routes->get('rekap', 'Omset::rekap', ['as' => 'omset.rekap']);
});
////////////////  OMSET   //////////////////////////////////////////////
$routes->get('fNama/(:any)', 'exp\expController::FilterByName/$1');

//  Export   / import untuk tabel tb_proyek (pengalaman)
$routes->get('exporxlsExp', 'EximController::exportExcel'); //  Export ke file Excel
//$routes->post('imporxlsExp', 'EximController::importExcel'); //  Import dari file Excel
/********************PENGALAMAN-------------------------------------------------------------------------------- */

//  Export   / import untuk tabel jurusan (pengalaman)
$routes->get('expor_jurusan', 'JurusanController::exportExcel'); //  Export ke file Excel
$routes->post('impor_jurusan', 'JurusanController::importExcel'); //  Import dari file Excel
/********************PENGALAMAN-------------------------------------------------------------------------------- */

/*-----------------------------------Ijin Usaha-------------------------------------------*/
$routes->get('/ijin', 'ijin\IjinController::index');
$routes->get('tambah-ijin', 'ijin\IjinController::tambah_ijin');
$routes->post('tambah-ijin', 'ijin\IjinController::simpan_tambah_ijin');
$routes->get('edit-ijin/(:num)', 'ijin\IjinController::edit_ijin/$1');    //  dashboard > edit/update data
$routes->post('edit-ijin/(:num)', 'ijin\IjinController::simpan_edit_ijin/$1');  //  dashboard > simpan update
$routes->get('delete-ijin/(:num)', 'ijin\IjinController::delete_ijin/$1', ['as' => 'deleteijin']);
/*-------------------------------END OF Ijin Usaha------------------------------------------*/

/*-----------------------------------Pajak-------------------------------------------*/
$routes->get('pajak', 'pajak\PajakController::index');
$routes->get('tambah-pajak', 'pajak\PajakController::tambah_pajak');
$routes->post('tambah-pajak', 'pajak\PajakController::simpan_tambah_pajak');
$routes->get('edit-pajak/(:num)', 'pajak\PajakController::edit_pajak/$1');    //  dashboard > edit/update data
$routes->post('edit-pajak/(:num)', 'pajak\PajakController::simpan_edit_pajak/$1');  //  dashboard > simpan update
$routes->get('delete-pajak/(:num)', 'pajak\PajakController::delete_pajak/$1', ['as' => 'deletepajak']);
/*-------------------------------Pajak------------------------------------------*/

/*-----------------------------------Tender-------------------------------------------*/
$routes->get('/tender', 'Tender::index');
$routes->group("tender", function ($routes) {
    $routes->get('baca/(:num)', 'Tender::baca/$1', ['as' => 'tender.baca']);
    $routes->get('tambah', 'Tender::tambah', ['as' => 'tender.tambah']);
    $routes->post('tambah', 'Tender::simpan', ['as' => 'tender.tambah']);
    $routes->get('edit/(:num)', 'Tender::edit/$1', ['as' => 'tender.edit']);    //  dashboard > edit/update data
    $routes->post('edit/(:num)', 'Tender::update/$1', ['as' => 'tender.edit']);  //  dashboard > simpan update
    $routes->get('hapus/(:num)', 'Tender::delete/$1', ['as' => 'tender.hapus']);
});
/*-------------------------------Pajak------------------------------------------*/

/*-----------------------------------Dokumen (Akta)-------------------------------------------*/
$routes->get('/akta', 'Akta::index');
$routes->group("akta", function ($routes) {
    $routes->get('tambah', 'Akta::tambah', ['as' => 'akta.tambah']);
    $routes->post('tambah', 'Akta::simpan', ['as' => 'akta.tambah']);
    $routes->get('edit/(:num)', 'Akta::edit/$1', ['as' => 'akta.edit']);    //  dashboard > edit/update data
    $routes->post('edit/(:num)', 'Akta::update/$1', ['as' => 'akta.edit']);  //  dashboard > simpan update
    $routes->get('hapus/(:num)', 'Akta::delete/$1', ['as' => 'akta.hapus']);
});
/*-------------------------------END OF Dokumen(Akta)------------------------------------------*/

/*-------------------------Users---------------------------------------*/
$routes->get('/user', 'Users::index');
$routes->post('user/user_add', 'Users::add');
$routes->get('user/ajax_read/(:num)', 'Users::ajax_read/$1');
$routes->get('user/ajax_edit/(:num)', 'Users::ajax_edit/$1');
$routes->post('user/update', 'Users::ajax_update');
$routes->post('user/user_delete/(:num)', 'Users::delete/$1');
/*-------------------------End of Users--------------------------------*/

/*-----------------------------------BAHASA-------------------------------------------*/
$routes->get('/bahasa', 'BahasaController::index');
$routes->get('ajax_baca_bahasa/(:num)', 'BahasaController::ajax_baca_bahasa/$1');
$routes->post('ajax_bahasa_add', 'BahasaController::ajax_bahasa_add');
$routes->post('ajax_delete_bahasa/(:num)', 'BahasaController::ajax_delete_bahasa/$1');
$routes->get('ajax_edit_bahasa/(:num)', 'BahasaController::ajax_edit_bahasa/$1');
$routes->post('ajax_update_bahasa', 'BahasaController::ajax_update_bahasa');
$routes->get('ajax_update_bahasa', 'BahasaController::ajax_update_bahasa');
/*-------------------------------END OF BAHASA------------------------------------------*/

/**************************************PENDIDIKAN*********************************************/
$routes->get('/pendidikan', 'PendidikanController::index');
$routes->get('ajax_baca_pendidikan/(:num)', 'PendidikanController::ajax_baca_pendidikan/$1');
$routes->post('ajax_add_pendidikan', 'PendidikanController::ajax_add_pendidikan');     //  Tambah pendidikan tenaga ahli 
$routes->post('ajax_delete_edu/(:num)', 'PendidikanController::ajax_delete_edu/$1');
$routes->get('ajax_edit_pendidikan/(:num)', 'PendidikanController::ajax_edit_pendidikan/$1');
$routes->post('ajax_update_pendidikan', 'PendidikanController::ajax_update_pendidikan');
/**************************************PENDIDIKAN*********************************************/


/**************************************POSISI*********************************************/
$routes->get('/posisi', 'PosisiController::index');
$routes->post('posisi/tambah', 'PosisiController::simpan');
$routes->get('posisi/baca/(:num)', 'PosisiController::baca/$1');
$routes->post('tambah', 'PosisiController::simpan', ['as' => 'posisi.tambah']);
$routes->get('posisi/edit/(:num)', 'PosisiController::edit/$1');
$routes->post('posisi/update', 'PosisiController::update');
$routes->post('posisi/hapus/(:num)', 'PosisiController::delete/$1');
$routes->post('importExcel_posisi', 'PosisiController::importExcel');
/*----------------------------------END OF POSISI-------------------------------------*/

$routes->get('/ta', 'TA::index');
$routes->group("ta", function ($routes) {
    $routes->get('home', 'TA::index', ['as' => 'ta.home']);
    $routes->get('baca/(:any)', 'TA::baca/$1', ['as' => 'ta.baca']);
    $routes->get('tambah', 'TA::tambah', ['as' => 'ta.tambah']);
    $routes->post('tambah', 'TA::uploadrefta', ['as' => 'ta.tambah']);                 //	Simpan/upload memakai progress bar (ajax)
    $routes->post('uploadrefta', 'TA::uploadrefta', ['as' => 'ta.uploadrefta']);    //	Simpan/upload memakai progress bar (ajax)
    $routes->get('hapus/(:num)', 'TA::delete/$1', ['as' => 'ta.hapus']);
    $routes->get('posisi/(:any)', 'TA::posisi/$1', ['as' => 'ta.posisi']);
    $routes->get('usia/(:num)', 'TA::usia/$1', ['as' => 'ta.usia']);
    $routes->get('sarjana/(:any)', 'TA::sarjana/$1', ['as' => 'ta.sarjana']);
    $routes->get('master/(:any)', 'TA::master/$1', ['as' => 'ta.master']);
    $routes->get('doktor/(:any)', 'TA::doktor/$1', ['as' => 'ta.doktor']);
    $routes->get('cetakpdf', 'TA::exportpdf', ['as' => 'ta.cetakpdf']);
    $routes->post('hapus_semua', 'TA::hapus_semua', ['as' => 'ta.hapus_semua']);
    $routes->post('importExcel', 'TA::importExcel', ['as' => 'ta.importExcel']);
    $routes->get('exporExcel', 'TA::exporExcel', ['as' => 'ta.exporExcel']);
    $routes->post('kosong', 'TA::kosong', ['as' => 'ta.kosong']);
});
$routes->get('edit_ta/(:num)', 'TA::edit_ta/$1');
$routes->post('edit_ta/updateTA', 'TA::updateTA');
$routes->post('updateTA', 'TA::updateTA');
$routes->get('ajax_hapus_ta/(:num)', 'TA::ajax_hapus_ta/$1');

/*-------------------        Instansi  --------------------------------*/
$routes->get('/instansi', 'Instansi::index');
$routes->post('add_instansi', 'Instansi::ajax_add');
$routes->post('ajax_del_instansi/(:num)', 'Instansi::ajax_del_instansi/$1');
$routes->get('ajax_read_instansi/(:num)', 'Instansi::ajax_read_instansi/$1');
$routes->get('ajax_edit_instansi/(:num)', 'Instansi::ajax_edit_instansi/$1');
$routes->post('ajax_update_instansi', 'Instansi::ajax_update_instansi');
$routes->post('importExcel', 'Instansi::importExcel', ['as' => 'instansi.importExcel']);
$routes->get('exportToExcel', 'Instansi::exportToExcel', ['as' => 'instansi.exportToExcel']);
/*---------------------    Instansi  --------------------------------------*/

/*-------    KATEGORI  -------------------------*/
$routes->get('/kategori', 'CategoryController::index');   //  Proyek tenaga ahli
$routes->post('kategori/tambah', 'CategoryController::simpan');
$routes->get('kategori/baca/(:num)', 'CategoryController::baca/$1');
$routes->get('kategori/edit/(:num)', 'CategoryController::edit/$1');
$routes->post('kategori/update', 'CategoryController::update');
$routes->post('kategori/hapus/(:num)', 'CategoryController::delete/$1');
/*--------------    KATEGORI  ----------------------------*/

/********************** Kota **************************************************/
$routes->get('/kota', 'City::index');
$routes->post('add_kota', 'City::simpan');
$routes->post('ajax_del_kota/(:num)', 'City::delete/$1');
$routes->get('ajax_read_kota/(:num)', 'City::baca/$1');
$routes->get('ajax_edit_kota/(:num)', 'City::edit/$1');
$routes->post('ajax_update_kota', 'City::update');
$routes->post('importExcel', 'City::importExcel', ['as' => 'kota.importExcel']);
$routes->get('exportToExcel', 'City::exportToExcel', ['as' => 'kota.exportToExcel']);
/********************** Kota **************************************************/


/********************** Jurusan **************************************************/
$routes->get('/jurusan', 'Jurusan::index');
$routes->post('add_jurusan', 'Jurusan::simpan');
$routes->post('ajax_del_jurusan/(:num)', 'Jurusan::delete/$1');
$routes->get('ajax_read_jurusan/(:num)', 'Jurusan::baca/$1');
$routes->get('ajax_edit_jurusan/(:num)', 'Jurusan::edit/$1');
$routes->post('ajax_update_jurusan', 'Jurusan::update');
$routes->post('importExcel', 'Jurusan::importExcel', ['as' => 'jurusan.importExcel']);
$routes->get('exportToExcel', 'Jurusan::exportToExcel', ['as' => 'jurusan.exportToExcel']);
/********************** Jurusan **************************************************/

/********************** Universitas **************************************************/
$routes->get('/universitas', 'Universitas::index');
$routes->post('add_universitas', 'Universitas::simpan');
$routes->post('ajax_del_universitas/(:num)', 'Universitas::delete/$1');
$routes->get('ajax_read_universitas/(:num)', 'Universitas::baca/$1');
$routes->get('ajax_edit_universitas/(:num)', 'Universitas::edit/$1');
$routes->post('ajax_update_universitas', 'Universitas::update');
$routes->post('importExcel', 'Universitas::importExcel', ['as' => 'universitas.importExcel']);
$routes->get('exportToExcel', 'Universitas::exportToExcel', ['as' => 'universitas.exportToExcel']);
/********************** Universitas **************************************************/


/********************	PROYEK -------------------------------------------------------------------------------- */
$routes->get('/proyek', 'Proyek::index');
$routes->get('baca_Proyek/(:num)', 'Proyek::baca/$1');
$routes->get('tambah_proyek', 'Proyek::tambah');     //  Tambah proyek tenaga ahli 
$routes->post('tambah_proyek', 'Proyek::simpanproyek');
$routes->post('simpanproyek', 'Proyek::simpanproyek');
$routes->get('edit_prj/(:num)', 'Proyek::edit_prj/$1');
$routes->post('edit_prj/updateproyek', 'Proyek::updateproyek');
$routes->post('updateproyek', 'Proyek::updateproyek');
$routes->get('hapus_proyek/(:num)', 'Proyek::delete/$1');
$routes->get('cetakpdf', 'Proyek::cetakpdf');
$routes->post('importExcel', 'Proyek::importExcel');
$routes->get('ExportToExcel', 'Proyek::ExportToExcel');
$routes->post('kosong', 'Proyek::kosong');
$routes->get('delete_all_proyek', 'Proyek::delete_all_projects');
$routes->get('saveta', 'Proyek::saveta');
/********************	PROYEK -------------------------------------------------------------------------------- */

/**************************************Upload*********************************************/
$routes->get('/upload', 'Upload::index');
$routes->group("upload", function ($routes) {
    $routes->get('tambah', 'Upload::tambah', ['as' => 'upload.tambah']);
    $routes->post('tambah', 'Upload::simpan_upload', ['as' => 'upload.tambah']);    //	Simpan/upload memakai progress bar (ajax)
    $routes->post('simpan_upload', 'Upload::simpan_upload', ['as' => 'upload.simpan_upload']);            //	Simpan/upload memakai progress bar (ajax)
    $routes->get('baca/(:num)', 'Upload::baca/$1', ['as' => 'upload.baca']);
});
/**************************************Upload*********************************************/
$routes->get('edit_lampiran/(:num)', 'Upload::edit_lampiran/$1');
$routes->post('edit_lampiran/update_lampiran', 'Upload::update_lampiran');
$routes->post('update_lampiran', 'Upload::update_lampiran');
$routes->post('hapus_lampiran/(:num)', 'Upload::hapus_lampiran/$1');


if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
