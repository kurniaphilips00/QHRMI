<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <!--
    <script src="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css"></script>
-->
    <link rel="stylesheet" href="../../js/editor.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/select/1.7.0/css/select.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/datetime/1.5.1/css/dataTables.dateTime.min.css">
</head>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                            <a href="/old-exp/tambah" class=btn btn-primary style="width:100px; color:blue; background-color: #a8ede4;">
                                <i class="fa-solid fa-circle-plus"></i> Tambah</a>
                        </div>

                    </div>
                    <br>

                    <div class="card-body">
                        <form action="">
                            <table id="example" class="display" style="width:100%">
                                <thead>
                                    <tr>
                                        <th style="text-align:center; width:5%">ID</th>
                                        <th style="text-align:center; width:15%">Tenaga Ahli</th>
                                        <!--<th style="text-align:center; width:5%">Kode pengalaman</th>
                                        <th style="text-align:center; width:25%">Kegiatan(Pekerjaan)</th>
                                        <th style="text-align:center; width:15%">Edit</th>-->
                                        <!--
                                        <th style="text-align:center; width:5%">Kode proyek</th>
                                        <th style="text-align:center; width:10%">Posisi</th>
                                        

                                        <th style="text-align:center; width:25%">Perusahaan(Instansi)</th>
                                        -->
                                    </tr>
                                </thead>

                            </table>
                        </form>
                        <!-- End of DAFTAR PENGALAMAN YANG AKAN DIHAPUS--------------------------------------------------------->
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>



<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/select/1.7.0/js/dataTables.select.min.js"></script>
<script src="../../js/dataTables.editor.min.js"></script>

<script>
    const editor = new DataTable.Editor({
        ajax: 'tampilkan_ajax',
        fields: [{
                label: 'id:',
                name: 'DT_RowId'
            },
            {
                label: 'Nama:',
                name: 'nama_ta'
            }
            
        ],
        table: '#example'
    });

    new DataTable('#example', {
        ajax: 'tampilkan_ajax',
        buttons: [{
                extend: 'create',
                editor
            },
            {
                extend: 'edit',
                editor
            },
            {
                extend: 'remove',
                editor
            }
        ],
        columns: [{
                data: null,
                render: data => data.id
            },
            {
                data: 'nama_ta'
            }
        ],
        dom: 'Bfrtip',
        select: true
    });


    /*
    $(document).ready(function() {
        new DataTable('#example', {
            ajax: {
                url: 'tampilkan_ajax',
                type: 'POST'
            },
            columns: [
                {
                    data: 'id'
                },
                {
                    data: 'nama_ta'
                },
                {
                    data: 'kode_pengalaman'
                },
                {
                    data: 'nama_pekerjaan'
                },
                {
                    data: null,
                    render: function ( data, type, row ) {
                        m = '';
                        m+= '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#bacaModal"' + data.id + '>Baca</button>'; 
                        m+= '<!-- Modal -->';
                        m+= '<div class="modal fade" id="bacaModal"' + data.id + 'tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">';
                        m+= '<div class="modal-dialog" role="document">';
                        m+= '<div class="modal-content"><div class="modal-header">';
                        m+= '<h1 class="modal-title" id="test"' + data.id + '><center>Baca Data</center></h1>';
                        m+= '<div class="modal-body">ID = ' + data.id + '</div>';
                        m+= '<div class="modal-body">Kode Pengalaman = ' + data.kode_pengalaman + '</div>';
                        m+= '<div class="modal-body">Tenaga Ahli = ' + data.nama_ta + '</div>';
                        m+= '<div class="modal-body">Nama pekerjaan = ' + data.nama_pekerjaan + '</div>';
                        m+= '<div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>';
                        m+= '<button type="button" class="btn btn-primary">Simpan</button>';
                        m+= '</div>';
                        m+= '</div></div></div>';
                        return m;
                    }
                
                }
            ],
            order: [1, 'desc'],
            processing: true,
            serverSide: true
        });

    });
    */
</script>
<script>
    function periksa() {
        var berkas = document.getElementById('files').value;
        if (berkas == '') {
            alert('File excel masih belum ada....!');
            document.getElementById("files").focus();
        }
    }

    function cetakIntermitten($id) {
        //      let nama = document.getElementById('#intermitten').innerText;
        window.location.href = "/laporanIntermitten/" + $id
    }

    function cetakCV($id) {
        window.location.href = "/laporanCV/" + $id
    }

    function filter_nama() {
        let name = document.getElementById('names');
        name.onclick = function(event) {
            var target = event.target;
            var nama = event.target.value;
            //  alert (nama);
            window.location.href = "/fNama/" + nama;
        };
    }

    function filter_pekerjaan() {
        let pengalaman = document.getElementById('experiences');
        pengalaman.onclick = function(event) {
            var target = event.target;
            var exp = event.target.value;
            //    alert (exp);
            window.location.href = "/filteredbyExperience/" + exp; //exp=id_exp
        };
    }
</script>
<?= $this->endsection(); ?>