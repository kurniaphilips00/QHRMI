<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>

    <link rel="stylesheet" href="sweetalert2.min.css">
</head>
<style type="text/css">
    .alert-displaynone {
        display: none;
    }
</style>

<section class="showcase">
    <div class="container">

        <center>
            <h1 style="font-weight: bold; font-family: Georgia";>Edit Lampiran</h1>
        </center>
        <!--        https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/        -->
        <form action="<?= route_to('/upload/edit/', $img['id']) ?>" method="post" id="upload_image_form" enctype="multipart/form-data">
            <div class="mb-3 row">
                <input type="hidden" name="id" id="TxtID">
                <label class="col-sm-2 col-form-label">Nama Tenaga Ahli</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="nama_ta" value="<?= $img['nama_ta'] ?>" readonly>
                </div>
            </div>
            <div class="mb-3 row">
                <label class="col-sm-2 col-form-label">Nama File Lampiran</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="namafile" value="<?= $img['namafile'] ?>" readonly>
                </div>
            </div>
            <div class="mb-3 row">
                <label class="col-sm-2 col-form-label" style="width:210px">Lampiran</label>
                <select class="col-sm-7" name="lampiran" style="height: 35px;">
                    <option value="<?= $img['lampiran'] ?>"><?= $img['lampiran'] ?></option>
                    <option value="PasFoto">Pas Foto</option>
                    <option value="tt">Tanda tangan</option>
                    <option value="KTP">KTP</option>
                    <option value="NPWP">NPWP</option>
                    <option value="SIPP">SIPP</option>
                    <option value="STR">STR</option>
                    <option value="KTA">KTA</option>
                    <option value="Ijazah">Ijazah</option>
                </select>
            </div>
      
            
         
            <br>
            <br>
            <br>
            <!--        https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/        -->

            <div id="alertMessage" class="alert alert-info mb-3" style="display: none">
                <span id="alertMsg"></span>
            </div>
            <?php
            $lokasi = isset($img['lokasi']) ? $img['lokasi'] : '';
            if ($lokasi != '')
                $img = substr($lokasi, 11);
            else
                $img = 'https://via.placeholder.com/300';
            ?>
            <div class="d-grid text-center">
                <img class="mb-3" id="ajaxImgUpload" alt="Preview Image" src="<?= $img ?>" />
            </div>
            <div class="mb-3 row">
                <label for="Nama_lampiran" class="col-sm-2 col-form-label" style="width:210px">Pilih file image</label>
                <input type="file" name="file" multiple="true" id="finput" onchange="onFileUpload(this);" style="width:900px" class="col-sm-4" accept="image/*">
                <!-- <button type="submit" class="btn btn-outline-secondary"  style="color:blue">Upload</button>-->
            </div>
            <!--        https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/        -->
            <hr>
            <div class="row align-items-center">
                <div class="col">
                    <div class="progress" style="width:500px; margin-left: 300px;">
                        <div id="file-progress-bar" class="progress-bar"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="/upload" class="btn btn-primary m-2" style="height: 40px; width: 110px"><i class="fa-solid fa-circle-left"></i></i> Kembali</a>
                <button id="uploadBtn" type="submit" class="btn btn-success" style="height: 40px; width: 110px">
                    <i class="fa-solid fa-file-arrow-up"></i>Simpan</button>
            </div>
        </form>


    </div> <!--<div class="container">-->

</section>

<!--    https://techarise.com/demos/ci/file-upload-with-progress-bar-jquery-ajax   -->
<!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="sweetalert2.all.min.js"></script>


<script>
    $(document).ready(function() {
        /*          <!--    https://techarise.com/demos/ci/file-upload-with-progress-bar-jquery-ajax   -->
                    <!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example -->        */
        $('#upload_image_form').on('submit', function(e) {
            $('#uploadBtn').prop('Disabled');
            e.preventDefault();
            id = $('#TxtID').val();
            if ($('#finput').val() != '') {
              //  alert($('#finput').val());
                $.ajax({
                    //  Progress bar
                    xhr: function() {
                        var xhr = new window.XMLHttpRequest();
                        //  Kemajuan progres bar dihitung di sini
                        xhr.upload.addEventListener("progress", function(element) {
                            if (element.lengthComputable) {
                                var percentComplete = ((element.loaded / element.total) * 100);
                                $("#file-progress-bar").width(percentComplete + '%');
                                $("#file-progress-bar").html(percentComplete + '%');
                            }
                        }, false);
                        return xhr;
                    },
                    url: "update_lampiran",
                    method: "POST",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    cache: false,
                    dataType: "json",
                    beforeSend: function() {
                        $("#file-progress-bar").width('0%');
                        $('#uploadBtn').html('Uploading ...');
                    },
                    success: function(res) {
                        if (res.success == true) {
                            console.log(res.data);
                            $('#uploadBtn').html('Sukses upload...');
                            $("button#uploadBtn").css("background-color", "green");
                            Swal.fire({
                                title: 'Sweet...!',
                                text: res.msg,
                                imageUrl: '/img/smilingb.jpg',
                                imageWidth: 400,
                                imageHeight: 200,
                                imageAlt: 'Custom image',
                            })
                        } 
                        else if (res.success == false) 
                        {
                            Swal.fire({
                                title: 'WWhhhOoooooopppps...!',
                                text: res.msg,
                                imageUrl: '/img/angryb.jpg',
                                imageWidth: 400,
                                imageHeight: 200,
                                imageAlt: 'Custom image',
                            })

                        }
                        //$('.uploadBtn').html('Upload');
                        $('#uploadBtn').prop('Enabled');
                        document.getElementById("upload_image_form").reset();
                    },

                    complete: function() {
                        $('#uploadBtn').html('Simpan');
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });
            } else {
                //  Tidak ada file yang di-upload
                $.ajax({
                    url: "update_lampiran",
                    method: "POST",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    cache: false,
                    dataType: "json",
                    success: function(res) {

                        if (res.success == true) {

                            $('#uploadBtn').html('Sukses menyimpan data...');
                            $("button#uploadBtn").css("background-color", "green");

                            Swal.fire({
                                title: 'Sweet...!',
                                text: res.msg,
                                imageUrl: '/img/smilingb.jpg',
                                imageWidth: 400,
                                imageHeight: 200,
                                imageAlt: 'Custom image',
                            })

                        } else if (res.success == false) {

                            Swal.fire({
                                title: 'WWhhhOoooooopppps...!',
                                text: res.msg,
                                imageUrl: '/img/angryb.jpg',
                                imageWidth: 400,
                                imageHeight: 200,
                                imageAlt: 'Custom image',
                            })
                        }
                        //$('.uploadBtn').html('Upload');
                        $('#uploadBtn').prop('Enabled');
                        document.getElementById("upload_image_form").reset();
                    },

                    complete: function() {
                        $('#uploadBtn').html('Simpan');
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });

            }

        });
    });
</script>
<script>
    function onFileUpload(input, id) {
        //  Menampilkan file setelah dipilih, menggantikan https://via.placeholder.com/300
        id = id || '#ajaxImgUpload';
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $(id).attr('src', e.target.result).width(300)
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>

<?= $this->endsection(); ?>