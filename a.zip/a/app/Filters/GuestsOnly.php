<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class GuestsOnly implements FilterInterface
{
    //  urutan entry user :
    //  Login > routes > filter > controller
    public function before(RequestInterface $request, $arguments = null)
    {
        if (session()->get('id')) {
            return redirect()->to('home/dashboard');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
    }
}