<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class UsersOnly implements FilterInterface
{
    //  urutan entry user :
    //  Login > routes > filter > controller
    public function before(RequestInterface $request, $arguments = null)
    {
        if (session()->get('id')) {
            // dd(session()->get('id'));
             return redirect()->to('home/dashboard');
         }
        if (!session()->get('id')) {
            return redirect()->to('login');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        
    }
}