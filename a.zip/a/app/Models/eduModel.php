<?php
namespace App\Models;

use CodeIgniter\Model;

class eduModel extends Model
{
    protected $table            = 'tb_pendidikan';   
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['kode_ta','nama_ta','strata','jurusan','universitas','thn_lulus'];
 
    public function getPendidikan($id=false) {
        if ($id==false) {
            return $this->findAll();
        }
        return $this->where(['id'=>$id])->first();
    }
    public function getEduWithKode($kode=false) {
        if ($kode==false) {
            return $this->findAll();
       }
        return $this->where(['kode_ta'=>$kode])->orderBy('strata', 'ASC')->findAll();
    }
    public function getReportForCV($kode=false) {
        return $this->where(['kode_ta'=>$kode])->findAll();
    }
    public function getJoin() {       
        $this->table('tb_pendidikan')->join('tb_ta', 'tb_pendidikan.kode_ta = tb_ta.kode_ta');
        return $this->findAll();
    }
    public function edu_update($where, $data) {
        $this->db->table($this->table)->update($data, $where);
        return $this->db->affectedRows();
    }
    public function kosongkan() {
        return $this->db->query('TRUNCATE tb_pendidikan');
    }
}
?>