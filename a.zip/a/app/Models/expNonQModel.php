<?php
namespace App\Models;

use CodeIgniter\Model;

class expNonQModel extends Model
{
    protected $table = 'tb_proyek_nq';   
    protected $allowedFields = 
    ['id','kode_pengalaman','kode_posisi','kode_instansi','nama_instansi','nama_perusahaan','kode_ta','nama_ta','pekerjaan',
    'lokasi','alamat','nokontrak','mulai','selesai','tahun','nilai', 
    'jml_bln','inter','status_kepegawaian','surat_referensi','lokasi_surat_referensi'];

    public function CariKodeTA($kode=false) {
        return $this->where(['kode_ta'=>$kode])->first();
    }
    public function CariSemuaKodeTA($kode=false) {
        return $this->db->table('tb_proyek_nq')
        ->select('kode_posisi,nama_instansi,nama_perusahaan,kode_ta,nama_ta,pekerjaan,
        lokasi,alamat,nokontrak,mulai,selesai,tahun,nilai, 
        jml_bln,inter,status_kepegawaian,surat_referensi')
        ->where('kode_ta', $kode)
        ->get()->getResultArray();
        //return $this->where(['kode_ta'=>$kode]);
    }
    public function CariKodePengalaman($kode=false) {
        return $this->where(['kode_pengalaman'=>$kode])->first();
    }
    public function CariIDPengalaman($id=false) {
        return $this->where(['id'=>$id])->first();
    }
    public function getPengalamanNonQ($kode=false) 
    {
        if ($kode==false) {
            return $this->orderBy('nama_ta', 'ASC')->findAll();
        }
        return $this->where(['kode_pengalaman'=>$kode])->first();
    }  
    public function kosongkan() {
        return $this->db->query('TRUNCATE tb_proyek_nq');
    }

}
?>