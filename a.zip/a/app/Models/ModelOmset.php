<?php
namespace App\Models;

use CodeIgniter\Model;

class ModelOmset extends Model

{
    protected $table            = 'tb_omset';   
    protected $primaryKey       = 'id';
    protected $allowedFields    = [
        'id', 'kode','instansi', 'jenis', 'pekerjaan','instansi', 'no_kontrak','mulai','selesai','nilai'];

    public function getOmsetOrderByKode() {
        return $this->orderBy('kode', 'ASC')->findAll();
    } 
    public function kosongkan() {
        return $this->db->query('TRUNCATE tb_omset');
    }

    public function getOmsetByID($id=false) {
        if ($id==false) {
             return $this->findAll();
        }
        return $this->where(['id'=>$id])->first();
    }
    public function getOmsetByKode($kode=false) {
        if ($kode==false) {
             return $this->findAll();
        }
        return $this->where(['kode'=>$kode])->first();
    }

}
?>