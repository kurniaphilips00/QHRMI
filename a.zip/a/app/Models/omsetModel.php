<?php
namespace App\Models;

use CodeIgniter\Model;

class omsetModel extends Model
{
    protected $table            = 'tb_omset_bln';   
    protected $primaryKey       = 'id';
   // protected $returnType       = 'object';
    protected $allowedFields    = ['nilai','tahun','bulan'];
 
    public function getNilaiOmsetBulanan($id=false) {
        return $this->orderBy('bulan', 'ASC')->findAll();
    }
   
    public function getReportForCV($kode=false) {
        return $this->where(['kode_ta'=>$kode])->findAll();
    }
    //  Untuk menyambung ke tabel tenaga ahli
    public function getJoin() {   
    //  Untuk menampilkan nama tenaga ahli yang diambil dari tabel tenaga ahli    
        $this->table('tb_pendidikan')->join('tb_ta', 'tb_pendidikan.kode_ta = tb_ta.kode_ta');
        return $this->findAll();
    }
    public function getTotalOmset() {
        $total = $this->db->table('tb_omset_bln')
        ->selectSum('nilai')->get();
        dd($total);
        return $total;
    } 
}
?>