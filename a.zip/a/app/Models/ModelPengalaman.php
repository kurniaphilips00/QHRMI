<?php
namespace App\Models;

use CodeIgniter\Model;

class ModelPengalaman extends Model

{
    protected $table            = 'tb_pengalaman';   
    protected $primaryKey       = 'id';
    protected $allowedFields    = [
        'id', 'kode_pengalaman','kode_proyek', 'nama_pekerjaan', 'nama_instansi',
        'kode_ta','nama_ta','kode_posisi', 'posisitugas'
        ];

    public function getExperts($kode=false) {
       if ($kode==false) {
            return $this->db->table('tb_pengalaman')
            ->select('id, kode_pengalaman, kode_proyek, kode_ta, nama_ta, nama_pekerjaan, nama_instansi, kode_posisi, posisitugas')
            ->orderBy('kode_ta', 'ASC')  
            ->get()->getResultArray();
       }
       return $this->where(['kode_pengalaman'=>$kode])->first();
   }
  
  public function getPengalamanOrderByKodePengalaman() {
            return $this->db->table('tb_pengalaman')
            ->select('id, kode_pengalaman, kode_proyek, kode_ta, nama_ta, nama_pekerjaan, nama_instansi, kode_posisi, posisitugas')
            ->orderBy('kode_pengalaman', 'ASC')  
            ->get()->getResultArray();
   }

  public function CariKodePengalaman($kode=false) {
        return $this->where(['kode_pengalaman'=>$kode])->first();
    }

  public function kosongkan() {
        return $this->db->query('TRUNCATE tb_pengalaman');
    }

   public function getPekerjaanDanInstansi($kode=false) {
	$proyek = $this->db->table('tb_proyek')->where('kode_proyek', $kode)->get()->getResultArray();
	return $proyek;
    }
   public function getExpertsWithID($id=false) {
    if ($id==false) {
         return $this->db->table('tb_pengalaman')
         ->select('id, kode_pengalaman, kode_proyek, kode_ta, nama_ta, nama_pekerjaan, nama_instansi, posisitugas')
         ->orderBy('nama_ta', 'ASC')  
         ->get()->getResultArray();
    }
    return $this->where(['id'=>$id])->first();
    }
   public function getFilterByName($nama) {
    return $this->db->table('tb_proyek_ta')
    ->where(['nama_TA'=>$nama])
    ->get()->getResultArray();
    }

    public function getFilterByExp($e_id) {
        return $this->db->table('tb_proyek_ta')
        ->where(['id_exp'=>$e_id])
        ->get()->getResultArray();
        }

    public function getLaporan($id=false) {
       // dd($id);
       //     return $this->db->table('vLaporan')
       return $this->db->table('tb_proyek_ta')
       ->join('tb_proyek', 'tb_proyek_ta.id_exp = tb_proyek.id_exp')
         //   ->orderBy('tahun', 'DESC')  // Tidak bisa ditampilkan di dompdf jika memakai $returnType = 'object';
        ->where(['id_TA'=>$id])
        ->get()->getResultArray();
    }

    public function getViewOfCV($id=false) {
        return $this->db->table('CV')
        ->where(['id_TA'=>$id])
        ->orderBy('tahun', 'DESC') 
        ->get()->getResultArray();
    }
    //Filter dari tabel proyek (pengalaman/pekerjaan)
    public function getTenagaAhli($id=false) {
        return $this->db->table('CV')
        ->where(['id_exp'=>$id])
        ->orderBy('tahun', 'DESC') 
        ->get()->getResultArray();
    }

    public function getPengalaman($kode) {
        return $this->db->table('view_pengalaman')
        ->where(['kode_ta'=>$kode])
        ->orderBy('tahun', 'DESC')
	->orderBy('kode_proyek', 'ASC')
	
        ->get()->getResultArray();
    }

}
?>