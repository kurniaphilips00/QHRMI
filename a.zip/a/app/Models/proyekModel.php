<?php
namespace App\Models;

use CodeIgniter\Model;

class proyekModel extends Model
{
    protected $table = 'tb_proyek';   
    protected $allowedFields = 
    ['id','kode_ta','nama_ta','kode_posisi','kode_pengalaman','kode_proyek','kode_instansi',
    'tahun','instansi','pekerjaan','lokasi','alamat','nokontrak','mulai','selesai','nilai', 
    'referensi','jml_bln','refpdf','inter','status_kepegawaian'];

    public function CariKodeProyek($kode=false) {
        return $this->where(['kode_proyek'=>$kode])->first();
    }

    public function getPengalamanNonQ($kode=false) {
        if ($kode==false) {
            return $this->db->table('view_pengalaman_nonq');
        }
        return $this->db->table('view_pengalaman_nonq')
        ->where(['kode_ta'=>$kode]) 
        ->get()->getResultArray();
    }
    public function getProyek($id=false) {
        if ($id==false) {
            return $this->findAll();
        }
        return $this->where(['id'=>$id])->first();
    } 
    public function getProyekOrderByKode() {
        return $this->orderBy('kode_proyek', 'ASC')->findAll();
    } 
    public function getProyekOrderByID() {
        return $this->db->table('tb_proyek')
        ->select('id, pekerjaan, tahun, instansi' )
        ->orderBy('id', 'ASC')  // Tidak bisa ditampilkan di dompdf jika memakai $returnType = 'object';
        ->get()->getResultArray();
    }
    public function getProyekOrderByProyek() {
        return $this->db->table('tb_proyek')
        ->select('id, pekerjaan')
        ->orderBy('pekerjaan', 'ASC')  // Tidak bisa ditampilkan di dompdf jika memakai $returnType = 'object';
        ->get()->getResultArray();
    }
    public function getProyekFilteredByName($n=false) {
        return $this->db->table('CV')
        ->where(['nama_TA'=>$n])
        //->orderBy('tahun', 'DESC') 
        ->get()->getResultArray();
    }
    function save_multiple($items = array())
    {
        $this->db->table('tb_proyek')->insertBatch($items);
        return $this->db->affectedRows();
    }

    public function kosongkan() {
        return $this->db->query('TRUNCATE tb_proyek');
    }

    public function proyek_update($where, $data) {
        $this->db->table($this->table)->update($data, $where);
        return $this->db->affectedRows();
    }
}
?>