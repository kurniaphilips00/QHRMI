<?php
namespace App\Models;

use CodeIgniter\Model;

class ModelOmsetBln extends Model

{
    protected $table            = 'tb_omset_bln';   
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['id', 'nilai','tahun', 'bulan'];

    public function kosongkan() {
        return $this->db->query('TRUNCATE tb_omset_bln');
    }

    public function getOmsetByID($id=false) {
        if ($id==false) {
             return $this->findAll();
        }
        return $this->where(['id'=>$id])->first();
    }

    public function getNilaiOnMonth($bln=false) {
        return $this->db->table('tb_omset_bln')
        ->select('id, bulan, nilai')
        ->where('bulan', $bln)
        ->get()->getResultArray();
    }
}
?>