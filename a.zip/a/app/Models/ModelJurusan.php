<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelJurusan extends Model
{
    protected $table            = 'tb_jurusan';
    protected $primaryKey       = 'id';

    protected $allowedFields    = ['id', 'jurusan'];

    public function getJurusan($id = false)
    {
        if ($id == false) {
            return $this->orderBy('jurusan', 'ASC')->findAll();
        }
        return $this->where(['id' => $id])->first();
    }
    public function update_jurusan($where, $data)
    {
        $this->db->table($this->table)->update($data, $where);
        return $this->db->affectedRows();
    }
}
