<?php

namespace App\Models;

use CodeIgniter\Model;

class CityModel extends Model
{
    protected $table            = 'tb_city';
    protected $primaryKey       = 'id';

    protected $allowedFields    = ['id', 'kota'];
    public function getCity($id = false)
    {
        if ($id == false) {
            return $this->orderBy('kota', 'ASC')->findAll();
        }
        return $this->where(['id' => $id])->first();
    }
    public function update_city($where, $data)
    {
        $this->db->table($this->table)->update($data, $where);
        return $this->db->affectedRows();
    }
}
