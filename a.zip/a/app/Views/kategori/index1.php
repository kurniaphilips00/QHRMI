<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="sweetalert2.min.css">
</head>

<style>
    .corner1 {
        border-radius: 10px;
        color: blue;
        width: 300px;
        height: 40px;
    }
</style>

<body>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <center>
                        <h1 style="font-weight: bold; font-family: Georgia" ;>Daftar Kategori</h1>
                    </center>

                    <div class="card">
                        <button class="btn btn-success" onclick="add_category()"><i class="glyphicon glyphicon-plus"></i>Tambah</button>
                        <br><br>
                        <?php if (session('del-success')) :  ?>
                            <div class="alert alert-info" role="alert">
                                <?= session('del-success');  //  Delete success 
                                ?>
                            </div>
                        <?php endif; ?>
                        <br><br>
                        <div class="card-body">
                            <table id="table_id" class="table table-bordered table-striped">
                                <thead>
                                    <tr>

                                        <th style="text-align:center; width:10%">No.</th>
                                        <th style="text-align:center; width:50%">Kategori</th>

                                        <th style="text-align:center; width:20%">Edit</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php if ($kategori) {
                                        $no = 1;
                                        foreach ($kategori    as $v) {
                                    ?>
                                            <tr>
                                                <td style="width:10%"><?= $no; ?></td>
                                                <td style="width:50%"><?= $v['kategori']; ?></td>
                                                <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->
                                                <td>
                                                    <button class="btn btn-info" onclick="baca(<?php echo $v['id']; ?>)">Baca</button>
                                                    <button class="btn btn-warning" onclick="edit_category(<?php echo $v['id']; ?>)">Edit</button>
                                                    <button class="btn btn-danger" onclick="delete_category(<?php echo $v['id']; ?>)">Delete</button>
                                                </td>
                                                <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->

                                            </tr>
                                            <?php $no++; ?>
                                        <?php
                                        }
                                    } else { ?>

                                        <tr>
                                            <td colspan="5">Tidak ada data(kosong)..........................!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!</td>
                                        </tr>
                                    <?php


                                    } ?>


                                </tbody>

                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="sweetalert2.all.min.js"></script>
    <!--
    Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
    Perlu penyesuaian versi bootstrap dari 3.4.1 ke 5.1.3 (di atas)
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    -->

    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
        var save_method; //for save method string
        var table;

        function add_category() {
            save_method = 'add';
            $('#form')[0].reset(); // reset form on modals
            $('#modal_form').modal('show'); // show bootstrap modal
            $('.modal-title').text('Tambah Data'); // Set Title to Bootstrap modal title
        }

        function baca(id) { //  Membaca data per ID
            $('#form')[0].reset(); // reset form on modals
            <?php header('Content-type: application/json'); ?>

            $.ajax({
                url: "/kategori/baca/" + id,
                type: "GET",
                dataType: "JSON",

                success: function(data) {
                    console.log(data);
                    $('[name="id"]').val(data.id);
                    $('[name="kategori"]').val(data.kategori);
                    $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                    $('.modal-title').text('Baca Data'); // Set title to Bootstrap modal title
                },
                complete: function() {
                    $("button#btnSave").css("display", "none");
                    $("button#btnTutup").css("background-color", "green");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR);
                    alert('Error baca data memakai ajax');
                }
            });
        }

        function edit_category(id) {
            save_method = 'update';
            //   alert(id);
            $('#form')[0].reset(); // reset form on modals
            <?php header('Content-type: application/json'); ?>
            //Ajax Load data from ajax
            $.ajax({
                url: "/kategori/edit/" + id,
                type: "GET",
                dataType: "JSON",
                success: function(data) {
                    console.log(data);
                    $('[name="id"]').val(data.id);
                    $('[name="kategori"]').val(data.kategori);
                    $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                    $('.modal-title').text('Edit Data'); // Set title to Bootstrap modal title
                    $("#btnSave").css("display", "true");
                    $("#btnSave").css("background-color", "green");
                },
                complete: function() {
                    $("button#btnSave").show();
                    $("button#btnSave").css("background-color", "green");
                    $("button#btnTutup").css("background-color", "red");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR);
                    alert('Error edit data memakai ajax');
                }
            });
        }

        function save() {
            var url;
            if (save_method == 'add') {
                url = "/kategori/tambah";
                judulSweet = 'Tambah';
            } else {
                url = "/kategori/update";
                judulSweet = 'Update';
            }
            $.ajax({
                url: url,
                type: "POST",
                data: $('#form').serialize(),
                dataType: "JSON",
                success: function(data) {
                    //if success close modal and reload ajax table
                    $('#modal_form').modal('hide');
                    location.reload(); // for reload a page
                    //  Tampilkan komentar Sweet Alert
                    Swal.fire(
                        judulSweet,
                        data.status,
                        'success'
                    );
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert('Error tambah / update data');
                }
            });
        }

        function delete_category(id) {

            Swal.fire({
                title: 'Apakah anda yakin menghapus data dengan id = ' + id,
                text: "Anda tidak bisa membatalkan !",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus !'
            }).then((result) => {
                if (result.isConfirmed) {

                    $.ajax({
                        url: "kategori/hapus/" + id,
                        type: "POST",
                        dataType: "JSON",
                        success: function(data) {
                            location.reload();//    ini untuk refresh
                            //  Tampilkan komentar Sweet Alert
                            Swal.fire(
                                'Terhapus !',
                                data.status,
                                'success'
                            )
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            console.log(jqXHR);
                            alert('Error hapus data memakai ajax');
                        }
                    });
                }
            })
        }
    </script>

    <!-- Modal -->
    <div class="modal" id="modal_form" data-bs-backdrop="false" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="false">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">x</button>
                </div>
                <center>
                    <h2 class="modal-title">Modal title</h2>
                </center>
                <div class="modal-body">
                    <form action="#" id="form" class="form-horizontal">
                        <input type="hidden" value="" name="id" />
                        <div class="form-body">
                            <div class="form-group">
                                <label class="control-label col-sm-3">Nama kategori</label>
                                <div class="col-md-9">
                                    <input name="kategori" placeholder="Nama kategori" class="form-control corner1" type="text">
                                </div>
                            </div>

                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" id="btnTutup" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                    <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </div>
    </div>



    <?= $this->endsection(); ?>