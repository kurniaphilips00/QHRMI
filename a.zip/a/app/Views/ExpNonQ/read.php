<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">

                    <!-- /.card-header -->
                    <div class="card-body">
                        <form method="get">
                            <!-- Ini alias dari update(simdat_TA=simpan update TA)-------------------->
                            <?= csrf_field(); ?>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Pengalaman</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['kode_pengalaman'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Tenaga Ahli</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['kode_ta'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nama Tenaga Ahli</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['nama_ta'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Pekerjaan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['pekerjaan'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Lokasi Kegiatan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['lokasi'] ?>" readonly>
                                </div>
                            </div>


                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Alamat</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['alamat'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Instansi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['nama_instansi'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Instansi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['kode_instansi'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Perusahaan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['nama_perusahaan'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode posisi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['kode_posisi'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Posisi penugasan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $posisitugas ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Tahun</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['tahun'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Mulai</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['mulai'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Selesai</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['selesai'] ?>" readonly>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Jumlah bulan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['jml_bln'] ?>" readonly>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Intermitten</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['inter'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <?php
                                    $nilai = isset($expNonQ['nilai']) ? $expNonQ['nilai'] : '';
                                    $formattedNum = number_format($nilai, 2, ',', '.');
                                   // dd($formattedNum);
                                ?>
                                <label class="col-sm-2 col-form-label">Nilai</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= 'Rp. '. $formattedNum ?>" readonly>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Status kepegawaian</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expNonQ['status_kepegawaian'] ?>" readonly>
                                </div>
                            </div>
                            <?php
                                $lokasi = isset($expNonQ['lokasi_surat_referensi']) ? $expNonQ['lokasi_surat_referensi'] : '';
                                $lokasi = substr($lokasi, 12);
                                //dd($lokasi);
                            ?>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Surat referensi</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" value="<?= $expNonQ['surat_referensi'] ?>" readonly>
                                </div>
                                <a href="<?= base_url($lokasi) ?>" target="_blank" style="font-style: italic;">Tampilkan Pdf</a>
                            </div>

                            <br>
                            <a href="/experiences" class="btn btn-primary m-2" style="height: 40px; width: 110px">
                                <i class="fa-solid fa-circle-left"></i></i>Kembali</a>
                        </form>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->
<?= $this->endsection(); ?><?= $this->extend('layout/dashboard-layout'); ?>