<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">

                    <div class="card-header">
                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                            <a href="/experiences/tambah" class="btn btn-primary" style="width:100px; background-color:#90e1f5; margin-right: 1em; color:black" tittle="Tambah tenaga ahli">
                                <i class="fa-solid fa-circle-plus"></i> Tambah</a>
                        </div>

                        <form action="experiences/imporDariExcel" method="post" enctype="multipart/form-data" style="display: inline;">
                            <div class="btn-group" role="group">
                                <label for="files" class="btn">Pilih file excel</label>
                                <input id="files" type="file" accept=".xls, .xlsx, .ods" name='excel'>
                            </div>
                            <button title="Import to Excel" onclick="return confirm('Tabel pengalaman akan dikosongkan, yakin ingin impor ?')" type="submit" class="btn btn-primary" style="width:80px;height: 30px; background-color:#90e1f5; color:black">
                                <i class="fa-sharp fa-solid fa-upload"></i>Import</button>
                            <a href="/experiences/exporKeExcel" class="btn btn-primary" 
                                    style="width:75px; height:30px; background-color:#90e1f5; margin-right: 20px; color:black" 
                                    title="Export to Excel">Export<i class="fa-solid fa-file-arrow-down"></i></a>
                        </form>
                    </div>
                    <br>
                        <?php if (session('imported')) :  ?>
                            <div class="alert alert-info" role="alert">
                                <?= session('imported');   
                                ?>
                            </div>
                        <?php endif; ?>
                        <?php if (session('format_error')) :  ?>
                            <div class="alert alert-danger" role="alert">
                                <?= session('format_error');   
                                ?>
                            </div>
                        <?php endif; ?>
                        <?php if (session('kosong')) :  ?>
                            <div class="alert alert-danger" role="alert">
                                <?= session('kosong');   
                                ?>
                            </div>
                        <?php endif; ?>
                        
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="text-align:center; width:5%">No.</th>
                                    <th style="text-align:center; width:5%">Kode Pengalaman</th>
                                    <th style="text-align:center; width:20%">Tenaga Ahli</th>
                                    <th style="text-align:center; width:20%">Nama Pekerjaan</th>
                                    <th style="text-align:center; width:10%">Jabatan</th>
                                    <th style="text-align:center; width:15%">Edit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($expNonQ) {
                                    $no = 1;
                                    foreach ($expNonQ as $v) {
                                        $id = isset($v['id']) ? $v['id'] : '';
                                        $kode_pengalaman = isset($v['kode_pengalaman']) ? $v['kode_pengalaman'] : '';
                                        
                                        $kode_posisi = isset($v['kode_posisi']) ? $v['kode_posisi'] : '';
                                        if ($kode_posisi != '') {
                                            // Untuk memilih Posisi dan uraian tugas
                                            $posisi = new app\Models\posisiModel();
                                            $posisirecord = $posisi->CariKodePosisi($kode_posisi);
                                            $posisitugas = $posisirecord['posisitugas'];
                                        }
                                          
                                        $nama_ta = isset($v['nama_ta']) ? $v['nama_ta'] : '';
                                        $pekerjaan = isset($v['pekerjaan']) ? $v['pekerjaan'] : '';
                                        $kode_ta = isset($v['kode_ta']) ? $v['kode_ta'] : '';
                                       // $posisitugas = isset($v['posisitugas']) ? $v['posisitugas'] : '';
                                ?>
                                        <tr>
				                            <td style="width:5%; text-align:center;"><?= $no; ?></td>
                                            <td style="width:5%; text-align:center;"><?= $kode_pengalaman; ?></td>
                                         
                                            <td style="width:20%"><?= $nama_ta ?></td>
                                            <td style="width:20%"><?= $pekerjaan ?></td>
                                            <td style="width:10%"><?= $posisitugas ?></td>
                                            <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->
                                            <td style="width:15%; text-align:center">
                                                <a href="/experiences/baca/<?= $kode_pengalaman; ?>"><b><i class="fa-solid fa-glasses" title="Baca"></i></b></i>|
                                                    <a href="/edit_nq/<?= $id; ?>"><i class="fa-solid fa-pencil" title="edit"></i>|
                                                        <a href="/experiences/hapus/<?= $id; ?>" onclick="return confirm('Yakin ingin menghapus pengalaman ?')">
                                                            <i class="fa-solid fa-trash-can" title="hapus"></i>
                                            </td>
                                            <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->

                                        </tr>

                                    <?php
                                        $no++;
                                    }
                                } else { ?>

                                    <tr>
                                        <td colspan="5">Tidak ada data(kosong)..........................!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!</td>
                                    </tr>
                                <?php


                                } ?>


                            </tbody>

                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<script>
    function inter() {
        window.location.href = "/laporanIntermitten/" + $kode
    }

    function cetakCV($id) {
        window.location.href = "/laporanCV/" + $id
    }

    function FilterTAOrderByName() {
        let name = document.getElementById('TAOrderByName');
        name.onclick = function(event) {
            var target = event.target;
            var nama = event.target.value;
            //  alert (nama);
            window.location.href = "/experiences/FilterTAByName/" + nama;
        };
    }

    function FilterTAOrderByID() {
        let id = document.getElementById('TAOrderByID');
        id.onclick = function(event) {
            var target = event.target;
            var noID = event.target.value;
            //  alert (noID);
            window.location.href = "/experiences/FilterTAByID/" + noID;
        };
    }

    function FilterProyekByName() {
        let name = document.getElementById('ProyekByName');
        name.onclick = function(event) {
            var target = event.target;
            var nama = event.target.value;
            window.location.href = "/experiences/FilterProyekByName/" + nama;
        };
    }

    function FilterProyekByID() {
        let id = document.getElementById('ProyekByID');
        id.onclick = function(event) {
            var target = event.target;
            var expID = event.target.value;
            //    alert (exp);
            window.location.href = "/experiences/FilterProyekByID/" + expID; //exp=id_exp
        };
    }
</script>


<?= $this->endsection(); ?>