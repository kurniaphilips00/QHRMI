<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <center>
                        <h1 style="font-weight: bold; font-family: Georgia" ;>Detil Tenaga Ahli</h1>
                    </center>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form method="get">
                            <!-- Ini alias dari update(simdat_TA=simpan update TA)-------------------->
                            <?= csrf_field(); ?>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Tenaga Ahli</label>
                                <div class="col-sm-10">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" value="<?= $result['kode_ta'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nama Personil</label>
                                <div class="col-sm-10">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" value="<?= $result['nama'] ?>" readonly>
                                </div>
                            </div>
                            <!--Posisi Penugasan dipakai untuk mengisi Posisi yang diusulkan-->
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Posisi</label>
                                <div class="col-sm-10">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" readonly value="<?= $result['posisi'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nama Perusahaan</label>
                                <div class="col-sm-10">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" readonly value="<?= $result['perusahaan'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kategori</label>
                                <div class="col-sm-10">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" readonly value="<?= $result['kategori'] ?>">
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Alamat</label>
                                <div class="col-sm-8">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" readonly value="<?= $result['alamat'] ?>">
                                </div>
                            </div>
                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Kota</label>
                                <div class="col-sm-8">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" readonly value="<?= $result['kota'] ?>">
                                </div>
                            </div>
                            <div class="mb-1 row">
                                <?php

                                $tanggal = isset($result['tgl']) ? $result['tgl'] : '';
                                if ($tanggal != '0000-00-00' && $tanggal != null  && $tanggal != '') {

                                    $tgl = substr($result['tgl'], 8, 2);
                                    $bln = substr($result['tgl'], 5, 2);
                                    $thn = substr($result['tgl'], 0, 4);


                                    //  Ini memanggil fungsi dari custom_helper
                                    helper('custom_helper'); // Loading single helper
                                    //  Memanggil fungsi NamaBulan() untuk mencetak nama-nama bulan
                                    $bulan = NamaBulan($bln);
                                    //  Sambung menyambung menjadi satu
                                    $tgl_lahir = $tgl . " " . $bulan . " " . $thn;
                                } else {
                                    $tgl_lahir = "";
                                }

                                ?>
                                <label class="col-sm-2 col-form-label">Tgl.lahir</label>
                                <input type="hidden" id="lahir" value="<?= $tanggal ?>" />
                                <div class="col-sm-2">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" value="<?= $tgl_lahir ?>" readonly />
                                </div>

                                <label class="col-sm-1 col-form-label">Usia</label>
                                <div class="col-sm-2">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" readonly class="form-control" id="usia">
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">KTP</label>
                                <div class="col-sm-8">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" value="<?= $result['no_ktp'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">NPWP</label>
                                <div class="col-sm-8">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" value="<?= $result['no_npwp'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Telp.</label>
                                <div class="col-sm-8">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" readonly value="<?= $result['no_telp'] ?>">
                                </div>
                            </div>
                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">HP</label>
                                <div class="col-sm-8">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" readonly value="<?= $result['no_hp'] ?>">
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Email</label>
                                <div class="col-sm-8">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="form-control" readonly value="<?= $result['email'] ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2">Status Kepegawaian</label>
                                <div class="col-sm-7">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="input-group-text" readonly value="<?= $result['status_kepegawaian'] ?>" />
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2">Nomor SIPP</label>
                                <div class="col-sm-2">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="input-group-text" readonly value="<?= $result['sipp'] ?>" />
                                </div>
                                <label class="col-sm-3" style="padding-left: 150px">Tgl. kadaluarsa</label>
                                <div>
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="input-group-text" readonly value="<?= $result['sipp_ed'] ?>" />
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2">Nomor STR</label>
                                <div class="col-sm-2">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="input-group-text" readonly value="<?= $result['str'] ?>" />
                                </div>
                                <label class="col-sm-3" style="padding-left: 150px">Tgl. kadaluarsa</label>
                                <div>
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="input-group-text" readonly value="<?= $result['str_ed'] ?>" />
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2">Nomor KTA</label>
                                <div class="col-sm-2">
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="input-group-text" readonly value="<?= $result['kta'] ?>" />
                                </div>
                                <label class="col-sm-3" style="padding-left: 150px">Tgl. kadaluarsa</label>
                                <div>
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="input-group-text" readonly value="<?= $result['kta_ed'] ?>" />
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2">Asosiasi</label>
                                <div class="col-sm-5">
                                    <input type="text" style="width:500px; background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" 
                                    class="input-group-text" readonly value="<?= $result['asosiasi'] ?>" />

                                </div>
                                <div>
                                    <label style="padding-left:60px" class="col-sm-2">Tgl. kadaluarsa</label>
                                    <input type="text" style="background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;" class="input-group-text" readonly value="<?= $result['asosiasi_ed'] ?>" />
                                </div>
                            </div>
                            <?php
                                $namafile = isset($result['file_pdf_referensi']) ? $result['file_pdf_referensi'] : '';
                            ?>
                            <!--Menampilkan gambarnya (preview)-->
                            <div class="mb-3 row">
                                <div class="col-sm-2">
                                    <label style="width:200px">File image/pdf</label>
                                </div>
                                <div class="col-sm-8">
                                    
                                <a href="<?= base_url('refTA/' . $namafile) ?>" 
                                style="width:500px; background-color: green; color:aliceblue; font-family: 'Georgia'; font-weight:900;"
                                 target="_blank" style="font-style: italic;" readonly><?= $namafile ?></a>

                            </div> <!--class="mb-3 row">-->


                            <br>
                            <div class="modal-footer">
                                <a href="/ta" class="btn btn-primary m-2" style="height: 40px; width: 110px">
                                <i class="fa-solid fa-circle-left"></i></i>Kembali</a>
                            </div>
                        </form>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->
<script>
    $(document).ready(function() {
        //  Menampilkan usia secara otomatis saat form ditampilkan
        const tgl = new Date(document.getElementById('lahir').value);
        const skrg = new Date();
        let tahun = tgl.getFullYear();
        let sekarang_tahun = skrg.getFullYear();
        let usia = sekarang_tahun - tahun; //  Menghitung usia
        //alert(usia);
        document.getElementById('usia').value = usia;
    });
</script>

<?= $this->endsection(); ?>