<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                            <a href="/old-exp/tambah" class=btn btn-primary style="width:100px; color:blue; background-color: #a8ede4;">
                                <i class="fa-solid fa-circle-plus"></i> Tambah</a>
                        </div>
                        <form action="old-exp/importExcel" method="post" enctype="multipart/form-data" style="display: inline;">
                            <div class="btn-group" role="group">
                                <label for="files" class="btn">Pilih file excel</label>
                                <input id="files" type="file" accept=".xls, .xlsx, .ods" name='excel'>
                            </div>
                            <button title="Import from Excel" type="submit" class="btn btn-primary" id="tombol" onclick="periksa()" style="width:80px;height: 30px; 
				                background-color:#90e1f5; color:black">
                                <i class="fa-sharp fa-solid fa-upload"></i>Import</button>
                        </form>

                        <form action="old-exp/kosong" method="post" style="display: inline;">

                            <button title="Kosongkan tabel" type="submit" onclick="return confirm('Tabel akan dikosongkan, apakah anda yakin ? ')" class="btn btn-primary" style="width:150px;height: 30px; 
				                background-color:#90e1f5; color:black">
                                <i class="fa-solid fa-scissors"></i>Kosongkan tabel</button>
                        </form>


                        <a href="old-exp/exportToExcel" class="btn btn-primary" onclick="return confirm('Tabel akan diekspor ke file Excel, yakin ingin ekspor ?')" style="width:75px; height:30px; background-color:#90e1f5; 
				        margin-right: 20px; color:black" title="Export to Excel">Export<i class="fa-solid fa-file-arrow-down"></i></a>

                    </div>
                    <br>


                    <?php if (session('sukses-tambah-TA')) :  ?>
                        <div class="alert alert-info" role="alert">
                            <?= session('sukses-tambah-TA');
                            ?>
                        </div>
                    <?php endif; ?>
                    <?php if (session('sukses-update-pengalaman')) :  ?>
                        <div class="alert alert-info" role="alert">
                            <?= session('sukses-update-pengalaman');
                            ?>
                        </div>
                    <?php endif; ?>
                    <?php if (session('delete-success')) :  ?>
                        <div class="alert alert-info" role="alert">
                            <?= session('delete-success');
                            ?>
                        </div>
                    <?php endif; ?>
                    <?php if (session('delete-all-success')) :  ?>
                        <div class="alert alert-info" role="alert">
                            <?= session('delete-all-success');
                            ?>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <!-- DAFTAR PENGALAMAN YANG AKAN DIHAPUS--------------------------------------------------------->
                        <form action="<?= route_to('delete_all_pengalaman') ?>" method="get">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th><button type="submit" name="HapusPengalaman" 
                                        value="1" style="width: 20px; height: 20px; text-align: center; font-weight: bold; padding: 0 0 0 0" 
                                        class="tombol" title="Hapus semua pengalaman yang dicentang"><i class="fa fa-trash"></i></button>
                                        </th>
                                        <th style="text-align:center; width:5%">No.</th>
                                        <th style="text-align:center; width:5%">Kode pengalaman</th>
                                        <th style="text-align:center; width:5%">Kode proyek</th>
                                        <th style="text-align:center; width:15%">Tenaga Ahli</th>
                                        <th style="text-align:center; width:10%">Posisi</th>
                                        <th style="text-align:center; width:25%">Kegiatan(Pekerjaan)</th>
                                        <th style="text-align:center; width:25%">Perusahaan(Instansi)</th>
                                        <th style="text-align:center; width:15%">Edit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($expert) {
                                        $no = 1;
                                        foreach ($expert as $v => $item) {
                                            $kode = isset($item['kode_pengalaman']) ? $item['kode_pengalaman'] : '';
                                            $id = isset($item['id']) ? $item['id'] : '';
                                    ?>
                                            <tr>
                                                <td>
                                                    <input type="checkbox" name="ckdel[]" value="<?= $id ?>">
                                                </td>
                                                <td style="width:5%"><?= $no ?></td>
                                                <td style="width:5%"><?= $item['kode_pengalaman']; ?></td>
                                                <td style="width:5%"><?= $item['kode_proyek']; ?></td>
                                                <td style="width:15%; text-align:center;"><?= $item['nama_ta']; ?></td>
                                                
                                                <td style="width:10%"><?= $item['posisitugas'] ?></td>
                                                <td style="width:25%"><?= $item['nama_pekerjaan'] ?></td>
                                                <td style="width:20%"><?= $item['nama_instansi'] ?></td>

                                                <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->
                                                <td style="width:15%; text-align:center">
                                                    <a href="/old-exp/baca/<?= $item['kode_pengalaman'] ?>"><i class="fa-solid fa-glasses" title="baca"></i>|
                                                        <a href="/old-exp/edit/<?= $item['id'] ?>"><i class="fa-solid fa-pencil" title="edit"></i>|
                                                            <a href="/old-exp/hapus/<?= $item['id'] ?>" onclick="return confirm('Yakin ingin menghapus tenaga ahli')">
                                                                <i class="fa-solid fa-trash-can" title="hapus"></i>
                                                </td>
                                                <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->

                                            </tr>

                                        <?php
                                            $no++;
                                        }
                                    } else { ?>
                                        <tr>
                                            <td colspan="5">Tidak ada data(kosong)..........................!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!</td>
                                        </tr>
                                    <?php
                                    } ?>
                                </tbody>
                            </table>
                        </form>
                        <!-- End of DAFTAR PENGALAMAN YANG AKAN DIHAPUS--------------------------------------------------------->
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->


<script>
    function periksa() {
        var berkas = document.getElementById('files').value;
        if (berkas == '') {
            alert('File excel masih belum ada....!');
            document.getElementById("files").focus();
        }
    }

    function cetakIntermitten($id) {
        //      let nama = document.getElementById('#intermitten').innerText;
        window.location.href = "/laporanIntermitten/" + $id
    }

    function cetakCV($id) {
        window.location.href = "/laporanCV/" + $id
    }

    function filter_nama() {
        let name = document.getElementById('names');
        name.onclick = function(event) {
            var target = event.target;
            var nama = event.target.value;
            //  alert (nama);
            window.location.href = "/fNama/" + nama;
        };
    }

    function filter_pekerjaan() {
        let pengalaman = document.getElementById('experiences');
        pengalaman.onclick = function(event) {
            var target = event.target;
            var exp = event.target.value;
            //    alert (exp);
            window.location.href = "/filteredbyExperience/" + exp; //exp=id_exp
        };
    }
</script>
<?= $this->endsection(); ?>