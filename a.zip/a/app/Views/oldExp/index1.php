<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <!--    Ini harus di download (berbayar) di https://editor.datatables.   -->
    <link rel="stylesheet" href="../../js/editor.dataTables.min.css">
    <!--    Ini harus di download (berbayar) di https://editor.datatables.net    -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/select/1.7.0/css/select.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/datetime/1.5.1/css/dataTables.dateTime.min.css">
</head>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                            <a href="/old-exp/tambah" class=btn btn-primary style="width:100px; color:blue; background-color: #a8ede4;">
                                <i class="fa-solid fa-circle-plus"></i> Tambah</a>
                        </div>

                    </div>
                    <br>

                    <div class="card-body">
                        <form action="">
                            <table id="example" class="display" style="width:100%">
                                <thead>
                                    <tr>
                                        <th style="text-align:center; width:5%">ID</th>
                                        <th style="text-align:center; width:15%">Tenaga Ahli</th>
                                        <th style="text-align:center; width:5%">Kode Pengalaman</th>
                                        <th style="text-align:center; width:25%">Kegiatan(Pekerjaan)</th>
                                        <th style="text-align:center; width:15%">Posisi</th>
                                     
                                    </tr>
                                </thead>

                            </table>
                        </form>
                        <!-- End of DAFTAR PENGALAMAN YANG AKAN DIHAPUS--------------------------------------------------------->
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/select/1.7.0/js/dataTables.select.min.js"></script>
<!--    Ini harus di download (berbayar) di https://editor.datatables.net    -->
<script src="../../js/dataTables.editor.min.js"></script>
<!--    Ini harus di download (berbayar) di https://editor.datatables.    -->

<script>
    const editor = new DataTable.Editor({
        ajax: 'tampilkan_ajax',
        fields: [{
                label: 'id:',
                name: 'id'
            },
            {
                label: 'Nama:',
                name: 'nama_ta'
            },
            {
                label: 'kode_pengalaman:',
                name: 'kode_pengalaman'
            },
            {
                label: 'nama_pekerjaan',
                name: 'nama_pekerjaan'
            },
            {
                label: 'posisitugas',
                name: 'posisitugas'
            }
        ],
        table: '#example',
        idSrc:  'id',
    });

    new DataTable('#example', {
        ajax: 'tampilkan_ajax',
        buttons: [{
                extend: 'create',
                editor
            },
            {
                extend: 'edit',
                editor
            },
            {
                extend: 'remove',
                editor
            }
        ],
        columns: [
            {
                data: 'id',
              
            },
            {
                data: 'nama_ta',
            },
            {
                data: 'kode_pengalaman',
            },
            {
                data: 'nama_pekerjaan',
            },
            {
                data: 'posisitugas'
            }
        ],
        dom: 'Bfrtip',
        select: true
    });
</script>
<script>
    function periksa() {
        var berkas = document.getElementById('files').value;
        if (berkas == '') {
            alert('File excel masih belum ada....!');
            document.getElementById("files").focus();
        }
    }

    function cetakIntermitten($id) {
        //      let nama = document.getElementById('#intermitten').innerText;
        window.location.href = "/laporanIntermitten/" + $id
    }

    function cetakCV($id) {
        window.location.href = "/laporanCV/" + $id
    }

    function filter_nama() {
        let name = document.getElementById('names');
        name.onclick = function(event) {
            var target = event.target;
            var nama = event.target.value;
            //  alert (nama);
            window.location.href = "/fNama/" + nama;
        };
    }

    function filter_pekerjaan() {
        let pengalaman = document.getElementById('experiences');
        pengalaman.onclick = function(event) {
            var target = event.target;
            var exp = event.target.value;
            //    alert (exp);
            window.location.href = "/filteredbyExperience/" + exp; //exp=id_exp
        };
    }
</script>
<?= $this->endsection(); ?>