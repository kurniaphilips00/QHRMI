<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">

                <div class="card">

                    <!-- /.card-header -->
                    <div class="card-body">
                        <form action="<?= route_to('old-exp/edit/', $expert['id']) ?>" method="post">

                            <div class="mb-3 row">
                                <label for="aktifitas" class="col-sm-2 col-form-label">Kode pengalaman</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $expert['kode_pengalaman'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="aktifitas" class="col-sm-2 col-form-label">Proyek(pekerjaan)</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="nama_pekerjaan" id="Pekerjaan"
                                    value="<?= $expert['nama_pekerjaan'] ?>">
                                </div>
                                <!--
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" id="Pekerjaan">
                                </div>-->
                            </div>
                            

                            <div class="mb-3 row">
                                <label for="pekerjaan" class="col-sm-2 col-form-label">Kode Proyek</label> 
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="kode_proyek" id="Kode_Proyek" 
                                    onfocus="isikodeProyek()" value="<?= $expert['kode_proyek'] ?>" readonly >
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Instansi</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="nama_instansi" id="Nama_Instansi" 
                                    onfocus="isinamaInstansi()" value="<?= $expert['nama_instansi'] ?>" readonly >
                                </div>
                            </div>
                            
                            <!------Mengisi nama tenaga ahli dari drop down pengetikan -->
                            <div class="mb-3 row">
                                <label for="Nama_Personil" class="col-sm-2 col-form-label">Nama Tenaga Ahli</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="nama_ta" id="Tenaga_Ahli" 
                                    value="<?= $expert['nama_ta'] ?>">
                                </div>
                                <!--
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" id="Tenaga_Ahli">
                                </div>-->
                            </div>
                            
                            <!------Menampilkan kode tenaga ahli otomatis setelah diklik   -->
                            <div class="mb-1 row">
                                <label for="ta_ID" class="col-sm-2 col-form-label">Kode Tenaga Ahli</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="kode_ta" id="Kode_Tenaga_Ahli" 
                                    value="<?= $expert['kode_ta'] ?>" onfocus="isikodeTA()" readonly >
                                </div>     
                            </div>
                          
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Posisi tugas</label>
                                <div class="col-sm-5">
                                    <select class="form-control" name="posisitugas" onchange="isikodePosisi()" id="Posisi">
                                        <option value="<?= $expert['posisitugas'] ?>"><?= $expert['posisitugas'] ?></option>
                                        <?php foreach ($posisi as $val) : ?>
                                            <option value="<?= $val['posisitugas'] ?>"> <?= $val['posisitugas'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-sm-2">
                                    <input type="hidden" class="form-control" name="kode_posisi" id="KodePosisi">
                                </div> 
                            </div>
                            <br>
                            <a href="/old-exp/" class="btn btn-primary m-2" style="height: 40px; width: 110px"><i class="fa-solid fa-circle-left"></i></i> Kembali</a>
                            <button type="submit" class="btn btn-success" style="height: 40px; width: 110px">Simpan</button>
                        </form>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<script>
    function isikodePosisi() {
        const pos = document.getElementById("Posisi").value;//Ini id dari drop down/ fungsi onclick
        let index = posisi.indexOf(pos);
        document.getElementById("KodePosisi").value = kode_posisi[index];
    }
    function IsiNama() {
        const sel = document.getElementById("ta_ID");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("Nama_Personil").value = teks;
    }

    function IsiID() {
        let ta = document.getElementById('ta_ID').value;
        const sel = document.getElementById("ta_ID");
        sel.options[sel.selectedIndex].text = ta;
    }

    function ShowExperts($id) {
        //      let nama = document.getElementById('#intermitten').innerText;
        window.location.href = "/ExpertsList/" + $id
    }

    function IsiIDPekerjaan() {
        let idKegiatan = document.getElementById('pekerjaan').value;
        const sel = document.getElementById("pekerjaan");
        sel.options[sel.selectedIndex].text = idKegiatan;
    }

    function IsiPekerjaan() {
        const sel = document.getElementById("pekerjaan");
        const teks = sel.options[sel.selectedIndex].text;
        const hasil = teks.substring(4,);
        document.getElementById("aktifitas").value = hasil;
    }
</script>

<script>
    $( document ).ready(function() {
        document.getElementById("Pekerjaan").focus();
    });
</script>
<script>
      // autocomplete dari  https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_autocomplete
      function autocomplete(inp, arr) {
        /*the autocomplete function takes two arguments,
        the text field element and an array of possible autocompleted values:*/
        var currentFocus;
        /*execute a function when someone writes in the text field:*/
        inp.addEventListener("input", function(e) {
            var a, b, i, val = this.value;
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!val) {
                return false;
            }
            currentFocus = -1;
            /*create a DIV element that will contain the items (values):*/
            a = document.createElement("DIV");
            a.setAttribute("id", this.id + "autocomplete-list");
            a.setAttribute("class", "autocomplete-items");
            /*append the DIV element as a child of the autocomplete container:*/
            this.parentNode.appendChild(a);
            /*for each item in the array...*/
            for (i = 0; i < arr.length; i++) {
                /*check if the item starts with the same letters as the text field value:*/
                if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                    /*create a DIV element for each matching element:*/
                    b = document.createElement("DIV");
                    /*make the matching letters bold:*/
                    b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                    b.innerHTML += arr[i].substr(val.length);
                    /*insert a input field that will hold the current array item's value:*/
                    b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                    /*execute a function when someone clicks on the item value (DIV element):*/
                    b.addEventListener("click", function(e) {
                        /*insert the value for the autocomplete text field:*/
                        inp.value = this.getElementsByTagName("input")[0].value;
                        /*close the list of autocompleted values,
                        (or any other open lists of autocompleted values:*/
                        closeAllLists();
                    });
                    a.appendChild(b);
                }
            }
        });
        /*execute a function presses a key on the keyboard:*/
        inp.addEventListener("keydown", function(e) {
            var x = document.getElementById(this.id + "autocomplete-list");
            if (x) x = x.getElementsByTagName("div");
            if (e.keyCode == 40) {
                /*If the arrow DOWN key is pressed,
                increase the currentFocus variable:*/
                currentFocus++;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 38) { //up
                /*If the arrow UP key is pressed,
                decrease the currentFocus variable:*/
                currentFocus--;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 13) {
                /*If the ENTER key is pressed, prevent the form from being submitted,*/
                e.preventDefault();
                if (currentFocus > -1) {
                    /*and simulate a click on the "active" item:*/
                    if (x) x[currentFocus].click();
                }
            }
        });

        function addActive(x) {
            /*a function to classify an item as "active":*/
            if (!x) return false;
            /*start by removing the "active" class on all items:*/
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = (x.length - 1);
            /*add class "autocomplete-active":*/
            x[currentFocus].classList.add("autocomplete-active");
        }

        function removeActive(x) {
            /*a function to remove the "active" class from all autocomplete items:*/
            for (var i = 0; i < x.length; i++) {
                x[i].classList.remove("autocomplete-active");
            }
        }

        function closeAllLists(elmnt) {
            /*close all autocomplete lists in the document,
            except the one passed as an argument:*/
            var x = document.getElementsByClassName("autocomplete-items");
            for (var i = 0; i < x.length; i++) {
                if (elmnt != x[i] && elmnt != inp) {
                    x[i].parentNode.removeChild(x[i]);
                }
            }
        }
        /*execute a function when someone clicks in the document:*/
        document.addEventListener("click", function(e) {
            closeAllLists(e.target);
        });
    }
    var nama = <?php echo json_encode($nama_ta); ?>;
    var kode =  <?php echo json_encode($kode_ta); ?>;
    
    var kode_proyek = <?php echo json_encode($kode_proyek) ?>;
    var nama_pekerjaan = <?php echo json_encode($nama_pekerjaan) ?>;
    var nama_instansi = <?php echo json_encode($nama_instansi) ?>;
    autocomplete(document.getElementById("Tenaga_Ahli"), nama);
    autocomplete(document.getElementById("Pekerjaan"), nama_pekerjaan);
    
    function isinamaTA() {
        const ta = document.getElementById("Tenaga_Ahli").value;//Ini id dari drop down/ fungsi onclick
        let index = nama.indexOf(ta);
        document.getElementById("Nama_Tenaga_Ahli").value = nama[index];
    }
    function isikodeTA() {
        const ta = document.getElementById("Tenaga_Ahli").value;//Ini id dari drop down/ fungsi onclick
        let index = nama.indexOf(ta);
        document.getElementById("Kode_Tenaga_Ahli").value = kode[index];
    }
    function isiProyek() {
        var pekerjaan = document.getElementById("Pekerjaan").value;//Ini id dari drop down/ fungsi onclick
        var kerja = pekerjaan.toString();
        document.getElementById("NamaProyek").value = kerja;
    }

    function isikodeProyek() {
        const pekerjaan = document.getElementById("Pekerjaan").value;//Ini id dari drop down/ fungsi onclick
        let index = nama_pekerjaan.indexOf(pekerjaan);
        document.getElementById("Kode_Proyek").value = kode_proyek[index];
    }
    
    function isinamaInstansi() {
        const pekerjaan = document.getElementById("Pekerjaan").value;//Ini id dari drop down/ fungsi onclick
        let index = nama_pekerjaan.indexOf(pekerjaan);
        //alert(index);
        document.getElementById("Nama_Instansi").value = nama_instansi[index];
    }
    
</script>
<?= $this->endsection(); ?>