<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Total Intermitten (Detil) Tenaga Ahli</title>
    <style>
        .tombol {
            background-color: DodgerBlue;
            border: none;
            color: white;
            padding: 12px 16px;
            font-size: 16px;
            cursor: pointer;
        }

        /* Darker background on mouse-over */
        .tombol:hover {
            background-color: RoyalBlue;
        }

        .gbr {

            position: fixed;
            left: 50px;
            top: 500px;
            right: 0px;
            margin-left: -70px;
            margin-top: 0px;
            color: lightgrey;
            opacity: 0.2;
            font-size: 300px;
            transform: rotate(60deg);
            -webkit-transform: rotate(-40deg);
        }

        /*https://stackoverflow.com/questions/1542320/margin-while-printing-html-page*/
        @page Section1 {
            size: 8.27in 11.69in;
            margin: .5in .0in .5in .5in;
            mso-header-margin: .0in;
            mso-footer-margin: .5in;
            mso-paper-source: 0;
        }

        div.Section1 {
            @page: Section1;
        }

        table,
        th {
            border: 1px solid;
        }
    </style>

    <!------------------------Fontawesome------------------------------------------------------------------>
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <!------------------------Fontawesome------------------------------------------------------------------>

</head>

<body>
    <div class="Section1">

        <button type="button" onClick="cetak()" style="background: white" id="myDIV">
            <i class="fa-solid fa-print" title="Cetak Intermitten"></i>
        </button>



        <img class="gbr" style="width:800px;" src='<?= base_url("/uploads/LogoQuantum.jpeg") ?>'>
        <form action="">
            <table id="tabel" class="table table-bordered table-striped">
                <thead>
                    <tr>

                        <th style="text-align:center; width:5%; background-color:cyan; color:black">Kode TA</th>
                        <th style="text-align:center; width:20%; background-color:cyan; color:black">Nama</th>
                        
                        <th style="text-align:center; width:20%; background-color:cyan; color:black">Pekerjaan</th>
                        <th style="text-align:center; width:15%; background-color:cyan; color:black">Instansi</th>
                        <th style="text-align:center; width:5%; background-color:cyan; color:black">Tahun</th>
                        <th style="text-align:center; width:10%; background-color:cyan; color:black">Posisi</th>
                        <th style="text-align:center; width:15%; background-color:cyan; color:black">Intermitten</th>
                        <th style="text-align:center; width:5%; background-color:cyan; color:black">Bln</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($pengalaman) {
                        $tot = 0;
                        $indeks = 0;
                        foreach ($pengalaman as $v) {   // Looping luar
                    ?>
                            <tr>
                                <td style="width:5%; background-color:darkblue; color:aliceblue;  text-align: center"><?= $v[$indeks]['kode_ta'] ?></td>
                                <td style="width:20%; background-color:darkblue; color:aliceblue"><?= $v[$indeks]['nama_ta'] ?></td>
                                <td style="width:20%;background-color:darkblue;"></td>
                                <td style="width:15%;background-color:darkblue; "></td>
                                <td style="width:5%;background-color:darkblue; "></td>
                                <td style="width:10%;background-color:darkblue; "></td>
                                <td style="width:15%;background-color:darkblue; "></td>
                                <td style="width:5%;background-color:darkblue; "></td>
                                <?php
                                $jml_bln = 0;
                                $bln = 0;
                                $no = 0;        
                                foreach ($v as $val) {  // Looping dalam
                                    $bln = $val['jml_bln'];
			   $inter = $val['inter'];
			   if ($inter != null) {
                                    	if (str_contains($inter, "hari")) {
                                        		if ( ! str_contains($val['inter'], " 0 hari")) {
                                            		$bln++;
                                        		}
                                		} 
			   }
                                    $no++;
                                ?>
                            <tr>
                                <td style="width:5%; border: 1px solid; text-align: center"><?=$no?>.</td>
                                <td colspan="2" style="border: 1px solid;"><?= $val['pekerjaan'] ?></td>
                                
                                <td style="width:15%; border: 1px solid;"><?= $val['instansi'] ?></td>
                                <td style="width:5%; text-align:center; border: 1px solid;"><?= $val['tahun'] ?></td>
                                <td style="width:10%; border: 1px solid;"><?= $val['posisitugas'] ?></td>
                                <td style="width:15%; text-align:center; border: 1px solid;"><?= $val['inter'] ?></td>
                                <td style="width:5%; text-align:center; border: 1px solid;"><?= $bln ?></td>
                            </tr>
                        <?php
                                $jml_bln = $jml_bln + $bln;
                                }   // Looping dalam
                                
                                $TotThn = floor($jml_bln / 12);
                                if ($TotThn > 0) {
                                    $sisabln = $tot % 12;
                                } else {
                                    $sisabln = $tot;
                                }
                        ?>

                        <tr>
                            <td style="width:10%;"></td>
                            <td style="width:30%;"></td>
                            <td style="width:30%;"></td>
                            <td style="width:30%" ; text-align:left; colspan="3">Total = <?= $jml_bln ?> bulan = <?= $TotThn ?> tahun,<?= $sisabln ?> bulan</td>

                        </tr>

                    <?php
                            $tot = 0;
                        }   // Looping luar
                    }
                    
                    else { ?>
                    <tr>
                        <td colspan="5">Tidak ada data(kosong)..........................!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!</td>
                    </tr>
                <?php
                    } ?>
                </tbody>


            </table>

        </form>

    </div>
    <script>
        function cetak() {

            var x = document.getElementById("myDIV");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }

            window.print();

        }

        function inter() {
            window.location.href = "/laporanIntermitten/" + $kode
        }
    </script>
</body>

</html>