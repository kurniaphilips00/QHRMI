<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        function generatePDF() {
            var element = document.getElementById('element-to-print');
            html2pdf(element);
        }
    </script>
</head>
<body id="element-to-print">
<center><h1>Hello World</h1></center>
<img src="img/angryb.jpg" width="100" height="100">
<br>
<button onclick="generatePDF()">Image</button>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

</body>
</html>