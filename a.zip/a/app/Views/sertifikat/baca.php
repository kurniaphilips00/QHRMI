<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Form Baca Data Sertifikat</h2>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <?php if (session('gagal-menambah-sertifikat')) :  ?>
                            <div class="alert alert-danger" role="alert">
                                <?= session('gagal-menambah-sertifikat');  //  Delete success 
                                ?>
                            </div>
                        <?php endif; ?>

                        <?php if (session('sukses-tambah-srt')) :  ?>
                            <div class="alert alert-info" role="alert">
                                <?= session('sukses-tambah-srt');  //  Delete success 
                                ?>
                            </div>
                        <?php endif; ?>

                        <form method="get">
                            <?= csrf_field() ?>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nama sertifikat</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" readonly value="<?= $sertifikat['nama_sertifikat']; ?>">

                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nomor Sertifikat</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" readonly value="<?= $sertifikat['nomor_sertifikat'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Tgl. terbit</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" readonly value="<?= $sertifikat['tgl_terbit'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Tgl. kadaluarsa</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" readonly value="<?= $sertifikat['tgl_kadaluarsa'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Tenaga Ahli</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" readonly value="<?= $sertifikat['kode_ta']; ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Nama Tenaga Ahli</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" readonly value="<?= $sertifikat['nama_ta'] ?>">
                                </div>
                            </div>
                            <!--Menampilkan gambarnya (preview)-->
                            <div class="mb-3 row">
                                <div class="col-sm-2">
                                    <label style="width:200px">File image/pdf</label>
                                </div>
                                <?php
                                if ($sertifikat['lokasi'] != '') {
                                    //  Nama file diambilkan dari lokasi dimulai karakter ke tujuh (dari 0)
                                    //  Karena public/ otomatis merujuk ke public_html > tidak perlu ditulis
                                    $lokasi = isset($sertifikat['lokasi']) ? $sertifikat['lokasi'] : '';
                                    //https://stackoverflow.com/questions/10542310/how-can-i-get-the-last-7-characters-of-a-php-string
                                    $ekstensi = substr($lokasi, -3);    // Ambil ekstensi
                                    if ($ekstensi == 'pdf') {   //  Jika file pdf......
                                        //  Gunakan namafile untuk menampilkan file pdf
                                        $namafile = isset($sertifikat['namafile']) ? $sertifikat['namafile'] : '';
                                ?>
                                        <div class="col-sm-8">
                                            <input type="text" style="width: 500px;" readonly value="<?= $namafile ?>" />
                                        </div>
                                        <!--    Tampilkan file pdf saat diklik  -->
                                        <a href="<?= base_url('certificate/' . $namafile) ?>" target="_blank" style="font-style: italic;">Tampilkan Pdf</a>
                                    <?php
                                        //  Jika bukan file pdf, berarti file image (gambar)
                                    } else {
                                        //  Ambil nama file gambar melalui field lokasi
                                        //  Mengambil karakter ke 12 (dimulai dari 0) , karena diawali public_html/
                                        $gbr = '/' . substr($lokasi, 12);
                                    ?>
                                        <div class="col-sm-6">
                                            <!-- Tampilkan file image (gambar)  -->
                                            <img src="<?= $gbr; ?>" style="width: 400px;">
                                        </div>
                                <?php   }
                                }
                                ?>
                            </div> <!--class="mb-3 row">-->

                            <div class="modal-footer">
                                <a href="/sertifikat" class="btn btn-primary m-2" style="height: 35px; width: 90px">
                                    <i class="fa-solid fa-circle-left"></i></i> Kembali</a>

                            </div>
                        </form>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->



<?= $this->endsection(); ?>