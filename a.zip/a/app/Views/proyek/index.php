<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">

                    <div class="card-header">
                        <center>
                            <h1 style="font-weight: bold; font-family: Georgia" ;>Daftar Proyek</h1>
                        </center>
                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                            <a href="/tambah_proyek" class=btn btn-primary style="width:100px; color:blue; background-color: #a8ede4;">
                                <i class="fa-solid fa-circle-plus"></i> Tambah</a>
                        </div>

                        <?php $judul = "Pastikan file Excel berisi field-field dengan urutan :
                                  'kode_proyek'         //      kolom A
                                  'kode_instansi'       //      kolom B
                                  'instansi'            //      kolom C
                                  'pekerjaan'           //      kolom D
                                  'tahun'               //      kolom E
                                  'lokasi'              //      kolom F
                                  'alamat'              //      kolom G
                                  'nokontrak'           //      kolom H
                                  'mulai'               //      kolom I
                                  'selesai'             //      kolom J
                                  'nilai'               //      kolom K
                                  'referensi'           //      kolom L
                                  'jml_bln'             //      kolom M
                                  'inter'               //      kolom N
                                  'refpdf'              //      kolom O" ?>

                        <form action="proyek/importExcel" method="post" enctype="multipart/form-data" style="display: inline;">
                            <div class="btn-group" role="group">
                                <label for="files" class="btn">Pilih file excel</label>
                                <input id="files" type="file" accept=".xls, .xlsx, .ods" name='excel'>
                            </div>
                            <button title="<?= $judul ?>" type="submit" class="btn btn-primary" id="tombol" onclick="periksa()" style="width:80px;height: 30px; 
				                background-color:#90e1f5; color:black">
                                <i class="fa-sharp fa-solid fa-upload"></i>Import</button>
                        </form>
                        <form action="proyek/kosong" method="post" style="display: inline;">

                            <button title="Kosongkan tabel" type="submit" onclick="return confirm('Tabel akan dikosongkan, apakah anda yakin ? ')" class="btn btn-primary" style="width:150px;height: 30px; 
				                background-color:#90e1f5; color:black">
                                <i class="fa-solid fa-scissors"></i>Kosongkan tabel</button>
                        </form>
                        <a href="proyek/ExportToExcel" class="btn btn-primary" onclick="return confirm('Tabel akan diekspor ke file Excel, yakin ingin ekspor ?')" style="width:75px; height:30px; background-color:#90e1f5; 
				        margin-right: 20px; color:black" title="Export to Excel">Export<i class="fa-solid fa-file-arrow-down"></i></a>
                    </div>
                    <br>
                </div>
                <br>
                <!-- /.card-header -->
                <div class="card-body">
                    <?php if (session('sukses-tambah')) :  ?>
                        <div class="alert alert-info" role="alert">
                            <?= session('sukses-tambah'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (session('sukses-hapus')) :  ?>
                        <div class="alert alert-info" role="alert">
                            <?= session('sukses-hapus'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (session('sukses-edit')) :  ?>
                        <div class="alert alert-info" role="alert">
                            <?= session('sukses-edit'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (session('delete-all-success')) :  ?>
                        <div class="alert alert-info" role="alert">
                            <?= session('delete-all-success'); ?>
                        </div>
                    <?php endif; ?>

                    <!-- DAFTAR PROYEK YANG AKAN DIHAPUS    --------------------------------------------------------->
                    <form action="<?= route_to('delete_all_proyek') ?>" method="get">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th><button type="submit" name="HapusProyek" value="1" style="width: 25px; height: 25px; text-align: top; color: red; padding: 0 0 0 0" class="tombol" title="Hapus semua proyek yang dicentang"><i class="fa fa-trash"></i></button>
                                    </th>
                                    <th style="text-align:center; width:5%">No</th>
                                    <th style="text-align:center; width:5%">Kode Proyek</th>
                                    <th style="text-align:center; width:20%">Instansi</th>
                                    <th style="text-align:center; width:20%">Pekerjaan</th>
                                    <th style="text-align:center; width:10%">Mulai</th>
                                    <th style="text-align:center; width:10%">Selesai</th>
                                    <th style="text-align:center; width:5%">Tahun</th>
                                    <th style="text-align:center; width:5%">Intermitten</th>
                                    <th style="text-align:center; width:15%">Edit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($proyek) {
                                    $no = 1;
                                    foreach ($proyek as $v) {

                                        $id = isset($v['id']) ? $v['id'] : '';
                                        $kodeproyek = isset($v['kode_proyek']) ? $v['kode_proyek'] : '';
                                        $tahun = isset($v['tahun']) ? $v['tahun'] : '';
                                        $instansi = isset($v['instansi']) ? $v['instansi'] : '';
                                        $pekerjaan = isset($v['pekerjaan']) ? $v['pekerjaan'] : '';
                                        $inter = isset($v['inter']) ? $v['inter'] : '';
                                        $mulai = isset($v['mulai']) ? $v['mulai'] : '';
                                        $selesai = isset($v['selesai']) ? $v['selesai'] : '';
                                        if ($mulai != null && $mulai != '0000-00-00') {
                                            $tgl = new DateTime($mulai);
                                            $tgl_mulai = $tgl->format('d-m-Y'); //  Menampilkan format Indo
                                        } else {
                                            $tgl_mulai = 'kosong';
                                        }
                                        if ($selesai != null &&  $selesai != '0000-00-00') {
                                            $tgl = new DateTime($selesai);
                                            $tgl_selesai = $tgl->format('d-m-Y'); //  Menampilkan format Indo
                                        } else {
                                            $tgl_selesai = 'kosong';
                                        }
                                ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" name="ckdel[]" value="<?= $v['id'] ?>">
                                            </td>
                                            <td style="width:5%"><?= $no; ?></td>
                                            <td style="width:5%"><?= $kodeproyek; ?></td>

                                            <td style="width:20%"><?= $instansi ?></td>
                                            <td style="width:20%"><?= $pekerjaan ?></td>
                                            <td style="width:10%"><?= $tgl_mulai ?></td>
                                            <td style="width:10%"><?= $tgl_selesai ?></td>
                                            <td style="width:5%"><?= $tahun ?></td>
                                            <td style="width:5%"><?= $inter ?></td>
                                            <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->
                                            <td style="width:15%; text-align:center">
                                                <a href="/baca_Proyek/<?= $id; ?>">
                                                    <i class="fa-solid fa-glasses" title="baca"></i></a>
                                                    |
                                                    <a href="/edit_prj/<?= $id; ?>">
                                                        <i class="fa-solid fa-pencil" title="edit"></i></a>|
                                                        
                                                            <a href="/hapus_proyek/<?= $id; ?>" onclick="return confirm('Yakin ingin menghapus proyek')">
                                                            <i class="fa-solid fa-trash-can" title="delete"></i></a>
                                            </td>
                                            <!---------------------------------------------Tombol-tombol editing--------------------------------------------------->
                                        </tr>
                                    <?php
                                        $no++;
                                    }
                                } else { ?>
                                    <tr>
                                        <td colspan="5">Tidak ada data(kosong)..........................!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!</td>
                                    </tr>
                                <?php
                                } ?>
                            </tbody>
                        </table>
                    </form>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
    </div>
    <!-- /.container-fluid -->

</section>
<!-- /.content -->

<script>
    function periksa() {
        var berkas = document.getElementById('files').value;
        if (berkas == '') {
            alert('File excel masih belum ada....!');
            document.getElementById("files").focus();
        }
    }

    function start() { //    Mengatur tampilan format tanggal mulai
        const tgl = new Date(document.getElementById('awal01').value);
        let thn = tgl.getFullYear();
        let bulan = tgl.getMonth() + 1; // Months start at 0
        alert(bulan);
        let tanggal = tgl.getDate();
        let formattedTMySQL = thn + '-' + bulan + '-' + tanggal; //  Format tanggal disesuaikan dengan MySQL AGAR BISA DISIMPAN
        document.getElementById('awal00').value = formattedTMySQL; //  Menampilkan tanggal lahir dengan format MySQL
    }

    function hitungintermitten() {
        let awal = document.getElementById('tgl_awal').value;
        if (awal != "") {
            const tglawal = new Date(document.getElementById('tgl_awal').value);
            const tglakhir = new Date(document.getElementById('tgl_akhir').value);
            let time_difference = tglakhir.getTime() - tglawal.getTime();
            let Years_difference = 0;
            let SisaBulan = 0;
            let SisaHari = 0;
            var inter = "( ";
            //calculate days difference by dividing total milliseconds in a day  
            let days_difference = time_difference / (1000 * 60 * 60 * 24);
            let Months_difference = Math.floor(days_difference / 30);
            console.log(Months_difference.toString());
            if (Months_difference > 12) {
                Years_difference = Math.floor(Months_difference / 12);
                SisaBulan = Months_difference % 12;
                SisaHari = days_difference - ((Years_difference * 360) + (SisaBulan * 30));
                inter += Years_difference + " tahun ";
                inter += SisaBulan + " bulan ";
                inter += SisaHari + " hari ";
            } else if (Months_difference > 0) {
                SisaHari = days_difference % 30;
                inter += Months_difference + " bulan ";
                inter += SisaHari + " hari ";
            } else {
                inter += days_difference + " hari ";
            }
            inter += " )";
            let tahuntglakhir = tglakhir.getFullYear();
            let bulantglakhir = tglakhir.getMonth() + 1; // Months start at 0
            let haritglakhir = tglakhir.getDate();
            let tglSelesai = tahuntglakhir + '-' + bulantglakhir + '-' + haritglakhir;
            document.getElementById('ak').value = tglSelesai;
            document.getElementById('intermitten').value = inter;
            document.getElementById('jmlbln').value = Months_difference;
        }

    }

    function cari_pengalaman() {
        // alert('Hai');
        const v = document.getElementById('names').value;
        if (v != '') {
            let names = document.getElementById('names');
            names.onclick = function(event) {
                var target = event.target;
                var nama = event.target.value;
                //  alert(nama);
                window.location.href = "/fNama/" + nama;
            };
        }

    }

    function ShowExperts($id) {
        //      let nama = document.getElementById('#intermitten').innerText;
        window.location.href = "/ExpertsList/" + $id
    }
</script>


<?= $this->endsection(); ?>