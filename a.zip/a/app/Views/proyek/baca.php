<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <center>
                        <h1 style="font-weight: bold; font-family: Georgia" ;>Baca Detil Proyek</h1>
                    </center>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form method="get">
                            <!-- Ini alias dari update(simdat_TA=simpan update TA)-------------------->
                            <?= csrf_field(); ?>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Proyek</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $result['kode_proyek'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Kode Instansi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $result['kode_instansi'] ?>" readonly>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Instansi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" value="<?= $result['instansi'] ?>" readonly>
                                </div>
                            </div>

                            <!--Posisi Penugasan dipakai untuk mengisi Posisi yang diusulkan-->
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Pekerjaan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" readonly value="<?= $result['pekerjaan'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Lokasi</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" readonly value="<?= $result['lokasi'] ?>">
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Alamat</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" readonly value="<?= $result['alamat'] ?>">
                                </div>
                            </div>


                            <?php
                            $mulai = isset($result['mulai']) ? $result['mulai'] : '';
                            $selesai = isset($result['selesai']) ? $result['selesai'] : '';
                            if ($mulai != '0000-00-00' && $mulai != null  && $mulai != '') {
                                $mulai = new DateTime($result['mulai']);
                                $mulai = $mulai->format('d-m-Y'); //  Menampilkan format Indo

                            }
                            if ($selesai != '0000-00-00' && $selesai != null  && $selesai != '') {
                                $selesai = new DateTime($result['selesai']);
                                $selesai = $selesai->format('d-m-Y'); //  Menampilkan format Indo
                            }
                            ?>
                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Mulai</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" readonly value="<?= $mulai ?>">
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Selesai</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" readonly value="<?= $selesai ?>">
                                </div>

                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Tahun</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" value="<?= $result['tahun'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Jumlah bulan</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" value="<?= $result['jml_bln'] ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Intermitten</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" readonly value="<?= $result['inter'] ?>">
                                </div>
                            </div>
                            <?php
                            $nilai = isset($result['nilai']) ? $result['nilai'] : '';
                            $formattedNum = number_format($nilai, 2, ',', '.');

                            ?>

                            <div class="mb-3 row">
                                <br>
                                <label class="col-sm-2 col-form-label">Nilai </label>
                                <div class="col-sm-8">
                                    <input type="text" style="width: 500px;" readonly value="<?= 'Rp. ' . $formattedNum ?>">
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Nomor Kontrak</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" readonly value="<?= $result['nokontrak'] ?>">
                                </div>
                            </div>

                            <div class="mb-1 row">
                                <label class="col-sm-2 col-form-label">Nomor Referensi</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" readonly value="<?= $result['referensi'] ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <?php
                                $surat_referensi = isset($result['surat_referensi']) ? $result['surat_referensi'] : '';
                                $lokasi_surat_referensi = $result['lokasi_surat_referensi'];
                                if ($lokasi_surat_referensi != '' && $lokasi_surat_referensi != null) {
                                    $ref = substr($lokasi_surat_referensi, 12);
                                } else {
                                    $ref = "";
                                }
                                //dd($lokasi_surat_referensi);
                                ?>
                                <br>
                                <label class="col-sm-2 col-form-label">File Referensi</label>
                                <div class="col-sm-8">
                                    <input type="text" style="width: 500px;" readonly value="<?= $surat_referensi ?>" />
                                </div>
                                <!-- Menampilkan surat referensi yang ada di lokasi -->
                                <a href="<?= base_url($ref) ?>" target="_blank" style="font-style: italic;">Tampilkan Pdf</a>
                            </div>
                            <a href="/proyek" class="btn btn-primary m-2" style="height: 40px; width: 110px">
                                <i class="fa-solid fa-circle-left"></i></i> Kembali</a>
                            <!--<button type="reset" class="btn btn-dark">Close</button>-->
                        </form>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<script>
    function positions() {
        // alert('hai');
        let posi = document.getElementById('pos').value;
        document.getElementById('posisinya').value = posi;
    };



    function IsiNama() {
        const sel = document.getElementById("ta_ID");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("Nama_Personil").value = teks;
    }

    function IsiJabatan() {
        const sel = document.getElementById("positions");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("jabatan").value = teks;
    }

    function IsiID() {

        let ta = document.getElementById('ta_ID').value;
        const sel = document.getElementById("ta_ID");
        sel.options[sel.selectedIndex].text = ta;
    }

    function ShowExperts($id) {
        //      let nama = document.getElementById('#intermitten').innerText;
        window.location.href = "/ExpertsList/" + $id
    }

    function IsiIDPekerjaan() {
        let idKegiatan = document.getElementById('pekerjaan').value;
        const sel = document.getElementById("pekerjaan");
        sel.options[sel.selectedIndex].text = idKegiatan;
    }

    function IsiPekerjaan() {
        const sel = document.getElementById("pekerjaan");
        const teks = sel.options[sel.selectedIndex].text;
        document.getElementById("aktifitas").value = teks;
    }
</script>

<?= $this->endsection(); ?>