<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
<head>

<meta charset="utf-8">
    <title>jQuery UI Autocomplete - Combobox</title>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
    <link type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css" rel="stylesheet" />
    <!--from   w  ww .j ava  2 s .c  o  m-->
    <style>
        .custom-combobox {
            position: relative;
            display: inline-block;
        }

        .custom-combobox-toggle {
            position: absolute;
            top: 0;
            bottom: 0;
            margin-left: -1px;
            padding: 0;
            /* support: IE7 */
            *height: 1.7em;
            *top: 0.1em;
        }

        .custom-combobox-input {
            margin: 0;
            padding: 0.3em;
        }
    </style>
    <script>
        (function($) {
            $.widget("custom.combobox", {
                _create: function() {
                    this.wrapper = $("<span>")
                        .addClass("custom-combobox")
                        .insertAfter(this.element);

                    this.element.hide();
                    this._createAutocomplete();
                    this._createShowAllButton();
                },

                _createAutocomplete: function() {
                    var selected = this.element.children(":selected"),
                        value = selected.val() ? selected.text() : "";

                    this.input = $("<input>")
                        .appendTo(this.wrapper)
                        .val(value)
                        .attr("title", "")
                        .addClass("custom-combobox-input ui-widget ui-widget-content ui-state-default ui-corner-left")
                        .autocomplete({
                            delay: 0,
                            minLength: 0,
                            source: $.proxy(this, "_source")
                        })
                        .tooltip({
                            tooltipClass: "ui-state-highlight"
                        });

                    this._on(this.input, {
                        autocompleteselect: function(event, ui) {
                            ui.item.option.selected = true;
                            this._trigger("select", event, {
                                item: ui.item.option
                            });
                        },

                        autocompletechange: "_removeIfInvalid"
                    });
                },

                _createShowAllButton: function() {
                    var input = this.input,
                        wasOpen = false;

                    $("<a>")
                        .attr("tabIndex", -1)
                        .attr("title", "Show All Items")
                        .tooltip()
                        .appendTo(this.wrapper)
                        .button({
                            icons: {
                                primary: "ui-icon-triangle-1-s"
                            },
                            text: false
                        })
                        .removeClass("ui-corner-all")
                        .addClass("custom-combobox-toggle ui-corner-right")
                        .mousedown(function() {
                            wasOpen = input.autocomplete("widget").is(":visible");
                        })
                        .click(function() {
                            input.focus();

                            // Close if already visible
                            if (wasOpen) {
                                return;
                            }

                            // Pass empty string as value to search for, displaying all results
                            input.autocomplete("search", "");
                        });
                },

                _source: function(request, response) {
                    var matcher = new RegExp($.ui.autocomplete.escapeRegex(request.term), "i");
                    response(this.element.children("option").map(function() {
                        var text = $(this).text();
                        if (this.value && (!request.term || matcher.test(text)))
                            return {
                                label: text,
                                value: text,
                                option: this
                            };
                    }));
                },

                _removeIfInvalid: function(event, ui) {

                    // Selected an item, nothing to do
                    if (ui.item) {
                        return;
                    }

                    // Search for a match (case-insensitive)
                    var value = this.input.val(),
                        valueLowerCase = value.toLowerCase(),
                        valid = false;
                    this.element.children("option").each(function() {
                        if ($(this).text().toLowerCase() === valueLowerCase) {
                            this.selected = valid = true;
                            return false;
                        }
                    });

                    // Found a match, nothing to do
                    if (valid) {
                        return;
                    }

                    // Remove invalid value
                    this.input
                        .val("")
                        .attr("title", value + " didn't match any item")
                        .tooltip("open");
                    this.element.val("");
                    this._delay(function() {
                        this.input.tooltip("close").attr("title", "");
                    }, 2500);
                    this.input.data("ui-autocomplete").term = "";
                },

                _destroy: function() {
                    this.wrapper.remove();
                    this.element.show();
                }
            });
        })(jQuery);

        $(function() {
            $("#combobox").combobox();
            $("#toggle").click(function() {
                $("#combobox").toggle();
            });
        });
    </script>
    
</head>
<style type="text/css">
    .alert-displaynone {
        display: none;
    }
</style>

<section class="showcase">
    <div class="container">
        <div class="pb-2 mt-4 mb-2 border-bottom">
            <h2>Upload Lampiran</h2>
        </div>

        <!--        https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/        -->
        <form method="post" id="upload_image_form" enctype="multipart/form-data">

            <div class="mb-3 row">
                <label for="nama_ta" class="col-sm-2 col-form-label">Nama Tenaga Ahli</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="nama_ta" id="Tenaga_Ahli">

                </div>
            </div>

            <div class="mb-3 row">
                <label class="col-sm-2 col-form-label">Kode Tenaga Ahli</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="kode_ta" id="Kode_Tenaga_Ahli" onfocus="isikodeTA()" readonly>


                </div>
            </div>
            <br>
            <div class="mb-3 row">
                <label for="Nama_lampiran" class="col-sm-2 col-form-label" style="width:210px">Lampiran</label>
                <select class="col-sm-4" name="lampiran" style="height: 35px;">
                    <option value="">Pilih lampiran</option>
                    <option value="PasFoto">Pas Foto</option>
                    <option value="tt">Tanda tangan</option>
                    <option value="KTP">KTP</option>
                    <option value="NPWP">NPWP</option>
                    <option value="SIPP">SIPP</option>
                    <option value="STR">STR</option>
                    <option value="KTA">KTA</option>
		<option value="Ijazah">Ijazah</option>
                </select>
            </div>
            <br><br>

            <!--        https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/        -->

            <div id="alertMessage" class="alert alert-info mb-3" style="display: none">
                <span id="alertMsg"></span>
            </div>
            <div class="d-grid text-center">
                <img class="mb-3" id="ajaxImgUpload" alt="Preview Image" src="https://via.placeholder.com/300" />
            </div>
            <div class="mb-3 row">
                <label for="Nama_lampiran" class="col-sm-2 col-form-label" style="width:210px">Pilih file image</label>
                <input type="file" name="file" multiple="true" id="finput" onchange="onFileUpload(this);" style="width:900px" 
                class="col-sm-4" accept="image/*">
                <!-- <button type="submit" class="btn btn-outline-secondary"  style="color:blue">Upload</button>-->
            </div>
            <!--        https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example/        -->


            <hr>
            <div class="row align-items-center">
                <div class="col">
                    <div class="progress" style="width:500px; margin-left: 300px;">
                        <div id="file-progress-bar" class="progress-bar"></div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <a href="/upload" class="btn btn-primary m-2" style="height: 40px; width: 110px"><i class="fa-solid fa-circle-left"></i></i> Kembali</a>
                <button id="uploadBtn" type="submit" class="btn btn-success" 
                style="height: 40px; width: 110px"><i class="fa-solid fa-file-arrow-up"></i>Upload</button>
            </div>
        </form>


    </div> <!--<div class="container">-->

</section>

<!--    https://techarise.com/demos/ci/file-upload-with-progress-bar-jquery-ajax   -->
<!--    https://www.positronx.io/codeigniter-ajax-image-upload-with-preview-example -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    function onFileUpload(input, id) {
        id = id || '#ajaxImgUpload';
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $(id).attr('src', e.target.result).width(300)
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    $(document).ready(function() {
        $('#upload_image_form').on('submit', function(e) {
            $('#uploadBtn').html('Uploading ...');
            $('#uploadBtn').prop('Disabled');
            e.preventDefault();
            if ($('#file').val() == '') {
                alert("Choose File");
                $('#uploadBtn').html('Upload');
                $('#uploadBtn').prop('enabled');
                document.getElementById("upload_image_form").reset();
            } else {
                $.ajax({

                    xhr: function() {
                        var xhr = new window.XMLHttpRequest();
                        //  Kemajuan progres bar dihitung di sini
                        xhr.upload.addEventListener("progress", function(element) {
                            if (element.lengthComputable) {
                                var percentComplete = ((element.loaded / element.total) * 100);
                                $("#file-progress-bar").width(percentComplete + '%');
                                $("#file-progress-bar").html(percentComplete + '%');
                            }
                        }, false);
                        return xhr;
                    },
                    url: "upl",
                    method: "POST",
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    cache: false,
                    dataType: "json",

                    beforeSend: function() {
                        $("#file-progress-bar").width('0%');
                    },
                    success: function(res) {
                        //   console.log(res.success);
                        // alert(res);
                        if (res.success == true) {
                            $('#ajaxImgUpload').attr('src', 'https://via.placeholder.com/300');
                            $('#alertMsg').html(res.msg);
                            $('#alertMessage').show();
                            $('#uploadBtn').html('Sukses upload...');
                            $('#uploadBtn').setAttribute('color', 'green');
                        } else if (res.success == false) {
                            $('#alertMsg').html(res.msg);
                            $('#alertMessage').show();
                        }
                        setTimeout(function() {
                            $('#alertMsg').html('');
                            $('#alertMessage').hide();
                        }, 4000);
                        $('.uploadBtn').html('Upload');
                        $('#uploadBtn').prop('Enabled');
                        document.getElementById("upload_image_form").reset();
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });
            }
        });
    });
</script>

<script>
    // autocomplete dari  https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_autocomplete
    function autocomplete(inp, arr) {
        /*the autocomplete function takes two arguments,
        the text field element and an array of possible autocompleted values:*/
        var currentFocus;
        /*execute a function when someone writes in the text field:*/
        inp.addEventListener("input", function(e) {
            var a, b, i, val = this.value;
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!val) {
                return false;
            }
            currentFocus = -1;
            /*create a DIV element that will contain the items (values):*/
            a = document.createElement("DIV");
            a.setAttribute("id", this.id + "autocomplete-list");
            a.setAttribute("class", "autocomplete-items");
            /*append the DIV element as a child of the autocomplete container:*/
            this.parentNode.appendChild(a);
            /*for each item in the array...*/
            for (i = 0; i < arr.length; i++) {
                /*check if the item starts with the same letters as the text field value:*/
                if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                    /*create a DIV element for each matching element:*/
                    b = document.createElement("DIV");
                    /*make the matching letters bold:*/
                    b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                    b.innerHTML += arr[i].substr(val.length);
                    /*insert a input field that will hold the current array item's value:*/
                    b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                    /*execute a function when someone clicks on the item value (DIV element):*/
                    b.addEventListener("click", function(e) {
                        /*insert the value for the autocomplete text field:*/
                        inp.value = this.getElementsByTagName("input")[0].value;
                        /*close the list of autocompleted values,
                        (or any other open lists of autocompleted values:*/
                        closeAllLists();
                    });
                    a.appendChild(b);
                }
            }
        });
        /*execute a function presses a key on the keyboard:*/
        inp.addEventListener("keydown", function(e) {
            var x = document.getElementById(this.id + "autocomplete-list");
            if (x) x = x.getElementsByTagName("div");
            if (e.keyCode == 40) {
                /*If the arrow DOWN key is pressed,
                increase the currentFocus variable:*/
                currentFocus++;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 38) { //up
                /*If the arrow UP key is pressed,
                decrease the currentFocus variable:*/
                currentFocus--;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 13) {
                /*If the ENTER key is pressed, prevent the form from being submitted,*/
                e.preventDefault();
                if (currentFocus > -1) {
                    /*and simulate a click on the "active" item:*/
                    if (x) x[currentFocus].click();
                }
            }
        });

        function addActive(x) {
            /*a function to classify an item as "active":*/
            if (!x) return false;
            /*start by removing the "active" class on all items:*/
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = (x.length - 1);
            /*add class "autocomplete-active":*/
            x[currentFocus].classList.add("autocomplete-active");
        }

        function removeActive(x) {
            /*a function to remove the "active" class from all autocomplete items:*/
            for (var i = 0; i < x.length; i++) {
                x[i].classList.remove("autocomplete-active");
            }
        }

        function closeAllLists(elmnt) {
            /*close all autocomplete lists in the document,
            except the one passed as an argument:*/
            var x = document.getElementsByClassName("autocomplete-items");
            for (var i = 0; i < x.length; i++) {
                if (elmnt != x[i] && elmnt != inp) {
                    x[i].parentNode.removeChild(x[i]);
                }
            }
        }
        /*execute a function when someone clicks in the document:*/
        document.addEventListener("click", function(e) {
            closeAllLists(e.target);
        });
    }

    var nama = <?php echo json_encode($nama); ?>;
    var kode = <?php echo json_encode($kode); ?>;
    autocomplete(document.getElementById("Tenaga_Ahli"), nama);

    function isikodeTA() {
        const ta = document.getElementById("Tenaga_Ahli").value; //Ini id dari drop down/ fungsi onclick
        let index = nama.indexOf(ta);
        document.getElementById("Kode_Tenaga_Ahli").value = kode[index];
    }
</script>


<?= $this->endsection(); ?>