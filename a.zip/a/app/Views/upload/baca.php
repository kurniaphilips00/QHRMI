<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <h2>Form Baca Lampiran Tenaga Ahli</h2>
                    <!-- /.card-header -->
                    <div class="card-body">


                        <form action="" method="post" enctype="multipart/form-data">
                            <?= csrf_field(); ?>

                            <div class="row ms-3">

                                <div class="mb-3 row">
                                    <div class="col-sm-2 mx-3" style="margin-left:20px;">
                                        <label>Nama Tenaga Ahli</label>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" value="<?= $img['nama_ta'] ?>" readonly>
                                    </div>
                                </div>


                                <div class="mb-3 row">
                                    <div class="col-sm-2 mx-3" style="margin-left:20px;">
                                        <label>Nama file</label>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" value="<?= $img['namafile'] ?>" readonly>
                                    </div>
                                </div>


                                <!--Menampilkan gambarnya (preview)-->
                                <div class="mb-3 row">
                                    <div class="col-sm-2 mx-3" style="margin-left:20px;">
                                        <label style="width:200px">Gambar</label>
                                    </div>
                                    <?php
                                    if ($img['lokasi'] != '') {
                                        //  Nama file diambilkan dari lokasi dimulai karakter ke tujuh (dari 0)
                                        //  Karena public/ otomatis merujuk ke public_html > tidak perlu ditulis
                                        $lokasi = isset($img['lokasi']) ? $img['lokasi'] : '';
                                        $gbr = '/' . substr($lokasi, 12);
                                    }
                                    ?>

                                    <div class="col-sm-6">
                                        <img src="<?= $gbr; ?>" style="width: 200px;">
                                    </div>
                                </div>
                                <br>
                                <br>

                                <div class="mb-3 row">
                                    <div class="col-sm-2 mx-3" style="margin-left:20px;">
                                        <label style="width: 200px;">Lokasi</label>
                                    </div>
                                    <div class="col-sm-4">
                                        <input type="text" class="form-control" readonly value="<?= $img['lokasi'] ?>">
                                    </div>
                                </div>

                                <br><br>
                                <div class="modal-footer">
                                    <a href="/upload" class="btn btn-primary px-2 mx-2" style="height: 40px; width: 100px"><i class="fa-solid fa-circle-left"></i></i>Kembali</a>

                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- /.col -->
                </div>

            </div>
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</section>


<?= $this->endSection(); ?>