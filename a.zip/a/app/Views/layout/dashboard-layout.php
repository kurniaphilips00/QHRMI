<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="<?= csrf_token() ?>" content="<?= csrf_hash() ?>" class="csrf">
  <title><?= (isset($judul)) ? $judul : '' ?></title>
  <link rel="icon" href="img/logo.jpg">


  <!--Datatable Server Side-->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">

  <!-- ################### CodeIgniter 4.3.6 (24 Februari 2020)  ############ --------------->

  <!-- ################### Dashboard Admin LTE 2.4.2 memakai Data Table With Full Features ############ --------------->

  <!-- |||||||||||||| File-file yang diperlukan untuk dashboard dari Admin LTE 2.4.2 di dalam folder bower_components   !!!!-->
  <!-- vvvvvvvvvvvvvv--------------------------------------------------------------------------------------------------------->
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="../../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- !!!!!!!!!!! File-file yang diperlukan untuk dashboard dari Admin LTE 2.4.2 di dalam folder bower_components !!!!!!!!!!!!!!!!!-->
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css">

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <style type="text/css">
    .jqstooltip {
      position: absolute;
      left: 0px;
      top: 0px;
      visibility: hidden;
      background: rgb(0, 0, 0) transparent;
      background-color: rgba(0, 0, 0, 0.6);
      filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);
      -ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";
      color: white;
      font: 10px arial, san serif;
      text-align: left;
      white-space: nowrap;
      padding: 5px;
      border: 1px solid white;
      box-sizing: content-box;
      z-index: 10000;
    }

    .jqsfield {
      color: white;
      font: 10px arial, san serif;
      text-align: left;
    }
  </style>
  <!------------------------Fontawesome------------------------------------------------------------------>
  <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
  <!------------------------Fontawesome------------------------------------------------------------------>

  <!-- ^^^^^^^^^^^^^^^ Dashboard Admin LTE 2.4.2 memakai Data Table With Full Features ---------------------------->
  <!-- ||||||||||||||| -------------------------------------------------------------------------------------------->

  <!--JQuery Autocomplete > dari W3Schools (https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_autocomplete) -->
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

  <!--  
  /*
Google Bard said :
"There are a few key differences between developing a CodeIgniter 4 application on localhost and an FTP site:

Localhost

Development environment: When developing on localhost, you have complete control over your development environment. This means that you can install any dependencies that you need, and you can configure your server to your liking.
Debugging: Debugging a CodeIgniter 4 application on localhost is much easier than on an FTP site. This is because you have access to all of the server logs and error messages.
Testing: Testing a CodeIgniter 4 application on localhost is also much easier than on an FTP site. This is because you can access the application directly in your web browser, and you can use any testing tools that you want.

FTP site

Development environment: When developing on an FTP site, you are limited by the development environment that is provided by your hosting provider. This means that you may not be able to install all of the dependencies that you need, and you may not be able to configure the server to your liking.
Debugging: Debugging a CodeIgniter 4 application on an FTP site can be more difficult than on localhost. This is because you may not have access to all of the server logs and error messages.
Testing: Testing a CodeIgniter 4 application on an FTP site can also be more difficult than on localhost. This is because you may need to upload the application to the server each time that you want to test it.

It is normal for errors to occur on an FTP site that do not occur on localhost, and vice versa. 
This is because the two environments may be configured differently. 
For example, the PHP version or the database configuration may be different.

Here are some possible reasons for this:

Different PHP versions: The PHP version on your FTP site may be different from the PHP version on your localhost. 
                        This can cause errors if your code is not compatible with the PHP version on your FTP site.
Different database configurations: The database configuration on your FTP site may be different from the database configuration 
                        on your localhost. This can cause errors if your code is not able to connect to the database on your FTP site.
Missing dependencies:   Your CodeIgniter 4 application may require certain dependencies that are not installed on your FTP site. 
                        This can cause errors if your application is unable to load the required dependencies.
Incorrect permissions:  The permissions on your FTP site may be incorrect. This can prevent your application from running correctly.
                        To troubleshoot errors that occur on your FTP site but not on localhost, you can try the following:

Check the PHP version on your FTP site and make sure that your code is compatible with that version.
Check the database configuration on your FTP site and make sure that your code is able to connect to the database.
Make sure that all of the required dependencies for your CodeIgniter 4 application are installed on your FTP site.
Check the permissions on your FTP site and make sure that they are correct.
Use a version control system such as Git to track your changes. This will make it easier to revert to a previous version of the application if something goes wrong.
Use a remote development environment such as Visual Studio Code or Sublime Text. These environments allow you to edit and debug your code directly on the FTP site.
Use a testing tool such as Cypress or Selenium to test your application. These tools allow you to test your application without having to upload it to the server each time.

Biang keladinya adalah terhapusnya folder /ci_4/app/Views/errors di ftp site, selain kemungkinan faktor2 di atas, 
sehingga tidak bisa menampilkan pesan error yang seharusnya (default), diatasi dengan cara copy 
folder errors dari localhost ( D:\laragon-portable\www\q\app\Views\errors\ )

*/
   -->



</head>

<body class="hold-transition skin-blue sidebar-mini" data-rsssl=1>
  <div class="wrapper">

    <header class="main-header">
      <!-- Logo -->
      <a href="" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>A</b>LT</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>Quantum</b>HRMI</span>
      </a>
      <!-- Header Navbar: style can be found in header.less -->
      <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </a>

        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">

            <!-- User Account -->
            <li class="dropdown user user-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Halo <?php echo session()->get('username') ?>
                <img src="../../dist/img/usr.png" class="user-image" alt="User Image">

              </a>
              <ul class="dropdown-menu">
                <!-- User image -->
                <li class="user-header">
                  <img src="../../dist/img/usr.png" class="img-circle" alt="User Image">

                </li>

            </li>
            <!-- Menu Footer-->
            <li class="user-footer">
              <div class="pull-right">
                <a href="<?php echo site_url('logout') ?>" class="btn btn-default btn-flat">Sign out</a>
              </div>
            </li>
          </ul>
          </li>
          <!-- Help -->
          <li>
            <a href="/help" title='Help'>?</a>
          </li>
          <!-- Help -->
          </ul>
        </div>
      </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
      <section class="sidebar">

        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
          <li class="header" style="color:burlywood">MENU UTAMA</li>
          <li>
            <a href="/home/dashboard">
              <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
          </li>
          <li class="treeview">
            <a href="/ta">
              <i class="fa-solid fa-user-graduate"></i><span>Tenaga Ahli</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="/ta"><i class="fa-solid fa-users"></i>Daftar Tenaga Ahli</a></li>
              <li><a href="/old-exp"><i class="fa-sharp fa-solid fa-building-user"></i>Pengalaman (Quantum)</a></li>
              <li><a href="/experiences"><i class="fa-sharp fa-solid fa-building-user"></i>Pengalaman (Non Quantum)</a></li>
              <li><a href="/imt" title="Intermitten"><i class="fa-solid fa-print"></i>Cetak Intermitten</a></li>
              <li><a href="/cv" title="Riwayat Hidup"><i class="fa-solid fa-print" title="Satu Halaman"></i>Cetak Riwayat Hidup</a></li>
            <!--
              <li><a href="/rh" title="Download Riwayat Hidup beberapa tenaga ahli"><i class="fa-solid fa-print" title="Beberapa Halaman"></i>Download Riwayat Hidup</a></li>
            -->
              <li><a href="/pendidikan" title="Riwayat Hidup"><i class="fa-solid fa-book-open-reader"></i>Pendidikan</a></li>
              <li><a href="/sertifikat"><i class="fa-sharp fa-solid fa-certificate"></i></i>Sertifikat</a></li>
              <li><a href="/bahasa"><i class="fa-sharp fa-solid fa-earth-asia"></i></i>Bahasa</a></li>
              <li><a href="/upload" title="Upload"><i class="fa-solid fa-image"></i>Lampiran</a></li>
            </ul>

            <a href="/pengalaman">
              <i class="fa-solid fa-building-shield"></i><span>Proyek</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="/proyek"><i class="fa-sharp fa-solid fa-city"></i>Daftar Proyek</a></li>
            </ul>
          </li>

          <li class="treeview">
            <a href="#"><i class="fa-solid fa-file-signature"></i>Tender</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="/tender"><i class="fa-solid fa-file-signature"></i>Daftar Tender</a></li>
              <li class="treeview">
                <a href="#"><i class="fa-sharp fa-solid fa-file-pdf"></i>Dokumen Tender
                  <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                  </span>
                </a>
                <ul class="treeview-menu">
                  <li><a href="/akta"><i class="fa-sharp fa-solid fa-file-lines"></i>Akta</a></li>
                </ul>
              </li>
              <li><a href="/omset"><i class="fa-solid fa-money-bill-1-wave"></i>Daftar Omset</a></li>

            </ul><!-- class="treeview-menu"-->
          </li>
          <li class="header" style="color:burlywood">MENU TAMBAHAN</li>
          <li>
            <a href="/posisi"><i class="fa-solid fa-user-plus"></i><span>Posisi</span></a>
            <a href="/kategori"><i class="fa-solid fa-shapes"></i><span>Kategori</span></a>
            <a href="/instansi"><i class="fa-sharp fa-solid fa-building"></i><span>Instansi</span></a>
            <a href="/kota"><i class="fa fa-taxi"></i><span>Kota</span></a>
            <a href="/jurusan"><i class="fa-solid fa-graduation-cap"></i><span>Jurusan</span></a>
            <a href="/universitas"><i class="fa fa-university"></i><span>Universitas</span></a>
            <a href="/user"><i class="fa fa-user"></i><span>User</span></a>
          </li>
        </ul>
      </section><!--class="sidebar"-->
      <!-- /.sidebar -->
    </aside>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!--/////Awal Render///////-->
      <?php $this->rendersection('content'); ?>
      <!--///////Akhir Render//////-->
    </div>
    <!-- /.content-wrapper -->


    <!-- /.content-wrapper -->
    <footer class="main-footer">
      <strong>Copyright &copy; 2023 <a href="#">PT. Quantum HRMI </a>All rights reserved.
    </footer>


  </div>
  <!-- ./wrapper -->


  <!-- jQuery 3 -->
  <script src="../../bower_components/jquery/dist/jquery.min.js"></script>
  <!-- Bootstrap 3.3.7 -->
  <script src="../../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <!-- DataTables -->
  <script src="../../bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="../../bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
  <!-- SlimScroll -->
  <script src="../../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
  <!-- FastClick -->
  <script src="../../bower_components/fastclick/lib/fastclick.js"></script>
  <!-- AdminLTE App -->
  <script src="../../dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../../dist/js/demo.js"></script>
  <!-- page script -->
  <script>
    $(function() {
      $('#example1').DataTable()
      $('#example2').DataTable({
        'paging': true,
        'lengthChange': false,
        'searching': false,
        'ordering': true,
        'info': false,
        'autoWidth': false
      })
    })
  </script>

  <!-- Bootstrap------------------------------------------------------------------------------------------------------------->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  <!-- Bootstrap------------------------------------------------------------------------------------------------------------->
  <?= $this->rendersection('scripts'); ?>
</body>

</html>