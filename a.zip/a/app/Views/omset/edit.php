<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>


<style type="text/css">
    .displaynone {
        display: none;
    }

    .currSign:before {
        content: 'Rp. ';
    }
</style>
<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Data Omset</h2>


                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">


                        <div class="panel-body">

                            <?php if (session('sukses-tambah-omset')) :  ?>
                                <div class="alert alert-info" role="alert">
                                    <?= session('sukses-tambah-omset');
                                    ?>
                                </div>
                            <?php endif; ?>


                            <form action="<?=route_to('/omset/edit/',$omset['id'])?>" method="post">
                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Kode</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['kode']; ?>" readonly name="kode">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Pekerjaan</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['pekerjaan']; ?>" name="pekerjaan">

                                    </div>
                                </div>



                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Instansi</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['instansi']; ?>" name="instansi">
                                    </div>
                                </div>


                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label" style="width: 280px;">Jenis</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['jenis']; ?>" name="jenis">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label" style="width: 280px;">No. kontrak</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['no_kontrak']; ?>" name="no_kontrak">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label" style="width: 280px;">Nilai kontrak</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['nilai']; ?>" name="nilai">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label" style="width: 280px;">Mulai</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['mulai']; ?>" name="mulai">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label" style="width: 280px;">Selesai</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['selesai']; ?>" name="selesai">
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <a href="/omset" class="btn btn-primary m-2" style="height: 35px; width: 90px">
                                        <i class="fa-solid fa-circle-left"></i></i>Kembali</a>
                                    <button type="submit" class="btn btn-success" id="save">Simpan</button>
                                </div>
                            </form>
                            <div class="form-group" id="process" style="display:none">
                                <div class="progress">
                                    <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->


<?= $this->endsection(); ?>