<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>


<style type="text/css">
    .displaynone {
        display: none;
    }

    .currSign:before {
        content: 'Rp. ';
    }
</style>
<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Data Omset</h2>


                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">


                        <div class="panel-body">

                            <?php if (session('sukses-tambah-omset')) :  ?>
                                <div class="alert alert-info" role="alert">
                                    <?= session('sukses-tambah-omset');
                                    ?>
                                </div>
                            <?php endif; ?>


                            <form action="" method="post">
                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Kode</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['kode']; ?>" readonly>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Pekerjaan</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['pekerjaan']; ?>" readonly>

                                    </div>
                                </div>



                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Instansi</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['instansi']; ?>" readonly>
                                    </div>
                                </div>


                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label" style="width: 280px;">Jenis</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['jenis']; ?>" readonly>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label" style="width: 280px;">No. kontrak</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['no_kontrak']; ?>" readonly>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label" style="width: 280px;">Nilai kontrak</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['nilai']; ?>" readonly>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label" style="width: 280px;">Mulai</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['mulai']; ?>" readonly>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label" style="width: 280px;">Selesai</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" value="<?= $omset['selesai']; ?>" readonly>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <a href="/omset" class="btn btn-primary m-2" style="height: 35px; width: 90px">
                                        <i class="fa-solid fa-circle-left"></i></i>Kembali</a>
                                    <button type="submit" class="btn btn-success" id="save">Simpan</button>
                                </div>
                            </form>
                            <div class="form-group" id="process" style="display:none">
                                <div class="progress">
                                    <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->


<?= $this->endsection(); ?>