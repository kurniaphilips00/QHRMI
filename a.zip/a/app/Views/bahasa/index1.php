<?= $this->extend('layout/dashboard-layout'); ?>
<?= $this->section('content'); ?>

<head>
    <!--    
        Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
        Perlu penyesuaian versi bootstrap dari 3.4.1 ke 5.1.3
    -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="sweetalert2.min.css">
</head>

<style>
    .corner1 {
        border-radius: 10px;
        color: blue;
        width: 600px;
        height: 40px;
    }

    /*https://stackoverflow.com/questions/47789667/table-cells-as-a-password-type*/
    .hidetext {
        -webkit-text-security: disc;
        /* Default */
    }
</style>

<body>
    <div class="container">
        <center>
            <h1 style="font-weight: bold; font-family: Georgia" ;>Daftar Bahasa</h1>
        </center>

        <button class="btn btn-success" onclick="add_bahasa()"><i class="glyphicon glyphicon-plus"></i>Tambah</button>
        <br><br>
        <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>ID</th>
                    <th>Kode TA</th>
                    <th>Nama Tenaga Ahli</th>
                    <th>Bhs Indonesia</th>

                    <th style="width: 200px;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $n = 0;
                foreach ($bhs as $bahasa) {
                    $n++;
                ?>
                    <tr>
                        <td><?php echo $n; ?></td>
                        <td><?php echo $bahasa['id_bahasa']; ?></td>
                        <td><?php echo $bahasa['kode_ta']; ?></td>
                        <td id="namanya"><?php echo $bahasa['nama_ta']; ?></td>
                        <td><?php echo $bahasa['nilai_bhs_indo']; ?></td>

                        <td>
                            <button class="btn btn-info" onclick="baca(<?php echo $bahasa['id_bahasa']; ?>)">Baca</button>
                            <button class="btn btn-warning" onclick="edit_bahasa(<?php echo $bahasa['id_bahasa']; ?>)">Edit</button>
                            <button class="btn btn-danger" onclick="delete_bahasa(<?php echo $bahasa['id_bahasa']; ?>)">Delete</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="sweetalert2.all.min.js"></script>
    <!--
    Diambil dari : https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/
    Perlu penyesuaian versi bootstrap dari 3.4.1 ke 5.1.3 (di atas)
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    -->

    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
        var save_method; //for save method string
        var table;

        function add_bahasa() {
            save_method = 'add';
            $('#form')[0].reset(); // reset form on modals
            $('#modal_form').modal('show'); // show bootstrap modal
            $('.modal-title').text('Tambah Data Bahasa'); // Set Title to Bootstrap modal title
            $('#input_Nama_Tenaga_Ahli1').show();     
            $('#Expert_Name_Div').show();      
            $('#input_Nama_Tenaga_Ahli2').hide();
            $('#Expert_Name_Div2').hide();
        }

        function baca(id) { //  Membaca data per ID
            $('#form')[0].reset(); // reset form on modals
            <?php header('Content-type: application/json'); ?>

            $.ajax({
                url: "/ajax_baca_bahasa/" + id,
                type: "GET",
                dataType: "JSON",

                success: function(data) {
                    console.log(data);
                    $('[name="id_bahasa"]').val(data.id_bahasa);
                    $('[name="nama_ta"]').val(data.nama_ta);
                    $('[name="nilai_bhs_indo"]').val(data.nilai_bhs_indo);
                    $('[name="nilai_bhs_setempat"]').val(data.nilai_bhs_setempat);
                    $('[name="nilai_bhs_inggris"]').val(data.nilai_bhs_inggris);

                    $("#pilihanTA").hide();
                    $("#namaTA").hide();
                    $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                    $('.modal-title').text('Baca Data Bahasa'); // Set title to Bootstrap modal title
                },
                complete: function() {
                    $("button#btnSave").css("display", "none");
                    
                    $("button#btnTutup").css("background-color", "green");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR);
                    alert('Error baca data memakai ajax');
                }
            });
        }

        function edit_bahasa(id) {
            save_method = 'update';
            //   alert(id);
            $('#form')[0].reset(); // reset form on modals
            <?php header('Content-type: application/json'); ?>
            //Ajax Load data from ajax
            $.ajax({
                url: "/ajax_edit_bahasa/" + id,
                type: "GET",
                dataType: "JSON",
                success: function(data) {
                   // console.log(data);
                    $('[name="id_bahasa"]').val(data.id_bahasa);
                    $('[name="nama_ta"]').val(data.nama_ta);
                    $('[name="nilai_bhs_indo"]').val(data.nilai_bhs_indo);
                    $('[name="nilai_bhs_setempat"]').val(data.nilai_bhs_setempat);
                    $('[name="nilai_bhs_inggris"]').val(data.nilai_bhs_inggris);
                    $('#namaTA').hide(); 
                    $('#pilihanTA').hide();
                 //   $('#Nama_Tenaga_Ahli').attr('disabled');
                    $('#input_Nama_Tenaga_Ahli1').hide();     
                    $('#Expert_Name_Div').hide();      
                    $('#input_Nama_Tenaga_Ahli2').show();
                    $('#Expert_Name_Div2').show();

                    $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                    $('.modal-title').text('Edit Data'); // Set title to Bootstrap modal title
                    $("#btnSave").css("display", "true");
                    $("#btnSave").css("background-color", "green");
                },
                complete: function() {
                    $("button#btnSave").show();
                    $("button#btnSave").css("background-color", "green");
                    $("button#btnTutup").css("background-color", "red");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR);
                    alert('Error edit data memakai ajax');
                }
            });
        }

        function save() {
            var url;
            if (save_method == 'add') {
                url = "/ajax_bahasa_add";
                judulSweet = 'Tambah';
            } else {
                url = "/ajax_update_bahasa";
                judulSweet = 'Update';
            }
            $.ajax({
                url: url,
                type: "POST",
                data: $('#form').serialize(),
                dataType: "JSON",
                success: function(data) {
                    //if success close modal and reload ajax table
                    $('#modal_form').modal('hide');
                    location.reload(); // for reload a page
                    //  Tampilkan komentar Sweet Alert
                    Swal.fire(
                        judulSweet,
                        data.status,
                        'success'
                    );
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert('Error tambah / update data');
                }
            });
        }

        function delete_bahasa(id) {
            namanya = $('#namanya').val();
            //  alert(namanya);
            Swal.fire({
                title: 'Apakah anda yakin menghapus data dengan id = ' + id,
                text: "Anda tidak bisa membatalkan !",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, hapus !'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "/ajax_delete_bahasa/" + id,
                        type: "POST",
                        dataType: "JSON",
                        success: function(data) {
                            location.reload();
                            //  Tampilkan komentar Sweet Alert
                            Swal.fire(
                                'Terhapus !',
                                data.status,
                                'success'
                            )
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            console.log(jqXHR);
                            alert('Error hapus data memakai ajax');
                        }
                    });
                }
            })
        }
    </script>

    <!-- Modal -->
    <div class="modal" id="modal_form" data-bs-backdrop="false" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="false">
        <div class="modal-dialog" style="width: 1100px;">
            <div class="modal-content">
                <div class="modal-header">

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">x</button>
                </div>

                <center>
                    <h1 class="modal-title" style="font-weight: bold; font-family: Georgia" ;>Judul</h1>
                </center>
                <div class="modal-body">
                    <form action="#" id="form" class="form-horizontal">
                        <input type="hidden" name="id_bahasa" />
                        <div class="form-body">
                        
                            <br>
                            <div class="form-group">
                                <label class="control-label col-sm-3" id="Nama_Tenaga_Ahli">Nama Tenaga Ahli</label>

                                <div class="col-sm-4" id="Expert_Name_Div">
                                    <input name="nama_ta" class="form-control" id="input_Nama_Tenaga_Ahli1" style="width: 700px;" type="text">
                                </div>

                                <div class="col-sm-4" id="Expert_Name_Div2">
                                    <input name="nama_ta" class="form-control" id="input_Nama_Tenaga_Ahli2" 
                                    style="width: 700px;" disabled="disabled" type="text">
                                </div>
                                

                                <input name="kode_ta" class="form-control" id="kode_Tenaga_Ahli" type="hidden">
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Nilai Bahasa Indonesia</label>
                                <input name="nilai_bhs_indo" class="form-control" style="width: 700px;"  type="text">
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Nilai Bahasa Inggris</label>
                                <input name="nilai_bhs_inggris" class="form-control" style="width: 700px;"  type="text">
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3">Nilai Bahasa Setempat</label>
                                <input name="nilai_bhs_setempat" class="form-control" style="width: 700px;"  type="text">
                            </div>

                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" id="btnTutup" class="btn btn-danger" data-bs-dismiss="modal">Tutup</button>
                    <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </div>
    </div>
    <script>
    function autocomplete(inp, arr) {
        /*the autocomplete function takes two arguments,
        the text field element and an array of possible autocompleted values:*/
        var currentFocus;
        /*execute a function when someone writes in the text field:*/
        inp.addEventListener("input", function(e) {
            var a, b, i, val = this.value;
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!val) {
                return false;
            }
            currentFocus = -1;
            /*create a DIV element that will contain the items (values):*/
            a = document.createElement("DIV");
            a.setAttribute("id", this.id + "autocomplete-list");
            a.setAttribute("class", "autocomplete-items");
            /*append the DIV element as a child of the autocomplete container:*/
            this.parentNode.appendChild(a);
            /*for each item in the array...*/
            for (i = 0; i < arr.length; i++) {
                /*check if the item starts with the same letters as the text field value:*/
                if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                    /*create a DIV element for each matching element:*/
                    b = document.createElement("DIV");
                    /*make the matching letters bold:*/
                    b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                    b.innerHTML += arr[i].substr(val.length);
                    /*insert a input field that will hold the current array item's value:*/
                    b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                    /*execute a function when someone clicks on the item value (DIV element):*/
                    b.addEventListener("click", function(e) {
                        /*insert the value for the autocomplete text field:*/
                        inp.value = this.getElementsByTagName("input")[0].value;
                        /*close the list of autocompleted values,
                        (or any other open lists of autocompleted values:*/
                        closeAllLists();
                    });
                    a.appendChild(b);
                }
            }
        });
        /*execute a function presses a key on the keyboard:*/
        inp.addEventListener("keydown", function(e) {
            var x = document.getElementById(this.id + "autocomplete-list");
            if (x) x = x.getElementsByTagName("div");
            if (e.keyCode == 40) {
                /*If the arrow DOWN key is pressed,
                increase the currentFocus variable:*/
                currentFocus++;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 38) { //up
                /*If the arrow UP key is pressed,
                decrease the currentFocus variable:*/
                currentFocus--;
                /*and and make the current item more visible:*/
                addActive(x);
            } else if (e.keyCode == 13) {
                /*If the ENTER key is pressed, prevent the form from being submitted,*/
                e.preventDefault();
                if (currentFocus > -1) {
                    /*and simulate a click on the "active" item:*/
                    if (x) x[currentFocus].click();
                }
            }
        });

        function addActive(x) {
            /*a function to classify an item as "active":*/
            if (!x) return false;
            /*start by removing the "active" class on all items:*/
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = (x.length - 1);
            /*add class "autocomplete-active":*/
            x[currentFocus].classList.add("autocomplete-active");
        }

        function removeActive(x) {
            /*a function to remove the "active" class from all autocomplete items:*/
            for (var i = 0; i < x.length; i++) {
                x[i].classList.remove("autocomplete-active");
            }
        }

        function closeAllLists(elmnt) {
            /*close all autocomplete lists in the document,
            except the one passed as an argument:*/
            var x = document.getElementsByClassName("autocomplete-items");
            for (var i = 0; i < x.length; i++) {
                if (elmnt != x[i] && elmnt != inp) {
                    x[i].parentNode.removeChild(x[i]);
                }
            }
        }
        /*execute a function when someone clicks in the document:*/
        document.addEventListener("click", function(e) {
            closeAllLists(e.target);
        });
    }
    
  
    var nama = <?php echo json_encode($nama); ?>;
    var kode = <?php echo json_encode($kode); ?>;
    autocomplete(document.getElementById("input_Nama_Tenaga_Ahli1"), nama);
    //  Mengisi kode tenaga ahli dari drop down
    function isi_kode_TA() {
        const ta = document.getElementById("TA").value; //Ini id dari drop down/ fungsi onclick
        let index = nama.indexOf(ta);
        document.getElementById("Kode_Tenaga_Ahli").value = kode[index];
    }
    //  Mengisi kode tenaga ahli dari ketikan
    function isikodeTA() {
        const ta = document.getElementById("Tenaga_Ahli").value; //Ini id dari drop down/ fungsi onclick
        let index = nama.indexOf(ta);
        document.getElementById("Kode_Tenaga_Ahli").value = kode[index];
    }
</script>
</body>
<script>
    //  Mengisi kode tenaga ahli dari ketikan
    function isi_kode_TA() {
        var nama = <?php echo json_encode($nama); ?>;
        var kode = <?php echo json_encode($kode); ?>;
        const ta = document.getElementById("pilihanTA").value; //Ini id dari drop down/ fungsi onclick
        let index = nama.indexOf(ta);
        document.getElementById("kode_Tenaga_Ahli").value = kode[index];
       // alert(document.getElementById("kode_Tenaga_Ahli").value);
    }
</script>
<?= $this->endsection(); ?>