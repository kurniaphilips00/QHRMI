<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Welcome to PT. Quantum HRMI</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="../img/logo.jpg" />

    <!-- CodeIgniter v4.3.6. (February 24, 2020)-->
    <!--
       
    
    Modal(view baca), ...
    
    edit(upload image ajax : DCodeMania) -> tenaga ahli, proyek, pengalaman non q
    omset(grafik),
    input proyek baru, bisa langsung input tenaga ahli(lebih dari satu) tersimpan ke dalam tabel pengalaman
    Datatable server side, sweet alert, login (password), ...
    CRUD proyek, 
    SOP (content) 
    JQuery, JSON
    Backup (hard disk)
    -->


    <style>
        .bkg {
            background-image: url('../img/q.jpg');
        }
    </style>
</head>

<body class="bkg">
    <p><a href="login" style="color: white;">Login</a></p>
    <!--<p><a href="home/dashboard" style="color: white;">Login</a></p>-->
</body>

</html>