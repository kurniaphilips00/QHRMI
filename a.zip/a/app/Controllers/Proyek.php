<?php

namespace App\Controllers;

use App\Models\rhModel;
use App\Controllers\BaseController;
use App\Models\posisiModel;
use App\Models\proyekModel;
use App\Models\InstansiModel;
use App\Models\ModelPengalaman;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

class Proyek extends BaseController
{
  protected $rhModel;
  protected $posisiModel;
  protected $proyekModel;
  protected $ModelPengalaman;

  protected $base;
  public function __construct()
  {

    $rh = $this->rhModel = new rhModel();
    $posisi = $this->posisiModel = new posisiModel();
    $expert = $this->ModelPengalaman = new ModelPengalaman();
    $proyek = $this->proyekModel = new proyekModel();
  }

  public function index()
  {
    if (session()->get('id')) {
      $proyek = $this->proyekModel->getProyek();
      $rh = $this->rhModel->getCV();
      $data = [
        'judul' => 'Daftar Proyek',
        'rh' => $rh,
        'proyek' => $proyek    //      Proyek diambilkan dari tabel proyek
      ];
      // dd($data);
      return view('/proyek/index', $data);
    } else
      return redirect()->to('/');
  }

  ///////////Tambah proyek//////////////////////////
  public function tambah_exp()
  {
    if (session()->get('id')) {

      $instansi = new InstansiModel();
      $pengguna = $instansi->getInstansi(); // Untuk memilih Tenaga Ahli urut berdasarkan ID

      $n = 0;
      foreach ($pengguna as $val) {
        $nama_instansi[$n] = $val['nama_instansi'];
        $kode_instansi[$n] = $val['kode_instansi'];
        $n++;
      }

      helper('custom_helper'); // Loading single helper
      $ta = $this->rhModel->getCVwithKode();
      $proyek = $this->proyekModel->getProyekOrderByKode();

      $kode = CheckProyek($proyek);   //  Menghitung nomor kode
      if ($kode == null) {
        $kode = hitungKode('tb_proyek');
      }
      $posisi = $this->posisiModel->getPosisi();

      $data = [
        'judul' => 'Tambah Data Proyek',
        'ta' => $ta, // Untuk memilih nama dan mengambil id dari Tenaga Ahli
        'posisi' => $posisi,  //  Untuk menentukan posisi tenaga ahli
        'proyek' => $proyek,  //  Proyek diambilkan dari tabel proyek
        'kode' => $kode,
        'kode_instansi' => $kode_instansi,
        'nama_instansi' => $nama_instansi,
        'validation' => \Config\Services::validation()
      ];
      return view('proyek/tambah', $data);
    } else
      return redirect()->to('/');
  }

  ///////////  Menyimpan data proyek & upload file referensi memakai ajax /////////////////////////
  public function simpan()
  {
    helper(['form', 'url']);
    $nilai = $this->request->getVar('nilai');
    $nilai = str_replace('.', '', $nilai);
    $nilai = str_replace(',00', '', $nilai);
    $nilai = str_replace('Rp', '', $nilai);

    $database = \Config\Database::connect();
    $builder = $database->table('tb_proyek');
    $validateImage = $this->validate([
      'file' => [
        'uploaded[file]',
        'mime_in[file, image/png, image/jpg,image/jpeg, image/gif]',
        'max_size[file, 4096]',
      ],
    ]);

    $response = [
      'success' => false,
      'data' => '',
      'msg' => "Data tidak tersimpan"
    ];

    $imageFile = $this->request->getFile('file');
    if ($imageFile != '' && !$imageFile->hasMoved()) {
      $kode = $this->request->getVar('kode_proyek');
      $newName = $imageFile->getName();
      $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
      $imageFile->move($PATH . '/ref');
      $lokasi = "public_html/ref/" . $newName;
      //Ini untuk local
      //$imageFile->move(WRITEPATH . '../public/ref/', $newName);//   Pindah file ke direktori penyimpanan
      //$lokasi = "public/ref/".$newName;
      $data = [
        'kode_proyek' => $this->request->getVar('kode_proyek'),
        'kode_instansi' => $this->request->getVar('kode_instansi'),
        'instansi' => $this->request->getVar('instansi'),
        'pekerjaan' => $this->request->getVar('pekerjaan'),
        'lokasi' => $this->request->getVar('lokasi'),
        'alamat' => $this->request->getVar('alamat'),
        'nokontrak' => $this->request->getVar('nokontrak'),
        'mulai' => $this->request->getVar('mulai'),
        'selesai' => $this->request->getVar('selesai'),
        'tahun' => $this->request->getVar('tahun'),
        'nilai' => $nilai,
        'jml_bln' => $this->request->getVar('jml_bln'),
        'inter' => $this->request->getVar('inter'),
        'referensi' => $this->request->getVar('referensi'), //  Ini nomor referensi
        'surat_referensi' => $newName,        //  Ini nama file referensi
        'lokasi_surat_referensi' => $lokasi   //  Ini lokasi file referensi
      ];
      $save = $builder->insert($data);
      $response = [
        'success' => true,
        'data' => $save,
        'msg' => "Data tersimpan,...file pdf berhasil di-upload"
      ];
    } else {
      $kode = $this->request->getVar('kode_proyek');
      $data = [
        'kode_proyek' => $this->request->getVar('kode_proyek'),
        'kode_instansi' => $this->request->getVar('kode_instansi'),
        'instansi' => $this->request->getVar('instansi'),
        'pekerjaan' => $this->request->getVar('pekerjaan'),
        'lokasi' => $this->request->getVar('lokasi'),
        'alamat' => $this->request->getVar('alamat'),
        'nokontrak' => $this->request->getVar('nokontrak'),
        'mulai' => $this->request->getVar('mulai'),
        'selesai' => $this->request->getVar('selesai'),
        'tahun' => $this->request->getVar('tahun'),
        'nilai' => $this->request->getVar('nilai'),
        'jml_bln' => $this->request->getVar('jml_bln'),
        'inter' => $this->request->getVar('inter')
      ];
      $save = $builder->insert($data);
      $response = [
        'success' => true,
        'data' => $save,
        'msg' => "Data tersimpan,...file pdf tidak ter-upload"
      ];
    }
    return $this->response->setJSON($response);
  }

  public function saveta()
  {
   // dd($this->request->getVar('prjcode'));
    $prjcode = $this->request->getVar('prjcode');
    if (isset($_GET['PilihTA'])) {  //  Jika tombol dengan name="PilihTA" diklik
      if (!empty($this->request->getVar('ckval1'))) { //  Jika ada checkbox dengan name="ckval1[]" dipilih
        //  https://stackoverflow.com/questions/64996555/insert-multiple-dimension-array-codeigniter
        $val1 = $this->request->getVar('ckval1');
        $val2 = $this->request->getVar('ckval2');
        $brs = 0;   //  baris (record)
        foreach ($val1 as $br) {
          $kode_posisi = $val2[$brs]; //  val2 = array yang berisi kode posisi
          $posisi = $this->posisiModel->CariKodePosisi($kode_posisi);
          $posisitugas = '';
          if ($posisi != '' and $posisi != null) {
            $posisitugas = $posisi['posisitugas'];
          }
          helper('custom_helper');
          $expert = $this->ModelPengalaman->getExperts();
          $kode = CheckPengalaman($expert);   //  Menghitung nomor kode pengalaman untuk mengisi pengalaman baru
          if ($kode == null) {
            $kode = hitungKode('tb_pengalaman');
          }
          $namata = $this->rhModel->where('kode_ta', $br)->first();
          $nama_ta = $namata['nama'];
        //  $kode_proyek = $this->request->getVar('kode_proyek');
         
          $proyek = $this->proyekModel->where('kode_proyek', $prjcode)->first();
         // dd($proyek);
          if ($proyek == null) {
            return redirect()->to(base_url('proyek/tambah'))->with('gagal-tambah-TA', 'Proyek yang dicari tidak ada, gagal menambah tenaga ahli...');
          }
          $pekerjaan = $proyek['pekerjaan'];
          $instansi = $proyek['instansi'];
          $this->ModelPengalaman->save([
            'kode_pengalaman' => $kode,
            'kode_proyek' => $prjcode,
            'nama_pekerjaan' => $pekerjaan,
            'nama_instansi' => $instansi,
            'kode_ta' => $br,
            'nama_ta' => $nama_ta,
            'kode_posisi' => $kode_posisi,
            'posisitugas' => $posisitugas
          ]);
          $brs++;
        }
        return redirect()->to(base_url('proyek/tambah'))->with('sukses-tambah-TA', 'Tenaga ahli berhasil ditambah...');
      }
    }
  }

  public function edit_exp($id)
  {
    if (session()->get('id')) {
      $posisi = $this->posisiModel->getPosisi();
      $proyek = $this->proyekModel->getProyek($id);  //  Proyek diambilkan dari tabel proyek
      // dd($proyek);
      $ta = $this->rhModel->getCV(); // Untuk memilih nama dan mengambil id Tenaga Ahli
      $data = [
        'ta' => $ta,
        'judul' => 'Edit Data Proyek',
        'proyek' => $proyek,   //  Proyek diambilkan dari tabel proyek
        'posisi' => $posisi,
        'validation' => \Config\Services::validation()
      ];
      // dd($proyek);
      return view('proyek/edit', $data);
    } else
      return redirect()->to('/');
  }


  ///////////  Menyimpan data proyek & upload file referensi memakai ajax /////////////////////////
  public function updproyek()
  {
    helper(['form', 'url']);
    $database = \Config\Database::connect();
    $builder = $database->table('tb_proyek');
    $validateImage = $this->validate([
      'file' => [
        'uploaded[file]',
        'mime_in[file, image/png, image/jpg,image/jpeg, image/gif]',
        'max_size[file, 4096]',
      ],
    ]);

    $response = [
      'success' => false,
      'data' => '',
      'msg' => "Data tidak tersimpan"
    ];

    if ($this->request->getFile('file') == null) {
      if ($this->request->getVar('nilai') != null) {
        $nilai = $this->request->getVar('nilai');
        $nilai = str_replace('.', '', $nilai);
        $nilai = str_replace(',00', '', $nilai);
        $nilai = str_replace('Rp', '', $nilai);
      } else
        $nilai = 0;
      //  if ($imageFile->getError() === 4) {      //      Jika tidak ada file yang di-upload

      //  Simpan data-data record saja (tanpa file)
      $data = [
        // 'id' => $id,
        'kode_proyek' => $this->request->getVar('kode_proyek'),
        'kode_instansi' => $this->request->getVar('kode_instansi'),
        'instansi' => $this->request->getVar('instansi'),
        'pekerjaan' => $this->request->getVar('pekerjaan'),
        'lokasi' => $this->request->getVar('lokasi'),
        'alamat' => $this->request->getVar('alamat'),
        'nokontrak' => $this->request->getVar('nokontrak'),
        'mulai' => $this->request->getVar('mulai'),
        'selesai' => $this->request->getVar('selesai'),
        'tahun' => $this->request->getVar('tahun'),
        'nilai' => $nilai,
        'jml_bln' => $this->request->getVar('jml_bln'),
        'inter' => $this->request->getVar('inter')
        
      ];
      $save = $builder->update($data);
      $response = [
        'success' => true,
        'data' => $save,
        'msg' => "Data tersimpan,...file pdf tidak di-upload"
      ];
      // }
    } else { //      Jika ada file yang di-upload
      $id = $this->request->getPost('id');  //  Ambil id untuk update
      if ($this->request->getVar('nilai') != null) {
        $nilai = $this->request->getVar('nilai');
        $nilai = str_replace('.', '', $nilai);
        $nilai = str_replace(',00', '', $nilai);
        $nilai = str_replace('Rp', '', $nilai);
      } else
        $nilai = 0;
      $imageFile = $this->request->getFile('file');
      $oldFile = $this->request->getVar('lokasi_surat_referensi');
      $oldFile = substr($oldFile, 12);
      unlink($oldFile);
      $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
      $imageFile->move($PATH . '/ref');
      $newName = $imageFile->getName();
      $lokasi = "public_html/ref/" . $newName;
      $data = [
        //  'id' => $id,
        'kode_proyek' => $this->request->getVar('kode_proyek'),
        'kode_instansi' => $this->request->getVar('kode_instansi'),
        'instansi' => $this->request->getVar('instansi'),
        'pekerjaan' => $this->request->getVar('pekerjaan'),
        'lokasi' => $this->request->getVar('lokasi'),
        'alamat' => $this->request->getVar('alamat'),
        'nokontrak' => $this->request->getVar('nokontrak'),
        'mulai' => $this->request->getVar('mulai'),
        'selesai' => $this->request->getVar('selesai'),
        'tahun' => $this->request->getVar('tahun'),
        'nilai' => $nilai,
        'jml_bln' => $this->request->getVar('jml_bln'),
        'inter' => $this->request->getVar('inter'),
        
        'referensi' => $this->request->getVar('referensi'), //  Ini nomor referensi
        'surat_referensi' => $newName,        //  Ini nama file referensi
        'lokasi_surat_referensi' => $lokasi   //  Ini lokasi file referensi
      ];
      //  Update data di sini !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      //  Dari dCodemania : https://dcodemania.com/post/crud-app-codeigniter-bootstrap-jquery-ajax
      $save = $builder->update($id, $data);
      $response = [
        'success' => true,
        'data' => $save,
        'msg' => "Data tersimpan,...file pdf berhasil di-upload"
      ];
    }
    return $this->response->setJSON($response);
  }

  public function update_exp($id)
  {
    $file = $this->request->getFile('file');
    if ($file != '' && !$file->hasMoved()) {
      $newName = $file->getName();
      $lokasi = "public_html/ref/" . $newName;
      if (is_file($lokasi)) {
        $this->proyekModel->save([  /////////UPDATE//////////////////////////////////
          'id' => $id,  // Jika memakai id berarti diasumsikan update
          'pekerjaan' => $this->request->getVar('pekerjaan'),
          'tahun' => $this->request->getVar('tahun'),
          'lokasi' => $this->request->getVar('lokasi'),
          'instansi' => $this->request->getVar('instansi'),
          'alamat' => $this->request->getVar('alamat'),
          'nokontrak' => $this->request->getVar('nokontrak'),
          'nilai' => $this->request->getVar('nilai'),
          'referensi' => $this->request->getVar('referensi'), //  Nomor referensi
          'mulai' => $this->request->getVar('mulai'),
          'selesai' => $this->request->getVar('selesai'),
          'jml_bln' => $this->request->getVar('jml_bln'),
          'inter' => $this->request->getVar('inter')
        ]);
      } else {
        $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
        $file->move($PATH . '/ref');

        $this->proyekModel->save([  /////////UPDATE//////////////////////////////////
          'id' => $id,

          'pekerjaan' => $this->request->getVar('pekerjaan'),

          'tahun' => $this->request->getVar('tahun'),
          'lokasi' => $this->request->getVar('lokasi'),
          'instansi' => $this->request->getVar('instansi'),
          'alamat' => $this->request->getVar('alamat'),
          'nokontrak' => $this->request->getVar('nokontrak'),
          'nilai' => $this->request->getVar('nilai'),
          'referensi' => $this->request->getVar('referensi'), //  Nomor referensi
          'mulai' => $this->request->getVar('mulai'),
          'selesai' => $this->request->getVar('selesai'),
          'jml_bln' => $this->request->getVar('jml_bln'),
          'inter' => $this->request->getVar('inter'),
          'surat_referensi' => $newName,  //  File referensi
          'lokasi_surat_referensi' => $lokasi
        ]);
      }
    }
    return redirect()->to(base_url('/proyek'))->with('sukses-edit', 'Data berhasil diupdate');
  }

  public function delete($id)
  {
    $Proyek = $this->proyekModel->getProyek($id);
    //  Hapus file lama jika ada
    $lokasi_surat_referensi = isset($Proyek['lokasi_surat_referensi']) ? $Proyek['lokasi_surat_referensi'] : '';
    if ($lokasi_surat_referensi != '') {
      $oldFile = substr($lokasi_surat_referensi, 12);
      if (file_exists($oldFile)) {
        unlink($oldFile);
      }
    }
    $this->proyekModel->delete($id);
    //  session()->setFlashdata('success','Data berhasil dihapus');
    return redirect()->to(base_url('/proyek'))->with('sukses-hapus', 'Data berhasil dihapus, jangan lupa menghapus data pengalaman tenaga ahli');
  }
  public function delete_all_projects()
  {
      //dd($_GET['HapusProyek']);
      if (isset($_GET['HapusProyek'])) {  //  Jika tombol dengan name="HapusPengalaman" diklik
          //  https://stackoverflow.com/questions/64996555/insert-multiple-dimension-array-codeigniter
        //  dd($this->request->getVar('ckdel'));
          if (!empty($this->request->getVar('ckdel'))) {  //  Jika ada checkbox dengan name="ckdel[]" dipilih
              $hapus = $this->request->getVar('ckdel');
             // dd($hapus);
              foreach ($hapus as $br) {
                  $this->proyekModel->delete($br);
              }
          }
      }
      session()->setFlashdata('delete-all-success', 'Semua data proyek yang dicentang berhasil dihapus');
      return redirect()->to('proyek/');
  }
  public function baca($id)
  {
    if (session()->get('id')) {
      $proyek = $this->proyekModel->getProyek($id);
      $data = [
        'judul' => 'Baca Data Proyek',
        'result' => $proyek,
      ];
      return view('proyek/baca', $data);
    } else
      return redirect()->to('/');
  }

  public function importExcel()
  { //importExcel
    $spreadsheet = new Spreadsheet();
    //  Ambil file dari name (input type="file".... name="excel".....) di dalam index.php
    $file = $this->request->getFile('excel');
    $ext = $file->getExtension();

    if ($ext === "xls" || $ext === "xlsx") {
      $this->proyekModel->kosongkan();
      if ($ext === "xls") $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();    //  Jika ekstensinya xls
      else $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx(); //  Jika ekstensinya xlsx
      $spread = $reader->load($file); //   Muat ke reader, tampung ke variabel $spread
      $sheet = $spread->getActiveSheet()->toArray(); //    Membaca sheet aktif dan menampung ke array
      foreach ($sheet as $index => $item) {
        if ($index == 0) continue; // Baris ke 0 berisi header(judul), bukan data, jadi diabaikan

        if ($item[0] == "" && $item[1] == "" && $item[2] == "" && $item[3] == "") {
          break;
        }
        if ($item[8] != "" && $item[9] != "") {
          //  Memanggil fungsi dari Base.php untuk menghitung intermitten
          $this->base = new Base();
          $inter = $this->base->hitung_intermitten($item[8], $item[9]);
          //dd($inter);
          $jml_bln = $this->base->hitung_bulan($item[8], $item[9]);
        } else {
          $inter = "";
          $jml_bln = 0;
        }

        $data =
          [

            'kode_proyek' => $item[0],    //      kolom A
            'kode_instansi' => $item[1],  //      kolom B
            'instansi' => $item[2],       //      kolom C
            'pekerjaan' => $item[3],      //      kolom D
            'tahun' => $item[4],          //      kolom E
            'lokasi' => $item[5],         //      kolom F
            'alamat' => $item[6],         //      kolom G
            'nokontrak' => $item[7],      //      kolom H
            'mulai' => $item[8],          //      kolom I
            'selesai' => $item[9],        //      kolom J
            'nilai' => $item[10],         //      kolom K
            'referensi' => $item[11],     //      kolom L
            'jml_bln' => $item[12],        //      kolom M
            'inter' => $item[13],            //      kolom N
            'refpdf' => $item[14]         //      kolom O                      
          ];

        $this->proyekModel->insert($data);  // mulai baris 1 dan seterusnya

      }
      session()->setFlashdata('import', 'Data berhasil di-impor');
    } else {
      session()->setFlashdata('error', 'Bukan format file excel');
    }
    return redirect()->to(base_url('/proyek'));
  }


  public function ExportToExcel()
  {
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    //      Baris pertama berisi judul
    $sheet->setCellValue('A1', 'Kode');
    $sheet->setCellValue('B1', 'Instansi');
    $sheet->setCellValue('C1', 'Pekerjaan');
    $sheet->setCellValue('D1', 'Tahun');
    $sheet->setCellValue('E1', 'Lokasi');
    $sheet->setCellValue('F1', 'Alamat');
    $sheet->setCellValue('G1', 'No. Kontrak');
    $sheet->setCellValue('H1', 'Mulai');
    $sheet->setCellValue('I1', 'Selesai');
    $sheet->setCellValue('J1', 'Nilai');
    $sheet->setCellValue('K1', 'Referensi');
    $sheet->setCellValue('L1', 'Jml bulan');
    $sheet->setCellValue('M1', 'Intermitten');
    $sheet->setCellValue('N1', 'File pdf referensi');


    $row = 2;   // row 1 dipakai untuk header (judul-judul kolom di atas)
    $proyek = $this->proyekModel->getProyekOrderByKode();
    foreach ($proyek as $v => $item) {
      $sheet->setCellValue('A' . $row, $item['kode_proyek'])
        ->setCellValue('B' . $row, $item['instansi'])
        ->setCellValue('C' . $row, $item['pekerjaan'])
        ->setCellValue('D' . $row, $item['tahun'])
        ->setCellValue('E' . $row, $item['lokasi'])
        ->setCellValue('F' . $row, $item['alamat'])
        ->setCellValue('G' . $row, $item['nokontrak'])
        ->setCellValue('H' . $row, $item['mulai'])
        ->setCellValue('I' . $row, $item['selesai'])
        ->setCellValue('J' . $row, $item['nilai'])
        ->setCellValue('K' . $row, $item['referensi'])
        ->setCellValue('L' . $row, $item['jml_bln'])
        ->setCellValue('M' . $row, $item['inter'])
        ->setCellValue('N' . $row, $item['refpdf']);

      $row++;
    }

    $filename = "proyek";
    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename=' . $filename . '.xlsx');
    header('Cache-Control: max-age=0');
    $writer->save('php://output');
  }


  public function kosong()
  { //Mengosongkan tabel
    $this->proyekModel->kosongkan();
    return redirect()->to(base_url('/proyek'));
  }
}
