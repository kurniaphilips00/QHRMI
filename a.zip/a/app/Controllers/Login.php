<?php
namespace app\Controllers;

use App\Controllers\BaseController;

class Login extends BaseController {
//  Urutan : login > routes > filter > controller
    public function index() {
        $usrModel = new \App\Models\usrModel();
        $login = $this->request->getPost('login');
        if ($login) {
        
            $username = $this->request->getVar('username');            
            $password = $this->request->getVar('password');
            $err = '';
            //Jika nama user dan password kosong
            if ($username == '' or $password == '') {
                $err = "Silahkan memasukkan username dan password";
            }
            $dataMember = [];
            if (empty($err))  { 
                $dataMember = $usrModel -> where('username', $username)->first();
                if ($dataMember) {
                    //if ($dataMember = ['password'] != md5($password)) {
                    if ($dataMember['password'] != $password) {
                        $err = "Nama user benar, tetapi password salah";
                    }
                }
                else {
                    $password = $usrModel -> where('password', $password)->first();
                    if ($password) {
                        $err = "Nama user salah, tetapi password benar";
                    }
                    else
                        $err = "Nama user dan password salah";
                }
            }
            if (empty($err))  {    
                $dataSesi = [
                    'id' => $dataMember['id'],
                    'username' => $dataMember['username']
                ];
                session()->set($dataSesi);
                return redirect()->to('home/dashboard');
                //return redirect()->to('usr');
            }
            if ($err) {
                
                //  Menampilkan pesan error pada view
                session()->setFlashdata('error', $err);
                return redirect()->to('login');
            }
        }
        return view('login_view');
    }
    public function logout() {
        session()->destroy();
        return redirect()->to('/');
    }
}
?>