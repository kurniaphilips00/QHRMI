<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Controllers\Base;
use App\Models\rhModel;
use App\Models\posisiModel;
use App\Models\bhsModel;
use App\Models\sertModel;
use App\Models\proyekTAModel;
use App\Models\ModelPengalaman;
use Dompdf\Dompdf;
use Dompdf\Options;
use Dompdf\FontMetrics;
use PDO;

class Imt extends BaseController
{
    protected $rhModel;
    protected $posisiModel;
    protected $bhsModel;
    protected $sertModel;
    protected $base;
    protected $proyekTAModel;
    protected $ModelPengalaman;

    public function __construct()
    {
        $rh = $this->rhModel = new rhModel();
        $ModelPengalaman = $this->ModelPengalaman = new ModelPengalaman();
    }
    public function index()
    {
        if (session()->get('id')) {
            $ta = $this->rhModel->getCVwithKode();
            $data = ['ta' => $ta, 'judul' => 'Intermitten Tenaga Ahli'];
            return view('imt/index', $data);
        }
        else
            return redirect()->to('/');
    }

    /*  Mencetak semua intermitten ( detil & total ) yang terpilih pada check box memekai file HTML    */
    public function intermitten_detil()
    {
        if (isset($_GET['intmt'])) {
            if (!empty($this->request->getVar('ckval'))) {
                $check = $this->request->getVar('ckval');
               // dd($check);
                $pengalaman = array();
                $n = 0;
                //  Untuk semua tenaga ahli
                foreach ($check as $brs) {
                   // $result = $this->rhModel->getCVwithKode($brs);
                    // Cari detil pengalaman untuk tenaga ahli ke n
                    $pengalaman[$n] = $this->ModelPengalaman->getPengalaman($brs);
                    $n++;
                }
                if (count($pengalaman[0]) > 0) {
                    $data = ['pengalaman' => $pengalaman];
                    return view('imt/intermitten', $data);
                }
                else {
                    $check = implode("",$check);
                    return redirect()->to(base_url('/imt'))->with('belum-berpengalaman', 'Belum ada pengalaman dari tenaga ahli '.$check); 
                }
                
            } 
            
            else //Jika tidak ada tenaga ahli yang dipilih 
            {
                echo '<script type="text/javascript">';
                echo ' alert("Pilih minimal satu kotak check box")';  //not showing an alert box.
                echo '</script>';
                return redirect()->to(base_url('/imt'))->with('gagal-semua-intermitten', 'Pilih minimal satu kotak check box');
            }
        }
    }
 
}
