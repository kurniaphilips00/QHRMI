<?php

namespace App\Controllers;
use App\Models\proyekModel;
class Home extends BaseController
{
    protected $rhModel;
    protected $proyekModel;
    public function __construct()
    {
        $prj = $this->proyekModel = new proyekModel();
    }
    public function index()
    {
       return view('welcome_message');
    }
    public function dashboard() {
        //  User tidak boleh masuk ke http://localhost:8080/index.php/home/dashboard tanpa login (mengetik url di Google)
        //  https://stackoverflow.com/questions/4473042/how-to-prevent-entering-to-the-site-using-url-typing-in-codeigniter
        if (session()->get('id')) {
            $proyek = $this->proyekModel->getProyek();
            return view('dashboard/dashb', ['proyek' => $proyek]);
        }
        else
            return redirect()->to('/');
    }
    public function help()
    {
        return view('dashboard/help');  
    }
}
