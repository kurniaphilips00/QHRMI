<?php

namespace App\Controllers;

use App\Models\rhModel;
use App\Controllers\BaseController;
use App\Models\posisiModel;
use App\Models\expNonQModel;
use App\Models\InstansiModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

class ExpNonQ extends BaseController
{
    protected $rhModel;
    protected $expNonQModel;
    protected $posisiModel;
    protected $InstansiModel;

    public function __construct()
    {

        $rh = $this->rhModel = new rhModel();
        $expNonQ = $this->expNonQModel = new expNonQModel();
        $posisi = $this->posisiModel = new posisiModel();
        $instansi = $this->InstansiModel = new InstansiModel();
    }

    public function index()
    {
        if (session()->get('id')) {
            $expNonQ = $this->expNonQModel->getPengalamanNonQ();
            $data = [
                'judul' => 'Data Pengalaman Non Quantum',
                'expNonQ' => $expNonQ
            ];
            return view('/ExpNonQ/index', $data);
        } else
            return redirect()->to('/');
    }

    public function tambah()
    {
        if (session()->get('id')) {
            helper('custom_helper');

            //  Menghitung nomor kode
            $expNonQ = $this->expNonQModel->getPengalamanNonQ();
            $kode = CheckPengalamanNonQ($expNonQ);
            if ($kode == null) {
                $kode = hitungKode('tb_proyek_nq');
            }
            // Untuk memilih Posisi dan uraian tugas
            $posisi = $this->posisiModel->getPosisiByKode();
            $n = 0;
            foreach ($posisi as $val) {
                $kode_posisi[$n] = $val['kode_posisi'];
                $posisitugas[$n] = $val['posisitugas'];
                $uraiantugas[$n] = $val['uraiantugas'];
                $n++;
            }

            // Untuk memilih instansi
            $instansi = $this->InstansiModel->getInstansi();
            $n = 0;
            foreach ($instansi as $val) {
                $kode_instansi[$n] = $val['kode_instansi'];
                $nama_instansi[$n] = $val['nama_instansi'];
                $n++;
            }

            $ta = $this->rhModel->getCV();
            $n = 0;
            foreach ($ta as $val) {
                $namata[$n] = $val['nama'];
                $kodeta[$n] = $val['kode_ta'];
                $n++;
            }

            $data = [
                'judul' => 'Tambah Pengalaman Non Quantum',
                'ta' => $ta,
                'kode_pengalaman' => $kode,
                'exp' => $expNonQ,
                'nama' => $namata,
                'kode' => $kodeta,
                'kode_posisi' => $kode_posisi,
                'posisitugas' => $posisitugas,
                'uraiantugas' => $uraiantugas,
                'kode_instansi' => $kode_instansi,
                'nama_instansi' => $nama_instansi,
                'validation' => \Config\Services::validation()
            ];
            return view('/ExpNonQ/add', $data);
        } else
            return redirect()->to('/');
    }


    ///////////  Menyimpan hasil tambah pengalaman memakai ajax /////////////////////////
    public function uploadrefexpnonq()
    {
        helper(['form', 'url']);

        $database = \Config\Database::connect();
        $builder = $database->table('tb_proyek_nq');
        $validateImage = $this->validate([
            'file' => [
                'uploaded[file]',
                'mime_in[file, image/png, image/jpg,image/jpeg, image/gif]',
                'max_size[file, 4096]',
            ],
        ]);

        $response = [
            'success' => false,
            'data' => '',
            'msg' => "Data tidak tersimpan"
        ];

        $pdf_File = $this->request->getFile('file');
        if ($pdf_File != '' && !$pdf_File->hasMoved()) {      //  Ada file yang di upload

            $newName = $pdf_File->getName();

            $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
            $pdf_File->move($PATH . '/ref');
            $lokasi = "public_html/ref/" . $newName;
            //Ini untuk local
            //$pdf_File->move(WRITEPATH . '../public/ref/', $newName);//   Pindah file ke direktori penyimpanan
            //$lokasi = "public/ref/".$newName;

            $data = [
                'kode_pengalaman' => $this->request->getVar('kode_pengalaman'),
                'kode_posisi' => $this->request->getVar('kode_posisi'),
                'kode_instansi' => $this->request->getVar('kode_instansi'),
                'nama_instansi' => $this->request->getVar('nama_instansi'),
                'nama_perusahaan' => $this->request->getVar('nama_perusahaan'),
                'kode_ta' => $this->request->getVar('kode_ta'),
                'nama_ta' => $this->request->getVar('nama_ta'),
                'pekerjaan' => $this->request->getVar('pekerjaan'),
                'lokasi' => $this->request->getVar('lokasi'),
                'alamat' => $this->request->getVar('alamat'),
                'nokontrak' => $this->request->getVar('nokontrak'),
                'mulai' => $this->request->getVar('mulai'),
                'selesai' => $this->request->getVar('selesai'),
                'tahun' => $this->request->getVar('tahun'),
                'nilai' => $this->request->getVar('nilai'),
                'jml_bln' => $this->request->getVar('jml_bln'),
                'inter' => $this->request->getVar('inter'),
                'status_kepegawaian' => $this->request->getVar('status_kepegawaian'),
                'surat_referensi' => $newName,
                'lokasi_surat_referensi' => $lokasi
            ];

            $save = $builder->insert($data);
            $response = [
                'success' => true,
                'data' => $save,
                'msg' => "Data tersimpan,...file image berhasil di-upload"
            ];
        } else {    //  TIDAK ADA file yang di upload
            $data = [
                'kode_pengalaman' => $this->request->getVar('kode_pengalaman'),
                'kode_posisi' => $this->request->getVar('kode_posisi'),
                'kode_instansi' => $this->request->getVar('kode_instansi'),
                'nama_instansi' => $this->request->getVar('nama_instansi'),
                'nama_perusahaan' => $this->request->getVar('nama_perusahaan'),
                'kode_ta' => $this->request->getVar('kode_ta'),
                'nama_ta' => $this->request->getVar('nama_ta'),
                'pekerjaan' => $this->request->getVar('pekerjaan'),
                'lokasi' => $this->request->getVar('lokasi'),
                'alamat' => $this->request->getVar('alamat'),
                'nokontrak' => $this->request->getVar('nokontrak'),
                'mulai' => $this->request->getVar('mulai'),
                'selesai' => $this->request->getVar('selesai'),
                'tahun' => $this->request->getVar('tahun'),
                'nilai' => $this->request->getVar('nilai'),
                'jml_bln' => $this->request->getVar('jml_bln'),
                'inter' => $this->request->getVar('inter'),
                'status_kepegawaian' => $this->request->getVar('status_kepegawaian')
            ];
            $save = $builder->insert($data);
            $response = [
                'success' => true,
                'data' => $save,
                'msg' => "Data tersimpan,... tidak ada file image yang di-upload"
            ];
        }
        return $this->response->setJSON($response);
    }

    
    public function edit_nq($id) {
        if (session()->get('id')) {
            $expNonQ = $this->expNonQModel->CariIDPengalaman($id);
            
            
            // Untuk memilih Posisi dan uraian tugas
            $posisi = $this->posisiModel->getPosisiByKode();
            //  Ini untuk menampilkan field posisitugas dari tenaga ahli (tidak ada di tabel)
            $kodeposisi = $expNonQ['kode_posisi']; 
            $posisinya = $this->posisiModel->getPosisiByKode($kodeposisi);
            $nama_posisi_nya = $posisinya['posisitugas'];
            //  dd($posisi);
            $n = 0;
            foreach ($posisi as $val) {
                $kode_posisi[$n] = $val['kode_posisi'];
                $posisitugas[$n] = $val['posisitugas'];
                //$uraiantugas[$n] = $val['uraiantugas'];
                $n++;
            }
            // Untuk memilih instansi
            $instansi = $this->InstansiModel->getInstansi();
         //   dd($instansi);
            $n = 0;
            foreach ($instansi as $val) {
                $kode_instansi[$n] = $val['kode_instansi'];
                $nama_instansi[$n] = $val['nama_instansi'];
                $n++;
            }
            $data = [
                'judul' => 'Edit Pengalaman Tenaga Ahli',
                'expNonQ' => $expNonQ,
                
                'kode_posisi' => $kode_posisi,
                'posisitugas' => $posisitugas,
                'nama_posisi_nya' => $nama_posisi_nya,      
                'kode_instansi' => $kode_instansi,
                'nama_instansi' => $nama_instansi,
                
            ];
            return view('/ExpNonQ/edit', $data);
        } else
            return redirect()->to('/');
    } 
//  Update pengalaman non quantum memakai ajax
    public function updatenonq_with_ajax()
    {
        helper(['form', 'url']);     
        $response = [
            'success' => false,
            'data' => '',
            'msg' => "Data tidak tersimpan"
        ];
        $model = new expNonQModel();
        $id = $this->request->getPost('id');
        $pdf_File = $this->request->getFile('file');
        if ($pdf_File != '' && !$pdf_File->hasMoved()) {
            //  Jika ada file yang di-upload (name="file")  
            //  Dihapus dulu baru kemudian di-update, jangan di-update dulu kemudian dihapus...>>>>  kesalahan logika !!!
            //  Hapus file referensi lama, jika ada
            $Arr = $model->getNonQExp($id);  //  Ambil array field-fieldnya
            $oldFile = isset($Arr['lokasi_surat_referensi']) ? $Arr['lokasi_surat_referensi'] : '';   //  Ambil field lokasi file 
            if ($oldFile != '') {   //  Periksa apakah file lama masih ada
                $oldFile = substr($oldFile, 12);
                if (file_exists($oldFile)) {
                    unlink($oldFile);       //  Hapus file referensi lama
                }
            }
            $newName = $pdf_File->getName();
            $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
            $pdf_File->move($PATH . '/ref');
            $lokasi = "public_html/ref/" . $newName;
            $data = [
                'kode_pengalaman' => $this->request->getVar('kode_pengalaman'),
                'nama_perusahaan' => $this->request->getVar('nama_perusahaan'),
                'kode_ta' => $this->request->getVar('kode_ta'),
                
                'kode_posisi' => $this->request->getVar('kode_posisi'),
                'kode_instansi' => $this->request->getVar('kode_instansi'),
                'nama_instansi' => $this->request->getVar('nama_instansi'),
                
                'nama_ta' => $this->request->getVar('nama_ta'),
                'pekerjaan' => $this->request->getVar('pekerjaan'),
                'lokasi' => $this->request->getVar('lokasi'),
                'alamat' => $this->request->getVar('alamat'),
                'nokontrak' => $this->request->getVar('nokontrak'),
                'mulai' => $this->request->getVar('mulai'),
                'selesai' => $this->request->getVar('selesai'),
                'tahun' => $this->request->getVar('tahun'),
                'nilai' => $this->request->getVar('nilai'),
                'jml_bln' => $this->request->getVar('jml_bln'),
                'inter' => $this->request->getVar('inter'),
                'status_kepegawaian' => $this->request->getVar('status_kepegawaian'),
                'surat_referensi' => $newName,
                'lokasi_surat_referensi' => $lokasi
            ];
            $model->update_pengalaman_non_q(array('id' => $this->request->getPost('id')), $data);
            $response = [
                'success' => true,
                'data' => $model,
                'msg' => "Data tersimpan,...file berhasil di-upload",
            ];
        } else {   //  Tidak ada file yang di-upload
            $data = [
                'kode_pengalaman' => $this->request->getVar('kode_pengalaman'),
                'kode_ta' => $this->request->getVar('kode_ta'),
                'nama_ta' => $this->request->getVar('nama_ta'),
                
                'kode_posisi' => $this->request->getVar('kode_posisi'),
                'kode_instansi' => $this->request->getVar('kode_instansi'),
                'nama_instansi' => $this->request->getVar('nama_instansi'),
                'nama_perusahaan' => $this->request->getVar('nama_perusahaan'),
              
                'pekerjaan' => $this->request->getVar('pekerjaan'),
                'lokasi' => $this->request->getVar('lokasi'),
                'alamat' => $this->request->getVar('alamat'),
                'nokontrak' => $this->request->getVar('nokontrak'),
                'mulai' => $this->request->getVar('mulai'),
                'selesai' => $this->request->getVar('selesai'),
                'tahun' => $this->request->getVar('tahun'),
                'nilai' => $this->request->getVar('nilai'),
                'jml_bln' => $this->request->getVar('jml_bln'),
                'inter' => $this->request->getVar('inter'),
                'status_kepegawaian' => $this->request->getVar('status_kepegawaian')
            ];
            $model = new expNonQModel();
            
            $model->update_pengalaman_non_q(array('id' => $this->request->getPost('id')), $data);
            $response = [
                'success' => true,
                'data' => $model,
                'msg' => "Data tersimpan,...tidak ada file yang di-upload"
            ];
        }
        return $this->response->setJSON($response);
    }

    public function ajak()
    {
        $param['draw'] = isset($_REQUEST['draw']) ? $_REQUEST['draw'] : '';
        $key = isset($_REQUEST['search']['value']) ? $_REQUEST['search']['value'] : '';
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : '';
        $length = isset($_REQUEST['length']) ? $_REQUEST['length'] : '';
        $expNonQ = $this->expNonQModel = new expNonQModel();
    }
    public function baca($kode)
    {
        if (session()->get('id')) {
            $exp = $this->expNonQModel->getPengalamanNonQ($kode);
            $kode_posisi = $exp['kode_posisi'];
            // Untuk memilih Posisi dan uraian tugas
            $posisi = $this->posisiModel->getPosisiByKode($kode_posisi);
            $posisitugas = $posisi['posisitugas'];
            $uraiantugas = $posisi['uraiantugas'];

            //  $uraiantugas = $pengalaman[$n]['uraiantugas'];
            $uraiantugas = str_replace("&lt;ol&gt;", "<ol>", $uraiantugas);
            $uraiantugas = str_replace("&lt;/ol&gt;", "</ol>", $uraiantugas);
            $uraiantugas = str_replace("&lt;li&gt;", "<li>", $uraiantugas);
            $uraiantugas = str_replace("&lt;/li&gt;", "</li>", $uraiantugas);
            $uraiantugas = str_replace("&amp;nbsp;", "", $uraiantugas);
            //dd($uraiantugas);
            $data = [
                'judul' => 'Baca Data Tenaga Ahli',
                'expNonQ' => $exp,
                'posisitugas' => $posisitugas,
                //   '$kode_posisi' => $kode_posisi,
                'validation' => \Config\Services::validation()
            ];
            return view('/ExpNonQ/read', $data);
        } else
            return redirect()->to('/');
    }

    public function edit($id)
    {
        if (session()->get('id')) {
            $expNonQ = $this->expNonQModel->CariIDPengalaman($id);
            
            //    dd($id);
            $taName = $this->rhModel->getTAOrderByName(); // Untuk memilih Tenaga Ahli urut berdasarkan nama
            $n = 0;
            foreach ($taName as $val) {
                $namata[$n] = $val['nama'];
                $kodeta[$n] = $val['kode_ta'];
                $n++;
            }
            
            
            // Untuk memilih Posisi dan uraian tugas
            $posisi = $this->posisiModel->getPosisiByKode();
            //  Ini untuk menampilkan field posisitugas dari tenaga ahli (tidak ada di tabel)
            $kodeposisi = $expNonQ['kode_posisi']; 
            $posisinya = $this->posisiModel->getPosisiByKode($kodeposisi);
            $nama_posisi_nya = $posisinya['posisitugas'];
            //  dd($posisi);
            $n = 0;
            foreach ($posisi as $val) {
                $kode_posisi[$n] = $val['kode_posisi'];
                $posisitugas[$n] = $val['posisitugas'];
                //$uraiantugas[$n] = $val['uraiantugas'];
                $n++;
            }
            // Untuk memilih instansi
            $instansi = $this->InstansiModel->getInstansi();
            $n = 0;
            foreach ($instansi as $val) {
                $kode_instansi[$n] = $val['kode_instansi'];
                $nama_instansi[$n] = $val['nama_instansi'];
                $n++;
            }
            $data = [
                'judul' => 'Edit Pengalaman Tenaga Ahli',
                'expNonQ' => $expNonQ,
                'nama' => $namata,
                'kode' => $kodeta,
                'kode_posisi' => $kode_posisi,
                'posisitugas' => $posisitugas,
                'nama_posisi_nya' => $nama_posisi_nya,      
                'kode_instansi' => $kode_instansi,
                'nama_instansi' => $nama_instansi,
                'validation' => \Config\Services::validation()
            ];
            return view('/ExpNonQ/edit', $data);
        } else
            return redirect()->to('/');
    }

    public function update($id)
    {
        $this->expNonQModel->save([
            'id' => $id,
            'kode_pengalaman' => $this->request->getVar('kode_pengalaman'),
            'kode_posisi' => $this->request->getVar('kode_posisi'),
            'kode_instansi' => $this->request->getVar('kode_instansi'),
            'nama_instansi' => $this->request->getVar('nama_instansi'),
            'nama_perusahaan' => $this->request->getVar('nama_perusahaan'),
            'kode_ta' => $this->request->getVar('kode_ta'),
            'nama_ta' => $this->request->getVar('nama_ta'),
            'pekerjaan' => $this->request->getVar('pekerjaan'),
            'lokasi' => $this->request->getVar('lokasi'),
            'alamat' => $this->request->getVar('alamat'),
            'nokontrak' => $this->request->getVar('nokontrak'),
            'mulai' => $this->request->getVar('mulai'),
            'selesai' => $this->request->getVar('selesai'),
            'tahun' => $this->request->getVar('tahun'),
            'nilai' => $this->request->getVar('nilai'),
            'jml_bln' => $this->request->getVar('jml_bln'),
            'inter' => $this->request->getVar('inter'),
            'status_kepegawaian' => $this->request->getVar('status_kepegawaian'),
        ]);
        //--pasangannya di admin/exp/index.php, karena kalau berhasil langsung kembali ke route /pengalaman (admin/exp/index.php)   
        session()->setFlashdata('sukses-update-pengalaman', 'Data Pengalaman Tenaga Ahli berhasil diupdate');
        return redirect()->to('experiences');
    }
    public function delete($id)
    {
        $PengalamanNonQ = $this->expNonQModel->CariIDPengalaman($id);
        //  Hapus file lama jika ada
        $lokasi_surat_referensi = isset($PengalamanNonQ['lokasi_surat_referensi']) ? $PengalamanNonQ['lokasi_surat_referensi'] : '';
        if ($lokasi_surat_referensi != '') {
            $oldFile = substr($lokasi_surat_referensi, 12);
            if (file_exists($oldFile)) {
                unlink($oldFile);
            }
        }
        $this->expNonQModel->delete($id);
        session()->setFlashdata('success-delete', 'Data berhasil dihapus');
        return redirect()->to('/experiences');
    }

    public function imporDariExcel()
    {   //    importExcel
        $spreadsheet = new Spreadsheet();
        $file = $this->request->getFile('excel');

        $ext = $file->getExtension();

        if ($ext === "xls" || $ext === "xlsx") {

            if ($ext === "xls") $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();    //  Jika ekstensinya xls
            else $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx(); //  Jika ekstensinya xlsx
            $spread = $reader->load($file);                             //   Muat ke reader, tampung ke variabel $spread
            $sheet = $spread->getActiveSheet()->toArray();              //    Membaca sheet aktif dan menampung ke array
            
            foreach ($sheet as $index => $item) {
                if ($index == 0) continue; // Baris ke 0 berisi header(judul), bukan data, jadi diabaikan
                //  Jika baris x semua kolom 0 hingga 3 kosong berhenti
                if ($item[0] == "" && $item[1] == "" && $item[2] == "" && $item[3] == "") {
                    break;
                }
                //  Jika baris x berisi data > impor
                if ($item[0] != "" && $item[1] != "" && $item[2] != "" && $item[3] != "") {
                    $data =
                        [   //  ID otomatis bertambah, tidak perlu impor
                            'kode_instansi' => $item[0],        //      kolom A
                            'kode_pengalaman' => $item[1],      //      kolom B
                            'kode_posisi' => $item[2],
                            'kode_ta' => $item[3],
                            'nama_ta' => $item[4],
                            'pekerjaan' => $item[5],
                            'lokasi' => $item[6],
                            'alamat' => $item[7],
                            'nokontrak' => $item[8],
                            'nama_instansi' => $item[9],
                            'nama_perusahaan' => $item[10],
                            'nilai' => $item[11],
                            'jml_bln' => $item[12],
                            'tahun' => $item[13],
                            'mulai' => $item[14],
                            'selesai' => $item[15],
                            'inter' => $item[16],
                            'status_kepegawaian' => $item[17],
                            'surat_referensi' => $item[18],
                            'lokasi_surat_referensi' => $item[19]
                        ];
                    $this->expNonQModel->insert($data);  // mulai baris 1 dan seterusnya 
                }
            }
            session()->setFlashdata('imported', 'Data berhasil di-impor ');
        } else {
            if ($ext == "") {
                session()->setFlashdata('kosong', 'Belum ada file yang dipilih (kosong)');
            }
            else {
                session()->setFlashdata('format_error', 'Bukan format file excel');
            }
            
        }
        return redirect()->to(base_url('/experiences'));
    }

    public function exporKeExcel()
    {

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
//      Urutannya harus sesuai tabel tb_proyek_nq di dalam database...!!!
        $sheet->setCellValue('A1', 'Kode instansi');
        $sheet->setCellValue('B1', 'Kode Pengalaman');
        $sheet->setCellValue('C1', 'Kode Posisi');
        $sheet->setCellValue('D1', 'Kode Tenaga Ahli');
        $sheet->setCellValue('E1', 'Nama Tenaga Ahli');
        $sheet->setCellValue('F1', 'Pekerjaan');
        $sheet->setCellValue('G1', 'Lokasi');
        $sheet->setCellValue('H1', 'Alamat');
        $sheet->setCellValue('I1', 'No Kontrak');
        $sheet->setCellValue('J1', 'Nama Instansi');
        $sheet->setCellValue('K1', 'Nama Perusahaan');
        $sheet->setCellValue('L1', 'Nilai');
        $sheet->setCellValue('M1', 'Jml bulan ');
        $sheet->setCellValue('N1', 'Tahun');
        $sheet->setCellValue('O1', 'Mulai');
        $sheet->setCellValue('P1', 'Selesai');
        $sheet->setCellValue('Q1', 'Intermitten');
        $sheet->setCellValue('R1', 'Status Kepegawaian');
        $sheet->setCellValue('S1', 'Surat Referensi');
        $sheet->setCellValue('T1', 'Lokasi Surat Referensi');


        $row = 2;   // row 1 dipakai untuk header (judul-judul kolom di atas)
        $exp = $this->expNonQModel->getPengalamanNonQ();
        foreach ($exp as $v => $item) {
            $sheet  //      Urutannya harus sesuai tabel tb_proyek_nq di dalam database...!!!
//            setCellValue('A' . $row, $item['kode_proyek'])
                ->setCellValue('A' . $row, $item['kode_instansi'])
                ->setCellValue('B' . $row, $item['kode_pengalaman'])
                ->setCellValue('C' . $row, $item['kode_posisi'])
                ->setCellValue('D' . $row, $item['kode_ta'])
                ->setCellValue('E' . $row, $item['nama_ta'])
                ->setCellValue('F' . $row, $item['pekerjaan'])
                ->setCellValue('G' . $row, $item['lokasi'])
                ->setCellValue('H' . $row, $item['alamat'])
                ->setCellValue('I' . $row, $item['nokontrak'])
                ->setCellValue('J' . $row, $item['nama_instansi'])
                ->setCellValue('K' . $row, $item['nama_perusahaan'])
                ->setCellValue('L' . $row, $item['nilai'])
                ->setCellValue('M' . $row, $item['jml_bln'])
                ->setCellValue('N' . $row, $item['tahun'])
                ->setCellValue('O' . $row, $item['mulai'])
                ->setCellValue('P' . $row, $item['selesai'])
                ->setCellValue('Q' . $row, $item['inter'])
                ->setCellValue('R' . $row, $item['status_kepegawaian'])
                ->setCellValue('S' . $row, $item['surat_referensi'])
                ->setCellValue('T' . $row, $item['lokasi_surat_referensi']);
                
            $row++;
        }

        $filename = "PengalamanNonQuantum";
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename=' . $filename . '.xlsx');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
    }

    public function kosong()
    {
        $this->expNonQModel->kosongkan();
        return redirect()->to('/experiences');
    }
}
