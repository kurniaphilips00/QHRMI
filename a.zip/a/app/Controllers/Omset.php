<?php

namespace App\Controllers;
use App\Models\ModelOmset;
use App\Models\ModelOmsetBln;
use App\Controllers\BaseController;

class Omset extends BaseController
{
   
    protected $ModelOmset; 
    protected $ModelOmsetBln;
    public function __construct()
    {
        $OmsetBln = $this->ModelOmsetBln = new ModelOmsetBln();
        $Omset = $this->ModelOmset = new ModelOmset();   
    }
    
    public function index() {
            $Omset = $this->ModelOmset->getOmsetOrderByKode();
            $data = ['Omset' => $Omset, 'judul' => 'Omset PT. Quantum HRMI'];      
        return view ('omset/index', $data);
    }

    public function tambah()
      {       
        helper('custom_helper'); 
        $Omset = $this->ModelOmset->getOmsetOrderByKode();
        //  Periksa apakah ada nomor yang terlompati (bolong)
        if (checkSkip($Omset,'tb_omset') == null) {
          //    Jika tidak ada, maka nomor urut diambil dari jumlah record
            $kode = hitungKode('tb_omset');
        }
        //    Jika ada, maka nomor urut diambil dari record yang terlompati
        else {
            $kode = checkSkip($Omset, 'tb_omset');
        }

        $Omset = $this->ModelOmset->getOmsetOrderByKode();
       
          $data = [ 
              'judul' => 'Tambah Data Omset',   
            
              'Omset' => $Omset,  //  Pengalaman diambilkan dari tabel Omset
              'kode' => $kode,
           
              'validation' => \Config\Services::validation()
          ];  
          return view('omset/add', $data);
    }
      
      ///////////  Menyimpan hasil tambah pengalaman/////////////////////////
    public function simpan()
      {           
             $rules = $this->validate([
       
            'instansi'    => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Instansi harus diisi.',
                ],
            ],
            'pekerjaan'      => [
                'rules'  => 'required',
                'errors' => [
                    'required' => 'Pekerjaan harus diisi.',
                ],
            ]
        ]);
        if (!$rules) 
           {    //--pasangannya di tambah_exp.php 
            session()->setFlashdata('gagal-menambah-omset','Tambah data omset gagal !!!');
            return redirect()->back()->withInput();
          } 
 
          $this->ModelOmset->save([
            // id_exp tidak perlu disimpan karena autoincrement, otomatis di-update,
              'kode' => $this->request->getVar('kode'),
              'pekerjaan' => $this->request->getVar('pekerjaan'),
              'jenis' => $this->request->getVar('jenis'),
              'instansi' => $this->request->getVar('instansi'),
              'no_kontrak' => $this->request->getVar('no_kontrak'),
              'nilai' => $this->request->getVar('nilai'),
              'mulai' => $this->request->getVar('mulai'),
              'selesai' => $this->request->getVar('selesai')
          ]);    
 
         return redirect()->to(base_url('omset'))->with('sukses-tambah-omset', 'Data berhasil disimpan');
      }
         
    public function edit($id) {
        $omset = $this->ModelOmset->getOmsetByID($id);
        $data = [
            'judul' => 'Edit Data Omset',
            'omset' => $omset
        ];
        return view('omset/edit', $data);
    }
      
    public function update($id) {
        $this->ModelOmset->save([  
            'id' => $id,
            'pekerjaan' => $this->request->getVar('pekerjaan'),
            'jenis' => $this->request->getVar('jenis'),
            'instansi' => $this->request->getVar('instansi'),
            'no_kontrak' => $this->request->getVar('no_kontrak'),
            'nilai' => $this->request->getVar('nilai'),
            'mulai' => $this->request->getVar('mulai'),
            'selesai' => $this->request->getVar('selesai')
            
        ]);
        return redirect()->to(base_url('/omset'))->with('sukses-update-omset', 'Omset berhasil diupdate');
    }
 
    public function delete($id) {
       // dd($id);
        $this->ModelOmset->delete($id);
        session()->setFlashdata('del-success','Data omset berhasil dihapus');
        return redirect()->to(base_url('/omset'));
    }

    public function baca($kode)
    {
        $omset = $this->ModelOmset->getOmsetByKode($kode);
        $data = [
            'omset' => $omset,
            'judul' => 'Baca Data Omset'
        ];
        return view('omset/baca', $data);
    }

    public function rekap() {
        $Omset = $this->ModelOmset->getOmsetOrderByKode();
        
        $no = 0;
        foreach ($Omset as $v) {
          $no++;
          $selesai = isset($v['selesai']) ? $v['selesai'] : '';
         // dd($v);
          if ($selesai != '') {
                $year = date("Y",strtotime($selesai));  
                $month = date("n",strtotime($selesai));
                $omsbln = $this->ModelOmsetBln->getNilaiOnMonth(intval($month));
              //  dd($omsbln[0]['id']);
                $this->ModelOmsetBln->save([  
                    'id' => $omsbln[0]['id'],
                    'tahun' => intval($year),
                    'nilai' => $v['nilai']
                ]);
          }  
        }
        return redirect()->to(base_url('/omset'));
    }
 }
