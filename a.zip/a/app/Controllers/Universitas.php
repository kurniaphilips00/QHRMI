<?php

namespace App\Controllers;
use App\Models\ModelUniversitas;
use App\Controllers\BaseController;

class Universitas extends BaseController
{
    protected $ModelUniversitas;
    public function __construct()
    {
        $universitas = $this->ModelUniversitas = new ModelUniversitas();
    }

    public function index()
    {
        if (session()->get('id')) {
            $universitas = $this->ModelUniversitas->getUniversitas();
            $data = ['universitas' => $universitas, 'judul' => 'Data Universitas',];
            return view('/universitas/index1', $data);
        } else
            return redirect()->to('/');
    }
    public function baca($id)
    {
        $model = new ModelUniversitas();
        $data = $model->getUniversitas($id);
        echo json_encode($data);
    }

    public function simpan()
    {
        $data = [
            'universitas' => $this->request->getPost('universitas'),
        ];
        $model = new ModelUniversitas();
        $model->save($data);
        return $this->response->setJSON([
            'status' => 'Sukses tambah data !'
        ]);
    }
    public function update()
    {    
        $id = $this->request->getPost('id');
        helper(['form', 'url']);
        $data = [
            'universitas' => $this->request->getPost('universitas')
        ];
        $model = new ModelUniversitas();
        $model->update_universitas(array('id' => $id), $data);
        return $this->response->setJSON([
            'status' => 'Sukses update data !'
        ]);
    }
    public function edit($id)
    {
        $model = new ModelUniversitas();
        $data = $model->getUniversitas($id);
        echo json_encode($data);
    }
    public function delete($id)
    {
        $model = new ModelUniversitas();
        $model->delete($id);
        return $this->response->setJSON([
            'status' => 'Sukses hapus data !'
        ]);
    }
}
