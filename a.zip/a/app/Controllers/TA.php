<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\rhModel;
use App\Models\posisiModel;
use App\Models\kategoriModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use App\Models\bhsModel;
use App\Models\sertModel;
use App\Models\CityModel;

class TA extends BaseController
{
    protected $rhModel;
    protected $posisiModel;
    protected $kategoriModel;
    protected $proyekTAModel;
    protected $bhsModel;
    protected $sertModel;
    protected $base;
    protected $CityModel;

    public function __construct()
    {
        $rh = $this->rhModel = new rhModel();
        $posisi = $this->posisiModel = new posisiModel();
        $kategori = $this->kategoriModel = new kategoriModel();
        $bhs = $this->bhsModel = new bhsModel();
        $sertifikat = $this->sertModel = new sertModel();
        $city = $this->CityModel = new CityModel;

    }

    public function index(
        $S1 = null,
        $S2 = null,
        $S3 = null,
        $pos = null,
        $usia1 = null,
        $OrderBySIPPED = null
    ) {
        //  User tidak boleh masuk ke http://localhost:8080/index.php/home/dashboard tanpa login (mengetik url di Google)
        //  https://stackoverflow.com/questions/4473042/how-to-prevent-entering-to-the-site-using-url-typing-in-codeigniter
        if (session()->get('id')) {
            $data = [];
            if ((int)$OrderBySIPPED == 1) {
                $cv = $this->rhModel->getOrderBySIPP_ED();
                $posisi = $this->posisiModel->getPosisi();
                $data = ['cv' => $cv, 'posisi' => $posisi, 'judul' => 'Tenaga Ahli(filtered)'];
                if ($cv == "") {
                    echo '<script type="text/javascript">';
                    echo ' alert("Data yang dicari tidak ada")';  //not showing an alert box.
                    echo '</script>';
                } else {
                    return view('ta/index', $data);
                }
            }
            if ($usia1 != null) {
                $usia1 = (int)$usia1;
                $usia2 = $usia1 + 10;
                $posisi = $this->posisiModel->getPosisi();
                $cv = $this->rhModel->getFilterUsia($usia1, $usia2);
                $data = ['cv' => $cv, 'posisi' => $posisi, 'judul' => 'Tenaga Ahli (filter usia)'];
                if ($cv == "") {
                    echo '<script type="text/javascript">';
                    echo ' alert("Data yang dicari tidak ada")';  //not showing an alert box.
                    echo '</script>';
                } else {
                    return view('ta/index', $data);
                }
            }
            if ($pos != null) {
                $posisi = $this->posisiModel->getPosisi();
                $cv = $this->rhModel->getFilterPosisi($pos);
                $data = ['cv' => $cv, 'posisi' => $posisi, 'judul' => 'Tenaga Ahli(filtered)'];
                if ($cv == "") {
                    echo '<script type="text/javascript">';
                    echo ' alert("Data yang dicari tidak ada")';  //not showing an alert box.
                    echo '</script>';
                } else {
                    return view('ta/index', $data);
                }
            }
            if ($S1 != null) {
                $cv = $this->rhModel->getFilterPendidikanS1($S1);
                $data = ['cv' => $cv, 'judul' => 'Tenaga Ahli (filter S1)'];
                if ($cv == "") {
                    echo '<script type="text/javascript">';
                    echo ' alert("Data yang dicari tidak ada")';  //not showing an alert box.
                    echo '</script>';
                } else {
                    return view('ta/index', $data);
                }
            }
            if ($S2 != null) {
                $posisi = $this->posisiModel->getPosisi();
                $cv = $this->rhModel->getFilterPendidikanS2($S2);
                $data = ['cv' => $cv, 'posisi' => $posisi, 'judul' => 'Tenaga Ahli (filter S2)'];
                if ($cv == "") {
                    echo '<script type="text/javascript">';
                    echo ' alert("Data yang dicari tidak ada")';  //not showing an alert box.
                    echo '</script>';
                } else {
                    return view('ta/index', $data);
                }
            }
            if ($S3 != null) {
                $posisi = $this->posisiModel->getPosisi();
                $cv = $this->rhModel->getFilterPendidikanS3($S3);
                $data = ['cv' => $cv, 'posisi' => $posisi, 'judul' => 'Tenaga Ahli (filter S3)'];
                if ($cv == "") {
                    echo '<script type="text/javascript">';
                    echo ' alert("Data yang dicari tidak ada")';  //not showing an alert box.
                    echo '</script>';
                } else {
                    return view('ta/index', $data);
                }
            }
            //  Tidak ada pemfilteran
            if ($S1 == null && $S2 == null && $S3 == null && $pos == null && $usia1 == null && $OrderBySIPPED == null) {
                $posisi = $this->posisiModel->getPosisi();
                $cv = $this->rhModel->getCVwithKode();
                //$ckval = array();
                $data = ['cv' => $cv, 'posisi' => $posisi, 'judul' => 'Tenaga Ahli'];
                return view('ta/index', $data);
            }
        } else
            return redirect()->to('/');
    }

    public function sarjana($S1)
    {
        return $this->index($S1, null, null, null, null, null);
    }
    public function master($S2)
    {
        return $this->index(null, $S2, null, null, null, null);
    }
    public function doktor($S3)
    {
        return $this->index(null, null, $S3, null, null, null);
    }

    public function usia($umur)
    {
        return $this->index(null, null, null, null, $umur, null);
    }
    public function posisi($p)
    {
        return $this->index(null, null, null, $p, null, null);
    }

    public function add_ajax_ta()
    {
        helper('custom_helper');
        $model = new rhModel();
        $cv = $model->getTAOrderByKode();
        $kode = CheckTA($cv);   //  Menghitung nomor kode
        if ($kode == null) {
            $kode = hitungKode('tb_ta');
        }

        $ref = $this->request->getFile('file_pdf_referensi');
        if ($ref != '' && !$ref->hasMoved()) {

            $newName = $ref->getName();

            $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
            $ref->move($PATH . '/refTA');
            $lokasi = "public_html/refTA/" . $newName;
            $data = [
                'kode_ta' => $kode,
                'nama' => $this->request->getPost('nama'),
                'file_pdf_referensi' => $newName,
                'lokasi_file_pdf_referensi' => $lokasi,
                'tgl' => $this->request->getPost('tgl')
            ];

            $model->save($data);
            return $this->response->setJSON([
                'status' => 'Sukses tambah data dan upload file  !'
            ]);
        } else {
            $data = [
                'kode_ta' => $kode,
                'nama' => $this->request->getPost('nama'),
                //  'file_pdf_referensi' => $newName,
                // 'lokasi_file_pdf_referensi' => $lokasi,
                'tgl' => $this->request->getPost('tgl')
            ];

            $model->save($data);
            return $this->response->setJSON([
                'status' => 'Sukses tambah data, file tidak ter-upload !'
            ]);
        }
    }

    //  Menambah data dengan refresh
    public function tambah()
    {
        if (session()->get('id')) {
            $kota = $this->CityModel->getCity();
            $n = 0;
            foreach ($kota as $val) {
                $namakota[$n] = $val['kota'];
                
                $n++;
            }
            $cv = $this->rhModel->getTAOrderByKode();
            helper('custom_helper');
            $kode = CheckTA($cv);   //  Menghitung nomor kode
            if ($kode == null) {
                $kode = hitungKode('tb_ta');
            }
            $posisi = $this->posisiModel->getPosisi();
            $kategori = $this->kategoriModel->getKategori();
            $data = [
                'judul' => 'Tambah Data Tenaga Ahli',
                'posisi' => $posisi,
                'kategori' => $kategori,
                'kode' => $kode,
                'namakota' => $namakota,
                'validation' => \Config\Services::validation()
            ];
            return view('ta/add', $data);
        } else
            return redirect()->to('/');
    }
    public function simpan()    //  Menyimpan  data baru
    {

        $npwp = $this->request->getVar('no_npwp1') . "." . $this->request->getVar('no_npwp2') . "." . $this->request->getVar('no_npwp3') . "-" . $this->request->getVar('no_npwp4') . "." . $this->request->getVar('no_npwp5') . "." . $this->request->getVar('no_npwp6');
        $rules = $this->validate([
            /*--------------------------------------Validasi teks---------------------------------*/
            'nama' => ['rules'  => 'required', 'errors' => ['required' => 'Nama harus diisi.']],
            //'perusahaan' => ['rules'  => 'required','errors' => ['required' => 'Perusahaan harus diisi.']]
        ]);
        if (!$rules) {
            session()->setFlashdata('add-failed', 'Tambah Data gagal !!!');
            return redirect()->back()->withInput();
        }

        $this->rhModel->save([   //  /////////      Simpan data baru ////////////////////////////////// 
            'kode_ta' => $this->request->getVar('kode_ta'),
            'posisi' => $this->request->getVar('posisi'),
            'perusahaan' => $this->request->getVar('perusahaan'),
            'nama' => $this->request->getVar('nama'),
            'kategori' => $this->request->getVar('kategori'),
            'alamat' => $this->request->getVar('alamat'),
            'kota' => $this->request->getVar('kota'),
            'tgl' => $this->request->getVar('tgl_lahir'),
            'no_npwp' => $npwp,
            'no_telp' => $this->request->getVar('no_telp'),
            'no_hp' => $this->request->getVar('no_hp'),
            'no_ktp' => $this->request->getVar('no_ktp'),
            'sipp' => $this->request->getVar('sipp'),
            'sipp_ed' => $this->request->getVar('sipp_ed'),
            'str' => $this->request->getVar('str'),
            'str_ed' => $this->request->getVar('str_ed'),
            'kta' => $this->request->getVar('kta'),
            'kta_ed' => $this->request->getVar('kta_ed'),
            'asosiasi' => $this->request->getVar('asosiasi'),
            'asosiasi_ed' => $this->request->getVar('asosiasi_ed'),
            'email' => $this->request->getVar('email'),
            'status_kepegawaian' => $this->request->getVar('status_kepegawaian')

        ]);
        return redirect()->to(base_url('/ta'))->with('add-success', 'Data berhasil ditambah');
    }

    public function uploadrefta()
    { //  Menyimpan  data baru (memakai ajax)

        $npwp = $this->request->getVar('no_npwp1') . "." . $this->request->getVar('no_npwp2') . "." . $this->request->getVar('no_npwp3') . "-" . $this->request->getVar('no_npwp4') . "." . $this->request->getVar('no_npwp5') . "." . $this->request->getVar('no_npwp6');
        $rules = $this->validate([

            'nama' => ['rules'  => 'required', 'errors' => ['required' => 'Nama harus diisi.']],
        ]);
        if (!$rules) {
            session()->setFlashdata('add-failed', 'Tambah Data gagal !!!');
            return redirect()->back()->withInput();
        }
        helper(['form', 'url']);

        $database = \Config\Database::connect();
        $builder = $database->table('tb_ta');
        $validateImage = $this->validate([
            'file' => [
                'uploaded[file]',
                'mime_in[file, image/png, image/jpg,image/jpeg, image/gif]',
                'max_size[file, 4096]',
            ],
        ]);

        $response = [
            'success' => false,
            'data' => '',
            'msg' => "Data tidak tersimpan"
        ];

        $imageFile = $this->request->getFile('file');
        if ($imageFile != '' && !$imageFile->hasMoved()) {
            $newName = $imageFile->getName();
            $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
            $imageFile->move($PATH . '/refTA');
            $lokasi = "public_html/refTA" . $newName;
            //Ini untuk localhost
            //$imageFile->move(WRITEPATH . '../public/refta/', $newName);//   Pindah file ke direktori penyimpanan
            //$lokasi = "public/refta/".$newName;

            $data = [
                'kode_ta' => $this->request->getVar('kode_ta'),
                'posisi' => $this->request->getVar('position'),
                'perusahaan' => $this->request->getVar('perusahaan'),
                'nama' => $this->request->getVar('nama'),
                'kategori' => $this->request->getVar('kategori'),
                'alamat' => $this->request->getVar('alamat'),
                'kota' => $this->request->getVar('kota'),
                'tgl' => $this->request->getVar('tgl_lahir'),
                'no_npwp' => $npwp,
                'no_telp' => $this->request->getVar('no_telp'),
                'no_hp' => $this->request->getVar('no_hp'),
                'no_ktp' => $this->request->getVar('no_ktp'),
                'sipp' => $this->request->getVar('sipp'),
                'sipp_ed' => $this->request->getVar('sipp_ed'),
                'str' => $this->request->getVar('str'),
                'str_ed' => $this->request->getVar('str_ed'),
                'kta' => $this->request->getVar('kta'),
                'kta_ed' => $this->request->getVar('kta_ed'),
                'asosiasi' => $this->request->getVar('asosiasi'),
                'asosiasi_ed' => $this->request->getVar('asosiasi_ed'),
                'email' => $this->request->getVar('email'),
                'file_pdf_referensi' => $newName,
                'lokasi_file_pdf_referensi' => $lokasi,
                'status_kepegawaian' => $this->request->getVar('status_kepegawaian')
            ];
            $save = $builder->insert($data);
            $response = [
                'success' => true,
                'data' => $save,
                'msg' => "Data tersimpan,...file image berhasil di-upload"
            ];
        } else {
            $data = [
                'kode_ta' => $this->request->getVar('kode_ta'),
                'posisi' => $this->request->getVar('position'),
                'perusahaan' => $this->request->getVar('perusahaan'),
                'nama' => $this->request->getVar('nama'),
                'kategori' => $this->request->getVar('kategori'),
                'alamat' => $this->request->getVar('alamat'),
                'kota' => $this->request->getVar('kota'),
                'tgl' => $this->request->getVar('tgl_lahir'),
                'no_npwp' => $npwp,
                'no_telp' => $this->request->getVar('no_telp'),
                'no_hp' => $this->request->getVar('no_hp'),
                'no_ktp' => $this->request->getVar('no_ktp'),
                'sipp' => $this->request->getVar('sipp'),
                'sipp_ed' => $this->request->getVar('sipp_ed'),
                'str' => $this->request->getVar('str'),
                'str_ed' => $this->request->getVar('str_ed'),
                'kta' => $this->request->getVar('kta'),
                'kta_ed' => $this->request->getVar('kta_ed'),
                'asosiasi' => $this->request->getVar('asosiasi'),
                'asosiasi_ed' => $this->request->getVar('asosiasi_ed'),
                'email' => $this->request->getVar('email'),
                'status_kepegawaian' => $this->request->getVar('status_kepegawaian')
            ];
            $save = $builder->insert($data);
            $response = [
                'success' => true,
                'data' => $save,
                'msg' => "Data tersimpan,...file image tidak ter-upload"
            ];
        }
        return $this->response->setJSON($response);
    }
    public function baca($kode)
    {
        if (session()->get('id')) {
            $posisi = $this->posisiModel->getPosisi();
            $kategori = $this->kategoriModel->getKategori();
            $data = [
                'judul' => 'Baca Data Tenaga Ahli',
                'result' => $this->rhModel->getCVwithKode($kode),
                'posisi' => $posisi,
                'kategori' => $kategori,
                'validation' => \Config\Services::validation()
            ];
            return view('ta/read', $data);
        } else
            return redirect()->to('/');
    }
    public function edit_ta($id)
    {
        if (session()->get('id')) {
            $kota = $this->CityModel->getCity();
            $n = 0;
            foreach ($kota as $val) {
                $namakota[$n] = $val['kota'];
                
                $n++;
            }
            $posisi = $this->posisiModel->getPosisi();
            $kategori = $this->kategoriModel->getKategori();
            $ta = $this->rhModel->getCV($id); // Untuk memilih nama dan mengambil id Tenaga Ahli
            $data = [
                'ta' => $ta,
                'judul' => 'Edit Data Proyek',
                'ta' => $ta,   //  Proyek diambilkan dari tabel proyek
                'posisi' => $posisi,
                'kategori' => $kategori,
                'namakota' => $namakota
            ];
            // dd($proyek);
            return view('ta/edit', $data);
        } else
            return redirect()->to('/');
    }

    public function updateTA()
    {
        helper(['form', 'url']);
        $response = [
            'success' => false,
            'data' => '',
            'msg' => "Data tidak tersimpan"
        ];
        
        $model = new rhModel();
        $id = $this->request->getPost('id');
        $imageFile = $this->request->getFile('file');
        if ($imageFile != '' && !$imageFile->hasMoved()) {  //  Ada file yang di-upload 
                    //  Dihapus dulu baru kemudian di-update, jangan di-update dulu kemudian dihapus...>>>>  kesalahan logika !!!
                   //   Hapus file referensi lama, jika ada
                   $Arr = $model->getCV($id);  //  Ambil array field-fieldnya
                   $oldFile = isset($Arr['lokasi_file_pdf_referensi']) ? $Arr['lokasi_file_pdf_referensi'] : '';   //  Ambil field lokasi file 
                   if ($oldFile != '') {   //  Periksa apakah file lama masih ada
                       $oldFile = substr($oldFile, 12);
                       if (file_exists($oldFile)) {
                           unlink($oldFile);       //  Hapus file referensi lama
                       }
                   }
            //  Ambil file baru
            $newName = $imageFile->getName();
            $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
            $imageFile->move($PATH . '/refTA');
            $lokasi = "public_html/refTA/" . $newName;
            $data = [
                //        'kode_proyek' => $this->request->getVar('kode_proyek'),
                //        'id' => $this->request->getVar('id'),
                'posisi' => $this->request->getVar('posisi'),
                'kategori' => $this->request->getVar('kategori'),
                'alamat' => $this->request->getVar('alamat'),
                'kota' => $this->request->getVar('kota'),
                'tgl' => $this->request->getVar('tgl'),
                'no_npwp' => $this->request->getVar('no_npwp'),
                'no_telp' => $this->request->getVar('no_telp'),
                'no_hp' => $this->request->getVar('no_hp'),
                'no_ktp' => $this->request->getVar('no_ktp'),
                'sipp' => $this->request->getVar('sipp'),
                'sipp_ed' => $this->request->getVar('sipp_ed'),
                'str' => $this->request->getVar('str'),
                'str_ed' => $this->request->getVar('str_ed'),
                'kta' => $this->request->getVar('kta'),
                'kta_ed' => $this->request->getVar('kta_ed'),
                'asosiasi' => $this->request->getVar('asosiasi'),
                'email' => $this->request->getVar('email'),
                'asosiasi_ed' => $this->request->getVar('asosiasi_ed'),
                'status_kepegawaian' => $this->request->getVar('status_kepegawaian'),
                'file_pdf_referensi' => $newName,
                'lokasi_file_pdf_referensi' => $lokasi
            ];
            /************************UPDATE ***********************************************************/
            /* https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/ */
            $model->update_TA(array('id' => $id), $data);
            /************************UPDATE ***********************************************************/
            $response = [
                'success' => true,
                'data' => $model,
                'msg' => "Data tersimpan,...file referensi baru berhasil di-upload, file lama dihapus",
            ];
        } else {   //  Tidak ada file yang di-upload
            $data = [
                'posisi' => $this->request->getVar('posisi'),
                'kategori' => $this->request->getVar('kategori'),
                'alamat' => $this->request->getVar('alamat'),
                'kota' => $this->request->getVar('kota'),
                'tgl' => $this->request->getVar('tgl'),
                'no_npwp' => $this->request->getVar('no_npwp'),
                'no_telp' => $this->request->getVar('no_telp'),
                'no_hp' => $this->request->getVar('no_hp'),
                'no_ktp' => $this->request->getVar('no_ktp'),
                'sipp' => $this->request->getVar('sipp'),
                'sipp_ed' => $this->request->getVar('sipp_ed'),
                'str' => $this->request->getVar('str'),
                'str_ed' => $this->request->getVar('str_ed'),
                'kta' => $this->request->getVar('kta'),
                'kta_ed' => $this->request->getVar('kta_ed'),
                'asosiasi' => $this->request->getVar('asosiasi'),
                'email' => $this->request->getVar('email'),
                'asosiasi_ed' => $this->request->getVar('asosiasi_ed'),
                'status_kepegawaian' => $this->request->getVar('status_kepegawaian'),
            ];
            $model = new rhModel();
            /* https://www.tutsmake.com/codeigniter-4-ajax-crud-with-datatables-and-bootstrap-modals/ */
            $model->update_TA(array('id' => $id), $data);
            $response = [
                'success' => true,
                'data' => $model,
                'msg' => "Data tersimpan,...tidak ada file yang di-upload"
            ];
        }
        return $this->response->setJSON($response);
    }

    public function update($id)
    {
        // dd($this->request->getVar('kota'));

        $file = $this->request->getFile('file');
        if ($file != '' && !$file->hasMoved()) {
            $newName = $file->getName();
            $lokasi = "public_html/ref/" . $newName;
            if (is_file($lokasi)) {
                $this->rhModel->save([  /////////UPDATE//////////////////////////////////
                    'id' => $id,
                    'posisi' => $this->request->getVar('posisi'),
                    'perusahaan' => $this->request->getVar('perusahaan'),
                    'kategori' => $this->request->getVar('kategori'),
                    'alamat' => $this->request->getVar('alamat'),
                    'kota' => $this->request->getVar('kota'),
                    'tgl' => $this->request->getVar('tgl'),
                    'no_npwp' => $this->request->getVar('no_npwp'),
                    'no_telp' => $this->request->getVar('no_telp'),
                    'no_hp' => $this->request->getVar('no_hp'),
                    'no_ktp' => $this->request->getVar('no_ktp'),
                    'sipp' => $this->request->getVar('sipp'),
                    'sipp_ed' => $this->request->getVar('sipp_ed'),
                    'str' => $this->request->getVar('str'),
                    'str_ed' => $this->request->getVar('str_ed'),
                    'kta' => $this->request->getVar('kta'),
                    'kta_ed' => $this->request->getVar('kta_ed'),
                    'asosiasi' => $this->request->getVar('asosiasi'),
                    'email' => $this->request->getVar('email'),
                    'asosiasi_ed' => $this->request->getVar('asosiasi_ed'),
                    'status_kepegawaian' => $this->request->getVar('status_kepegawaian')
                ]);
            } else {
                $PATH = getcwd();    //https://forum.codeigniter.com/showthread.php?tid=74782&page=2
                $file->move($PATH . '/ref');
                $this->rhModel->save([  /////////UPDATE//////////////////////////////////
                    'id' => $id,
                    'posisi' => $this->request->getVar('posisi'),
                    'perusahaan' => $this->request->getVar('perusahaan'),
                    'kategori' => $this->request->getVar('kategori'),
                    'alamat' => $this->request->getVar('alamat'),
                    'kota' => $this->request->getVar('kota'),
                    'tgl' => $this->request->getVar('tgl'),
                    'no_npwp' => $this->request->getVar('no_npwp'),
                    'no_telp' => $this->request->getVar('no_telp'),
                    'no_hp' => $this->request->getVar('no_hp'),
                    'no_ktp' => $this->request->getVar('no_ktp'),
                    'sipp' => $this->request->getVar('sipp'),
                    'sipp_ed' => $this->request->getVar('sipp_ed'),
                    'str' => $this->request->getVar('str'),
                    'str_ed' => $this->request->getVar('str_ed'),
                    'kta' => $this->request->getVar('kta'),
                    'kta_ed' => $this->request->getVar('kta_ed'),
                    'asosiasi' => $this->request->getVar('asosiasi'),
                    'email' => $this->request->getVar('email'),
                    'asosiasi_ed' => $this->request->getVar('asosiasi_ed'),
                    'status_kepegawaian' => $this->request->getVar('status_kepegawaian'),
                    'file_pdf_referensi' => $newName,
                    'lokasi_file_pdf_referensi' => $lokasi
                ]);
            }
        }

        return redirect()->to(base_url('/ta'))->with('sukses-edit', 'Data berhasil diupdate');
    }
    public function delete($id)
    {
        $model = new rhModel();  //  Ambil array field-fieldnya
        $Arr = $model->getCV($id);  //  Ambil array field-fieldnya
        $oldFile = isset($Arr['lokasi_file_pdf_referensi']) ? $Arr['lokasi_file_pdf_referensi'] : '';   //  Ambil field lokasi file 
        if ($oldFile != '') {   //  Periksa apakah file lama masih ada
            $oldFile = substr($oldFile, 12);
            if (file_exists($oldFile)) {
                unlink($oldFile);       //  Hapus file referensi lama
            }
        }
        $this->rhModel->delete($id);
        return redirect()->to(base_url('/ta'))->with('sukses-hapus', 'Data berhasil dihapus');
    }

    public function help()
    {
        return view('/ta/help');
    }

    //  Hanya bisa untuk halaman 1 (pertama), halaman kedua dst. tidak bisa ????????
    public function hapus_semua()
    {
        // dd(isset($_POST['dell_all']));
        //  Tombol hapus semua diklik

        if (isset($_POST['dell_all']) == true) {

            //dd(isset($_POST['ckval']));
            // dd($this->request->getPost('ckval'));

            if (!empty($this->request->getPost('ckval'))) {
                //dd($this->request->getPost('ckval'));
                $check = $this->request->getPost('ckval');
                //  dd($this->request->getPost('ckval'));
                foreach ($check as $brs) {
                    $this->rhModel->delete($brs);
                }
                return redirect()->to(base_url('/ta'))->with('sukses-hapus-semua', 'Data berhasil dihapus');
            } else {
                echo '<script type="text/javascript">';
                echo 'alert("Pilih minimal satu kotak check box")';  //not showing an alert box.
                echo '</script>';
                return redirect()->to(base_url('/ta'))->with('gagal-hapus-semua', 'Gagal hapus,...pilih minimal satu kotak check box');
            }
        }
    }


    public function importExcel()
    {
        $spreadsheet = new Spreadsheet();

        $file = $this->request->getFile('excel');

        $ext = $file->getExtension();
        if ($ext === "xls" || $ext === "xlsx") {

            if ($ext === "xls") $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();    //  Jika ekstensinya xls
            else $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx(); //  Jika ekstensinya xlsx
            $spread = $reader->load($file); //   Muat ke reader, tampung ke variabel $spread
            $sheet = $spread->getActiveSheet()->toArray(); //    Membaca sheet aktif dan menampung ke array

            foreach ($sheet as $index => $item) {
                if ($index == 0) continue; // Baris ke 0 berisi header(judul), bukan data, jadi diabaikan
                //  Jika baris x semua kolom kosong berhenti
                if (
                    $item[0] == "" &&
                    $item[1] == "" &&
                    $item[2] == "" &&
                    $item[3] == "" &&
                    $item[4] == "" &&
                    $item[5] == "" &&
                    $item[6] == "" &&
                    $item[7] == "" &&
                    $item[8] == "" &&
                    $item[9] == "" &&
                    $item[10] == "" &&
                    $item[11] == "" &&
                    $item[12] == "" &&
                    $item[13] == "" &&
                    $item[14] == "" &&
                    $item[15] == "" &&
                    $item[16] == "" &&
                    $item[17] == "" &&
                    $item[18] == "" &&
                    $item[19] == "" &&
                    $item[20] == ""
                ) {
                    break;
                }
                if ($item[0] != "" && $item[1] != "") {
                    $data =
                        [

                            'kode_ta' => $item[0],    //      kolom a
                            'nama' => $item[1],       //      kolom b
                            'alamat' => $item[2],
                            'kota' => $item[3],
                            'tgl' => $item[4],
                            'no_ktp' => $item[5],
                            'no_npwp' => $item[6],
                            'no_telp' => $item[7],
                            'no_hp' => $item[8],
                            'email' => $item[9],
                            'posisi' => $item[10],
                            'perusahaan' => $item[11],
                            'kategori' => $item[12],
                            'sipp' => $item[13],
                            'sipp_ed' => $item[14],
                            'str' => $item[15],
                            'str_ed' => $item[16],
                            'kta' => $item[17],
                            'kta_ed' => $item[18],
                            'asosiasi' => $item[19],
                            'asosiasi_ed' => $item[20]
                        ];
                    $this->rhModel->insert($data);  // mulai baris 1 dan seterusnya 
                }
            }
            session()->setFlashdata('import', 'Data berhasil di-impor');
        } else {
            session()->setFlashdata('error', 'Bukan format file excel');
        }
        return redirect()->to('/ta');
    }

    public function exporExcel()
    {

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $sheet->setCellValue('A1', 'Kode');
        $sheet->setCellValue('B1', 'Nama Tenaga Ahli');
        $sheet->setCellValue('C1', 'Alamat');
        $sheet->setCellValue('D1', 'Kota');
        $sheet->setCellValue('E1', 'Tanggal');
        $sheet->setCellValue('F1', 'No. KTP');
        $sheet->setCellValue('G1', 'No. NPWP');
        $sheet->setCellValue('H1', 'No. telp.');
        $sheet->setCellValue('I1', 'No. HP');
        $sheet->setCellValue('J1', 'e-Mail');
        $sheet->setCellValue('K1', 'Posisi');
        $sheet->setCellValue('L1', 'Perusahaan');
        $sheet->setCellValue('M1', 'Kategori');
        $sheet->setCellValue('N1', 'SIPP');
        $sheet->setCellValue('O1', 'SIPP ED');
        $sheet->setCellValue('P1', 'STR');
        $sheet->setCellValue('Q1', 'STR ED');
        $sheet->setCellValue('R1', 'KTA');
        $sheet->setCellValue('S1', 'KTA ED');
        $sheet->setCellValue('T1', 'Asosiasi');
        $sheet->setCellValue('U1', 'Asosiasi ED');


        $row = 2;   // row 1 dipakai untuk header (judul-judul kolom di atas)
        $edu = $this->rhModel->getCV();
        foreach ($edu as $v => $item) {
            $sheet
                ->setCellValue('A' . $row, $item['kode_ta'])
                ->setCellValue('B' . $row, $item['nama'])
                ->setCellValue('C' . $row, $item['alamat'])
                ->setCellValue('D' . $row, $item['kota'])
                ->setCellValue('E' . $row, $item['tgl'])
                ->setCellValue('F' . $row, $item['no_ktp'])
                ->setCellValue('G' . $row, $item['no_npwp'])
                ->setCellValue('H' . $row, $item['no_telp'])
                ->setCellValue('I' . $row, $item['no_hp'])
                ->setCellValue('J' . $row, $item['email'])
                ->setCellValue('K' . $row, $item['posisi'])
                ->setCellValue('L' . $row, $item['perusahaan'])
                ->setCellValue('M' . $row, $item['kategori'])
                ->setCellValue('N' . $row, $item['sipp'])
                ->setCellValue('O' . $row, $item['sipp_ed'])
                ->setCellValue('P' . $row, $item['str'])
                ->setCellValue('Q' . $row, $item['str_ed'])
                ->setCellValue('R' . $row, $item['kta'])
                ->setCellValue('S' . $row, $item['kta_ed'])
                ->setCellValue('T' . $row, $item['asosiasi'])
                ->setCellValue('U' . $row, $item['asosiasi_ed']);
            $row++;
        }

        $filename = "Tenaga_Ahli";
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename=' . $filename . '.xlsx');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
    }

    public function kosong()
    {
        $this->rhModel->kosongkan();
        return redirect()->to('/ta');
    }
}
