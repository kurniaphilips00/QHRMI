<?php

namespace App\Controllers;

use App\Models\kategoriModel;
use App\Controllers\BaseController;
use PDO;

class CategoryController extends BaseController
{
    protected $kategoriModel;
    public function __construct()
    {
        $kategori = $this->kategoriModel = new kategoriModel();
    }

    public function index()
    {
        if (session()->get('id')) {
            $kategori = $this->kategoriModel->getKategori();
            $data = ['kategori' => $kategori, 'judul' => 'Data Kategori',];
            return view('/kategori/index1', $data);
        } else
            return redirect()->to('/');
    }
    public function baca($id)
    {
        $model = new kategoriModel();
        $data = $model->getKategori($id);
        echo json_encode($data);
    }

    public function simpan()
    {
        $data = [
            'kategori' => $this->request->getPost('kategori'),
        ];
        $model = new kategoriModel();
        $model->save($data);
        return $this->response->setJSON([
            'status' => 'Sukses tambah data !'
        ]);
    }
    public function update()
    {    
        $id = $this->request->getPost('id');
        helper(['form', 'url']);
        $data = [
            'kategori' => $this->request->getPost('kategori')
        ];
        $model = new kategoriModel();
        $model->update_kategori(array('id' => $id), $data);
        return $this->response->setJSON([
            'status' => 'Sukses update data !'
        ]);
    }
    public function edit($id)
    {
        $model = new kategoriModel();
        $data = $model->getKategori($id);
        echo json_encode($data);
    }
    public function delete($id)
    {
        
        $model = new kategoriModel();
        $model->delete($id);
        
        return $this->response->setJSON([
            'status' => 'Sukses hapus data !'
        ]);
    }
}
