<?php

namespace App\Controllers;

use App\Models\rhModel;
use App\Models\bhsModel;
use App\Controllers\BaseController;
use PDO;

class BahasaController extends BaseController
{
    protected $rhModel;
    protected $bhsModel;
    public function __construct()
    {
        $ta = $this->rhModel = new rhModel();
        $bhs = $this->bhsModel = new bhsModel();
    }
    public function ajax_edit_bahasa($id) {
        $model = new bhsModel();
        $data = $model->getBahasaByID($id);
        echo json_encode($data);
    }
    public function ajax_update_bahasa() {
        helper(['form', 'url']);
        $id = $this->request->getPost('id_bahasa');
        $data = [
        
            'nilai_bhs_indo' => $this->request->getPost('nilai_bhs_indo'),
            'nilai_bhs_inggris' => $this->request->getPost('nilai_bhs_inggris'),
            'nilai_bhs_setempat' => $this->request->getPost('nilai_bhs_setempat')
        ];
        $model = new bhsModel();
        $model->update_Bahasa(array('id_bahasa' => $id), $data);
        return $this->response->setJSON([
            'status' => 'Sukses update data !'
        ]);
    }
    public function ajax_baca_bahasa($id)
    {
        $model = new bhsModel();
        $data = $model->getBahasaByID($id);
        echo json_encode($data);
    }
    public function ajax_delete_bahasa($id)
    {
        $model = new bhsModel();
        $model->delete($id);
        return $this->response->setJSON([
            'status' => 'Sukses hapus data !'
        ]);
    }
    public function ajax_bahasa_add()
    {
        $data = [
            'kode_ta' => $this->request->getPost('kode_ta'),
            'nama_ta' => $this->request->getPost('nama'),
            'nilai_bhs_indo' => $this->request->getPost('nilai_bhs_indo'),
            'nilai_bhs_inggris' => $this->request->getPost('nilai_bhs_inggris'),
            'nilai_bhs_setempat' => $this->request->getPost('nilai_bhs_setempat')
        ];
        $model = new bhsModel();
        $model->save($data);
        return $this->response->setJSON([
            'status' => 'Sukses tambah data !'
        ]);
    }
    public function index()
    {
        if (session()->get('id')) {
            $ta = $this->rhModel->getCV();
            $n = 0;
            foreach ($ta as $val) {
                $nama[$n] = $val['nama'];
                $kode[$n] = $val['kode_ta'];
                $n++;
            }
            $bhs = $this->bhsModel->getBahasa();
            $data = [
                'judul' => 'Data Bahasa',
                'ta' => $ta,
                'nama' => $nama,
                'kode' => $kode,
                'bhs' => $bhs
            ];
            return view('bahasa/index1', $data);
        } else
            return redirect()->to('/');
    }
    public function FilterByName($nama)
    {
        return $this->index($nama);
    }
}
