<?php

namespace App\Controllers;
use App\Models\CityModel;
use App\Controllers\BaseController;

class City extends BaseController
{
    protected $CityModel;
    public function __construct()
    {
        $kota = $this->CityModel = new CityModel();
    }

    public function index()
    {
        if (session()->get('id')) {
            $kota = $this->CityModel->getCity();
            $data = ['kota' => $kota, 'judul' => 'Data Kota',];
            return view('/kota/index1', $data);
        } else
            return redirect()->to('/');
    }
    public function baca($id)
    {
        $model = new CityModel();
        $data = $model->getCity($id);
        echo json_encode($data);
    }

    public function simpan()
    {
        $data = [
            'kota' => $this->request->getPost('kota'),
        ];
        $model = new CityModel();
        $model->save($data);
        return $this->response->setJSON([
            'status' => 'Sukses tambah data !'
        ]);
    }
    public function update()
    {    
        $id = $this->request->getPost('id');
        helper(['form', 'url']);
        $data = [
            'kota' => $this->request->getPost('kota')
        ];
        $model = new CityModel();
        $model->update_city(array('id' => $id), $data);
        return $this->response->setJSON([
            'status' => 'Sukses update data !'
        ]);
    }
    public function edit($id)
    {
        $model = new CityModel();
        $data = $model->getCity($id);
        echo json_encode($data);
    }
    public function delete($id)
    {
        $model = new CityModel();
        $model->delete($id);
        return $this->response->setJSON([
            'status' => 'Sukses hapus data !'
        ]);
    }
}
