<?php

namespace App\Controllers;

use App\Models\rhModel;
use App\Models\eduModel;
use App\Models\ModelJurusan;
use App\Models\ModelUniversitas;
use App\Controllers\BaseController;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PDO;

class PendidikanController extends BaseController
{
    protected $taModel;
    protected $eduModel;
    protected $univModel;
    protected $jurModel;

    public function __construct()
    {

        $ta = $this->taModel = new rhModel();
        $pendidikan = $this->eduModel = new eduModel();
        $univModel = $this->univModel = new ModelUniversitas();
        $jurModel = $this->jurModel = new ModelJurusan();
    }
    public function ajax_edit_pendidikan($id) {
        $model = new eduModel();
        $data = $model->getPendidikan($id);
        echo json_encode($data);
    }
    public function ajax_update_pendidikan() {
        helper(['form', 'url']);
        $data = [
            'strata' => $this->request->getPost('strata'),
            'jurusan' => $this->request->getPost('jurusan'),
            'universitas' => $this->request->getPost('universitas'),
            'thn_lulus' => $this->request->getPost('thn_lulus')
        ];
        $model = new eduModel();
        $model->edu_update(array('id' => $this->request->getPost('id')), $data);
        return $this->response->setJSON([
            'status' => 'Sukses update data !'
        ]);
    }
    public function ajax_delete_edu($id)
    {
        $model = new eduModel();
        $model->delete($id);
        return $this->response->setJSON([
            'status' => 'Sukses hapus data !'
        ]);
    }
    public function ajax_add_pendidikan()
    {
        $data = [
            'kode_ta' => $this->request->getPost('kode_ta'),
            'nama_ta' => $this->request->getPost('nama_ta'),
            'strata' => $this->request->getPost('strata'),
            'jurusan' => $this->request->getPost('jurusan'),
            'universitas' => $this->request->getPost('universitas'),
            'thn_lulus' => $this->request->getPost('thn_lulus')
        ];
        $model = new eduModel();
        $model->save($data);
        return $this->response->setJSON([
            'status' => 'Sukses tambah data !'
        ]);
    }
    public function ajax_baca_pendidikan($id) {
        $model = new eduModel();
        $data = $model->getPendidikan($id);
        echo json_encode($data);
    }
    public function index()
    {
        if (session()->get('id')) {
            $ta = $this->taModel->getCV();
            $n = 0;
            foreach ($ta as $val) {
                $nama[$n] = $val['nama'];
                $kode[$n] = $val['kode_ta'];
                $n++;
            }
            //  $n = 0;
            $strata[0] = "SMK/SMA";
            $strata[1] = "D1";
            $strata[2] = "D2";
            $strata[3] = "D3";
            $strata[4] = "S1";
            $strata[5] = "S2";
            $strata[6] = "S3";
            $strata[7] = "Psikolog";
            $strata[8] = "Profesi Psikolog";

            $jurusan = $this->jurModel->getJurusan();
            $n = 0;
            foreach ($jurusan as $val) {
                $jur[$n] = $val['jurusan'];
                $n++;
            }

            $universitas = $this->univModel->getUniversitas();
            $n = 0;
            foreach ($universitas as $val) {
                $univ[$n] = $val['universitas'];
                $n++;
            }

            $pendidikan = $this->eduModel->getPendidikan();
            $data = [
                'judul' => 'Data Pendidikan Tenaga Ahli',
                'ta' => $ta,
                'nama' => $nama,
                'kode' => $kode,
                'strata' => $strata,
                'jurusan' => $jur,
                'universitas' => $univ,
                'pendidikan' =>  $pendidikan
            ];
            return view('pendidikan/index1', $data);
        } else
            return redirect()->to('/');
    }
    public function FilterByName($nama)
    {
        return $this->index($nama);
    }
    public function exportExcel()
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        //      Baris pertama berisi judul

        $sheet->setCellValue('A1', 'Kode');
        $sheet->setCellValue('B1', 'Nama Tenaga Ahli');
        $sheet->setCellValue('C1', 'Strata');
        $sheet->setCellValue('D1', 'Jurusan');
        $sheet->setCellValue('E1', 'Universitas');
        $sheet->setCellValue('F1', 'Tahun Lulus');

        $row = 2;   // row 1 dipakai untuk header (judul-judul kolom di atas)
        $edu = $this->eduModel->getPendidikan();
        foreach ($edu as $v => $item) {
            $sheet
                ->setCellValue('A' . $row, $item['kode_ta'])
                ->setCellValue('B' . $row, $item['nama_ta'])
                ->setCellValue('C' . $row, $item['strata'])
                ->setCellValue('D' . $row, $item['jurusan'])
                ->setCellValue('E' . $row, $item['universitas'])
                ->setCellValue('F' . $row, $item['thn_lulus']);
            $row++;
        }

        $filename = "pendidikan";
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename=' . $filename . '.xlsx');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
    }


    //pendidikan/importExcel
    public function importExcel()
    { //importExcel
        $spreadsheet = new Spreadsheet();
        //  Ambil file dari name (input type="file".... name="excel".....) di dalam index.php
        $file = $this->request->getFile('excel');

        $ext = $file->getExtension();


        if ($ext === "xls" || $ext === "xlsx") {

            if ($ext === "xls") $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();    //  Jika ekstensinya xls
            else $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx(); //  Jika ekstensinya xlsx
            $spread = $reader->load($file); //   Muat ke reader, tampung ke variabel $spread
            $sheet = $spread->getActiveSheet()->toArray(); //    Membaca sheet aktif dan menampung ke array
            foreach ($sheet as $index => $item) {
                if ($index == 0) continue; // Baris ke 0 berisi header(judul), bukan data, jadi diabaikan
                // Jika menemui baris terakhir berhenti
                if (
                    $item[0] == "" && $item[1] == "" && $item[2] == "" && $item[3] == "" && $item[4] == ""
                    && $item[5] == "" && $item[6] == ""
                ) {
                    break;
                }
                if ($item[0] != "" && $item[1] != "" && $item[2] != "" && $item[3] != "" && $item[4] != "" && $item[5] != "") {
                    $data =
                        [
                            'kode_ta' => $item[0],        //      kolom B
                            'nama_ta' => $item[1],        //      kolom C
                            'strata' => $item[2],         //      kolom D
                            'jurusan' => $item[3],        //      kolom E
                            'universitas' => $item[4],    //      kolom F
                            'thn_lulus' => $item[5],      //      kolom G
                        ];
                    $this->eduModel->insert($data);  // mulai baris 1 dan seterusnya 
                }
            }
            session()->setFlashdata('import', 'Data berhasil di-impor');
        } else {
            session()->setFlashdata('error', 'Bukan format file excel');
        }
        return redirect()->to('/pendidikan');
    }

    public function kosong()
    { //Mengosongkan tabel
        $this->eduModel->kosongkan();
        return redirect()->to('/pendidikan');
    }
}
