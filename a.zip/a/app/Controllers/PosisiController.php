<?php

namespace App\Controllers;
use App\Models\posisiModel;
use App\Controllers\BaseController;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PDO;

class PosisiController extends BaseController
{
    protected $posisiModel;
    public function __construct()
    {         
        $posisi = $this->posisiModel = new posisiModel();     
    }
    
    public function index()
    {
        if (session()->get('id')) {
            $posisi = $this->posisiModel->getPosisi();
            $data = [            
                'posisi' => $posisi, 'judul' => 'Data Posisi',
            ];
            return view ('posisi/index', $data);
        }
        else
            return redirect()->to('/');
    }
    public function baca($id)
    {
        if (session()->get('id')) {
            $posisi = $this->posisiModel->getPosisi($id);
            $data = [
                'judul' => 'Baca Data Posisi',
                'posisi' => $posisi];
            return view('posisi/baca', $data);
        }
        else
            return redirect()->to('/');
    }
    public function edit($id) {
        if (session()->get('id')) {
            $posisi = $this->posisiModel->getPosisi($id);
            $data = [
                'judul' => 'Edit Data Posisi',
                'posisi' => $posisi
            ];
            return view('posisi/edit', $data);
        }
        else
            return redirect()->to('/');    
    }
    public function update($id) {
        $this->posisiModel->save([  
            'id' => $id,
            'posisitugas'=>esc($this->request->getVar('posisi')),
            'uraiantugas' =>esc($this->request->getVar('editor1')) 
        ]);
        return redirect()->to(base_url('/posisi'))->with('sukses-update-posisi', 'Posisi berhasil diupdate');
    }
    public function tambah() {
        if (session()->get('id')) {
            helper('custom_helper'); // Loading single helper
            $posisi = $this->posisiModel->getPosisiByKode();
            helper('custom_helper');
            $kode = CheckPosisi($posisi);   //  Menghitung nomor kode
            if ($kode == null) {
                $kode = hitungKode('tb_posisi');
            }

            $posisi = $this->posisiModel->getPosisi();
            $data = [
                'judul' => 'Tambah Data Posisi',
                'kode' => $kode,
                'posisi' => $posisi, 
                'validation' => \Config\Services::validation()
            ];
            return view('posisi/add', $data);
        }
        else
            return redirect()->to('/');
    }
   
    public function simpan() {
        $connect = new PDO("mysql:host=localhost; dbname=u454747069_prapro,u454747069_prapro374,374@Prapro374");
        if (isset($_POST["kode_posisi"])) {
         
            $data = array(
                ':kode_posisi' => trim($_POST["kode_posisi"]),
                ':posisitugas' => trim($_POST["posisitugas"]),
                ':uraiantugas' => trim($_POST["uraiantugas"])
            );
            ////)
            $query = "INSERT INTO tb_posisi(kode_posisi, posisitugas, uraiantugas)
            values (:kode_posisi, :posisitugas, :uraiantugas)";
            $statement = $connect->prepare($query);
            $statement->execute($data);
        }
    }

    public function delete($id) {
        $this->posisiModel->delete($id);
        session()->setFlashdata('del-success','Data posisi berhasil dihapus');
        return redirect()->to('/posisi');
    }
    public function importExcel() {
        $spreadsheet = new Spreadsheet();
        //  Ambil file dari name (input type="file".... name="excel".....) di dalam index.php
        $file = $this->request->getFile('excel');
        $ext = $file->getExtension();
        $this->posisiModel->kosongkan();
        if ($ext === "xls" || $ext === "xlsx") {
            $this->posisiModel->kosongkan();
            if ($ext === "xls") $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();    //  Jika ekstensinya xls
            else $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx(); //  Jika ekstensinya xlsx
            $spread = $reader->load($file);//   Muat ke reader, tampung ke variabel $spread
            $sheet = $spread->getActiveSheet()->toArray();//    Membaca sheet aktif dan menampung ke array
            foreach ($sheet as $index=>$item) {
                if ($index == 0) continue; // Baris ke 0 berisi header(judul), bukan data, jadi diabaikan
             
                if ($item[0] == "") {
                    break;       
                 }
               
                 
                    $data =
                       [  
                            'id'=>$item[0],          //      kolom A
                            'kode_posisi'=>$item[1],    //      kolom B
                            'posisi'=>$item[2],   //      kolom C
                           // 'uraiantugas'=>$item[3],      //      kolom D
                            
                            
                        ];
                    
                     $this->posisiModel->insert($data);  // mulai baris 1 dan seterusnya
                     
            }
            session()->setFlashdata('import','Data berhasil di-impor'); 
        }
        else {
            session()->setFlashdata('error','Bukan format file excel'); 
        }
        return redirect()->to('/pengalaman/');
    }
}
