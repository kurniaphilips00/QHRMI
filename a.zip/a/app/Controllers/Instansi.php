<?php

namespace App\Controllers;

use App\Models\InstansiModel;
use App\Controllers\BaseController;
use PhpOffice\PhpSpreadsheet\Spreadsheet;


class Instansi extends BaseController
{
    protected $InstansiModel;
    public function __construct()
    {
        $instansi = $this->InstansiModel = new InstansiModel();
    }

    public function index()
    {
        if (session()->get('id')) {
            $instansi = $this->InstansiModel->getInstansi();
            $data = ['instansi' => $instansi, 'judul' => 'Data Instansi',];
            return view('/instansi/index', $data);
        } else
            return redirect()->to('/');
    }

    public function tambah()
    {
        if (session()->get('id')) {
            helper('custom_helper'); // Loading single helper
            //  Menentukan kode pengalaman (tabel tb_proyek_ta)
            $instansi = $this->InstansiModel->getInstansi();
            helper('custom_helper');
            $kode = CheckInstansi($instansi);   //  Menghitung nomor kode
            if ($kode == null) {
                $kode = hitungKode('tb_instansi');
            }

            $instansi = $this->InstansiModel->getInstansi();
            $data = [
                'judul' => 'Tambah Data Instansi',
                'instansi' => $instansi,
                'kode' => $kode,
                'validation' => \Config\Services::validation()
            ];
            return view('/instansi/add', $data);
        } else
            return redirect()->to('/');
    }
    public function simpan()    //  Menyimpan  data baru
    {

        //$npwp = $this->request->getVar('no_npwp1') ."." . $this->request->getVar('no_npwp2') . "." . $this->request->getVar('no_npwp3') . "-" . $this->request->getVar('no_npwp4') . "." . $this->request->getVar('no_npwp5') . "." . $this->request->getVar('no_npwp6');
        $rules = $this->validate([
            /*--------------------------------------Validasi teks---------------------------------*/
            'nama_instansi' => ['rules'  => 'required', 'errors' => ['required' => 'Nama instansi harus diisi.']],
            //'perusahaan' => ['rules'  => 'required','errors' => ['required' => 'Perusahaan harus diisi.']]
        ]);
        if (!$rules) {
            session()->setFlashdata('add-failed', 'Tambah Data gagal !!!');
            return redirect()->back()->withInput();
        }

        $this->InstansiModel->save([   //  /////////      Simpan data baru ////////////////////////////////// 
            'kode_instansi' => $this->request->getVar('kode_instansi'),
            'nama_instansi' => $this->request->getVar('nama_instansi'),
            'alamat' => $this->request->getVar('alamat'),
            'notelp' => $this->request->getVar('notelp'),
            'email' => $this->request->getVar('email')
        ]);
        return redirect()->to(base_url('/instansi'))->with('add-success', 'Data berhasil ditambah');
    }

    public function update($id)
    {
        $this->InstansiModel->save([
            'id' => $id,
            'nama_instansi' => $this->request->getVar('nama_instansi'),
            'alamat' => $this->request->getVar('alamat'),
            'notelp' => $this->request->getVar('notelp'),
            'email' => $this->request->getVar('email')
        ]);
        return redirect()->to(base_url('/instansi'))->with('sukses-update-instansi', 'Instansi berhasil diupdate');
    }
    public function edit($id)
    {
        if (session()->get('id')) {
            $instansi = $this->InstansiModel->getInstansi($id);
            $data = [
                'judul' => 'Edit Data Instansi',
                'instansi' => $instansi
            ];
            return view('instansi/edit', $data);
        } else
            return redirect()->to('/');
    }
    public function delete($id)
    {
        // dd($id);
        $this->InstansiModel->delete($id);
        session()->setFlashdata('del-success', 'Data instansi berhasil dihapus');
        return redirect()->to(base_url('/instansi'));
    }

    public function read($id)
    {
        if (session()->get('id')) {
            $instansi = $this->InstansiModel->getInstansi($id);
            $data = [
                'instansi' => $instansi,
                'judul' => 'Baca Data Instansi'
            ];
            return view('instansi/read', $data);
        } else
            return redirect()->to('/');
    }

    public function importExcel()
    {   //importExcel
        $spreadsheet = new Spreadsheet();
        $file = $this->request->getFile('excel');

        $ext = $file->getExtension();

        if ($ext === "xls" || $ext === "xlsx") {

            if ($ext === "xls") $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();    //  Jika ekstensinya xls
            else $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx(); //  Jika ekstensinya xlsx
            $spread = $reader->load($file); //   Muat ke reader, tampung ke variabel $spread
            $sheet = $spread->getActiveSheet()->toArray(); //    Membaca sheet aktif dan menampung ke array

            foreach ($sheet as $index => $item) {
                if ($index == 0) continue; // Baris ke 0 berisi header(judul), bukan data, jadi diabaikan
                //  Jika baris x semua kolom kosong berhenti
                if ($item[0] == "" && $item[1] == "" && $item[2] == "" && $item[3] == "" && $item[4] == "") {
                    break;
                }
                if ($item[0] != "" && $item[1] != "") {
                    $data =
                        [
                            'kode_instansi' => $item[0],              //      kolom A
                            'nama_instansi' => $item[1],              //      kolom B
                            'alamat' => $item[2],                      //      kolom C                            	
                            'notelp' => $item[3],                      //      kolom D				
                            'email' => $item[4]                     //      kolom E
                        ];
                    $this->InstansiModel->insert($data);
                }
            }

            session()->setFlashdata('imported', 'Data berhasil di-impor ');
        } else {
            session()->setFlashdata('error', 'Bukan format file excel');
        }
        return redirect()->to(base_url('/instansi'));
    }

    public function exportToExcel()
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'Kode Instansi');
        $sheet->setCellValue('B1', 'Nama Instansi');
        $sheet->setCellValue('C1', 'Alamat');
        $sheet->setCellValue('D1', 'No. telp');
        $sheet->setCellValue('E1', 'Email');

        $row = 2;   // row 1 dipakai untuk header (judul-judul kolom di atas)
        $ins = $this->InstansiModel->getInstansi();
        foreach ($ins as $v => $item) {
            $sheet
                ->setCellValue('A' . $row, $item['kode_instansi'])
                ->setCellValue('B' . $row, $item['nama_instansi'])
                ->setCellValue('C' . $row, $item['alamat'])
                ->setCellValue('D' . $row, $item['notelp'])
                ->setCellValue('E' . $row, $item['email']);
            $row++;
        }

        $filename = "Instansi";
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename=' . $filename . '.xlsx');
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
    }

    public function kosong()
    {
        $this->InstansiModel->kosongkan();
        return redirect()->to(base_url('/instansi'));
    }
}
