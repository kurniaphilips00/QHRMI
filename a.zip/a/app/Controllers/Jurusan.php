<?php

namespace App\Controllers;
use App\Models\ModelJurusan;
use App\Controllers\BaseController;

class Jurusan extends BaseController
{
    protected $ModelJurusan;
    public function __construct()
    {
        $jurusan = $this->ModelJurusan = new ModelJurusan();
    }
    public function index()
    {
        if (session()->get('id')) {
            $jurusan = $this->ModelJurusan->getJurusan();
            $data = ['jurusan' => $jurusan, 'judul' => 'Data Jurusan',];
            return view('/jurusan/index1', $data);
        } else
            return redirect()->to('/');
    }
    public function baca($id)
    {
        $model = new ModelJurusan();
        $data = $model->getJurusan($id);
        echo json_encode($data);
    }

    public function simpan()
    {
        $data = [
            'jurusan' => $this->request->getPost('jurusan'),
        ];
        $model = new ModelJurusan();
        $model->save($data);
        return $this->response->setJSON([
            'status' => 'Sukses tambah data !'
        ]);
    }
    public function update()
    {    
        $id = $this->request->getPost('id');
        helper(['form', 'url']);
        $data = [
            'jurusan' => $this->request->getPost('jurusan')
        ];
        $model = new ModelJurusan();
        $model->update_jurusan(array('id' => $id), $data);
        return $this->response->setJSON([
            'status' => 'Sukses update data !'
        ]);
    }
    public function edit($id)
    {
        $model = new ModelJurusan();
        $data = $model->getJurusan($id);
        echo json_encode($data);
    }
    public function delete($id)
    {
        $model = new ModelJurusan();
        $model->delete($id);
        return $this->response->setJSON([
            'status' => 'Sukses hapus data !'
        ]);
    }
}
