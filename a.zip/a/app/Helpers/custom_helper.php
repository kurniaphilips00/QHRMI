<?php

//  Untuk menghitung jumlah semua tenaga ahli, tenaga ahli psikologi, SDM, lainnya.... pada dashboard 
function countData($tabel)
{
  $db = \Config\Database::connect();
  return $db->table($tabel)->countAllResults();
}
function HitungOmset()
{
  $omset = new App\Models\omsetModel();
  return $omset->getNilaiOmsetBulanan();
}
function HitungTotalOmsetBulanan()
{
  $tot = 0;
  $omset = new App\Models\omsetModel();
  $om = $omset->getNilaiOmsetBulanan();
  foreach ($om as $v) {
    $tot += $v['nilai'];
  }
  return $tot;
}

function HitungOmsetTahunan()
{
  $oms = new App\Models\omsTahunan();
  return $oms->getNilaiOmsetTahunan();
}


//  Untuk menghitung kode jika tidak ada nomor yang terlewati ( record terakhir + 1)
function hitungKode($tabel)
{
  //  Untuk localhost, username = root, password = ""
  //  Untuk cloud, host = 145.14.154.207, username = u454747069_prapro374, password = 374@Prapro374
  //  Untuk dbname (cloud dan localhost sama) : u454747069_prapro
  //  Contoh cloud :  $con=mysqli_connect("145.14.154.207","u454747069_prapro374","374@Prapro374","u454747069_prapro");

  $con = mysqli_connect("localhost", "root", "", "u454747069_prapro");
  // Check connection
  if (mysqli_connect_errno()) {
    echo "Gagal koneksi ke MySQL: " . mysqli_connect_error();
  }

  $sql = "SELECT * FROM " . $tabel;

  if ($result = mysqli_query($con, $sql)) {
    // Return the number of rows in result set
    $rowcount = mysqli_num_rows($result);

    $rowcount = $rowcount + 1;
    if ($tabel == 'tb_ta') {
      $kode = 'TA-' . sprintf("%04s", $rowcount);
    }
    if ($tabel == 'tb_proyek') {
      $kode = 'PR-' . sprintf("%04s", $rowcount);
    }

    if ($tabel == 'tb_posisi') {
      $kode = 'PO-' . sprintf("%04s", $rowcount);
    }
    if ($tabel == 'tb_pengalaman') {
      $kode = 'PL_' . sprintf("%04s", $rowcount);
    }
    if ($tabel == 'tb_instansi') {
      $kode = 'IN_' . sprintf("%04s", $rowcount);
    }
    if ($tabel == 'tb_proyek_nq') {
      $kode = 'PL-' . sprintf("%04s", $rowcount);
    }
  }
  mysqli_close($con);
  return $kode;
}


function CheckInstansi($tabel)
{

  $instansi = new App\Models\InstansiModel();
  $no = 0;
  foreach ($tabel as $v) {
    //  Mulai counter
    $no++;
    if (strlen($no) == 1) {
      $no = '000' . $no;
    }
    if (strlen($no) == 2) {
      $no = '00' . $no;
    }
    if (strlen($no) == 3) {
      $no = '0' . $no;
    }
    $nomor = 'IN_' . $no;
    $baris = $instansi->CariKodeInstansi($nomor);
    $kode = isset($baris['kode_instansi']) ? $baris['kode_instansi'] : '';
    if ($kode == '') {
      return $nomor;
      break;
    }
    $nomor = '';
  }
}

function CheckPosisi($tabel)
{

  $posisi = new App\Models\posisiModel();
  $no = 0;
  foreach ($tabel as $v) {
    //  Mulai counter
    $no++;
    if (strlen($no) == 1) {
      $no = '000' . $no;
    }
    if (strlen($no) == 2) {
      $no = '00' . $no;
    }
    if (strlen($no) == 3) {
      $no = '0' . $no;
    }
    $nomor = 'PO-' . $no;
    $baris = $posisi->CariKodePosisi($nomor);
    $kode = isset($baris['kode_posisi']) ? $baris['kode_posisi'] : '';
    if ($kode == '') {
      return $nomor;
      break;
    }
    $nomor = '';
  }
}

function CheckProyek($tabel)
{

  $proyek = new App\Models\proyekModel();
  $no = 0;
  foreach ($tabel as $v) {
    //  Mulai counter
    $no++;
    if (strlen($no) == 1) {
      $no = '000' . $no;
    }
    if (strlen($no) == 2) {
      $no = '00' . $no;
    }
    if (strlen($no) == 3) {
      $no = '0' . $no;
    }
    $nomor = 'PR-' . $no;
    $baris = $proyek->CariKodeProyek($nomor);
    $kode = isset($baris['kode_proyek']) ? $baris['kode_proyek'] : '';
    if ($kode == '') {
      return $nomor;
      break;
    }
    $nomor = '';
  }
}

function CheckPengalaman($tabel)
{

  $pengalaman = new App\Models\ModelPengalaman();
  $no = 0;
  foreach ($tabel as $v) {
    //  Mulai counter
    $no++;
    if (strlen($no) == 1) {
      $no = '000' . $no;
    }
    if (strlen($no) == 2) {
      $no = '00' . $no;
    }
    if (strlen($no) == 3) {
      $no = '0' . $no;
    }
    $nomor = 'PL_' . $no;
    $baris = $pengalaman->CariKodePengalaman($nomor);
    $kode = isset($baris['kode_pengalaman']) ? $baris['kode_pengalaman'] : '';
    if ($kode == '') {
      return $nomor;
      break;
    }
    $nomor = '';
  }
}

function CheckPengalamanNonQ($tabel)
{

  $pengalaman = new App\Models\expNonQModel();
  $no = 0;
  foreach ($tabel as $v) {
    //  Mulai counter
    $no++;
    if (strlen($no) == 1) {
      $no = '000' . $no;
    }
    if (strlen($no) == 2) {
      $no = '00' . $no;
    }
    if (strlen($no) == 3) {
      $no = '0' . $no;
    }
    $nomor = 'PL-' . $no;
    $baris = $pengalaman->CariKodePengalaman($nomor);
    $kode = isset($baris['kode_pengalaman']) ? $baris['kode_pengalaman'] : '';
    if ($kode == '') {
      return $nomor;
      break;
    }
    $nomor = '';
  }
}

function CheckTA($tabel)
{
  $ta = new App\Models\rhModel();
  $no = 0;
  foreach ($tabel as $v) {
    //  Mulai counter
    $no++;
    if (strlen($no) == 1) {
      $no = '000' . $no;
    }
    if (strlen($no) == 2) {
      $no = '00' . $no;
    }
    if (strlen($no) == 3) {
      $no = '0' . $no;
    }
    $nomor = 'TA-' . $no;
    $baris = $ta->CariKodeTA($nomor);
    $kode = isset($baris['kode_ta']) ? $baris['kode_ta'] : '';
    if ($kode == '') {
      return $nomor;
      break;
    }
    $nomor = '';
  }
}


function  NamaBulan($bln)
{
  switch ($bln) {
    case  1:
      return  "Januari";
      break;
    case  2:
      return  "Februari";
      break;
    case  3:
      return  "Maret";
      break;
    case  4:
      return  "April";
      break;
    case  5:
      return  "Mei";
      break;
    case  6:
      return  "Juni";
      break;
    case  7:
      return  "Juli";
      break;
    case  8:
      return  "Agustus";
      break;
    case  9:
      return  "September";
      break;
    case  10:
      return  "Oktober";
      break;
    case  11:
      return  "November";
      break;
    case  12:
      return  "Desember";
      break;
  }
}

function HitungTotalPengalaman($pengalaman)
{
  $totbln = 0;
  //  $this->db->table('tb_ta');
  foreach ($pengalaman as $v) {
    $totbln += $v['jml_bln'];
  }
  //  dd($totbln);
  return $totbln;
}
